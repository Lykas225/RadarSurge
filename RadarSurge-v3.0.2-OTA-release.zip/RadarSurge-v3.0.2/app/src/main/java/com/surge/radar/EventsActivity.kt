package com.surge.radar

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

/**
 * Экран «Мероприятия · Москва»: нативная лента событий по дням (Сегодня / Завтра / далее)
 * в единой цветовой гамме приложения (Palette) с временем, площадкой, адресом и копированием в 1 тап.
 */
class EventsActivity : AppCompatActivity() {

    private val ctx: Context get() = this
    private val matchP = ViewGroup.LayoutParams.MATCH_PARENT
    private val wrapP = ViewGroup.LayoutParams.WRAP_CONTENT
    private val msk = ZoneId.of("Europe/Moscow")

    private lateinit var p: Palette
    private lateinit var statusView: TextView
    private lateinit var catRow: LinearLayout
    private lateinit var listBox: LinearLayout

    private var selectedCat = "all"
    private var events: List<LiveEvent> = emptyList()
    private var lastError: String? = null

    private fun dp(v: Int): Int = dpi(v)

    private fun tv(t: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(ctx).apply {
            text = t
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        p = Palette(WidgetSettings.load(this).dark)
        events = EventsProvider.cached(this)
        buildUi()
        render()
        loadEvents(false)
    }

    private fun buildUi() {
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(p.bg)
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }

        // Верхняя панель
        val topBar = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val backBtn = tv("‹ Назад", 15f, p.accent, true).apply {
            setPadding(0, dp(4), dp(16), dp(4))
            setOnClickListener { finish() }
        }
        val refreshBtn = tv("↻ Обновить", 14f, p.accent, true).apply {
            setPadding(dp(12), dp(6), dp(12), dp(6))
            background = rounded(withAlpha(p.accent, 0.14f), dp(12).toFloat(), withAlpha(p.accent, 0.45f), dp(1))
            setOnClickListener { loadEvents(true) }
        }
        topBar.addView(backBtn, LinearLayout.LayoutParams(0, wrapP, 1f))
        topBar.addView(refreshBtn)
        root.addView(topBar)

        root.addView(
            tv("Москва · Мероприятия", 23f, p.text, true).apply {
                setPadding(0, dp(8), 0, dp(2))
            }
        )

        statusView = tv(EventsProvider.statusLine(this), 12f, p.sub).apply {
            setPadding(0, 0, 0, dp(10))
        }
        root.addView(statusView)

        // Фильтр категорий
        catRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        val catScroll = HorizontalScrollView(ctx).apply {
            isHorizontalScrollBarEnabled = false
            addView(catRow)
        }
        root.addView(catScroll, LinearLayout.LayoutParams(matchP, wrapP).apply { bottomMargin = dp(12) })
        renderCategoryChips()

        // Лента карточек
        val scroll = ScrollView(ctx)
        listBox = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, dp(24))
        }
        scroll.addView(listBox, LinearLayout.LayoutParams(matchP, wrapP))
        root.addView(scroll, LinearLayout.LayoutParams(matchP, 0, 1f))

        setContentView(root)
    }

    private fun renderCategoryChips() {
        catRow.removeAllViews()
        for ((key, label) in EventsProvider.categories) {
            val active = key == selectedCat
            val chip = tv(label, 12.5f, if (active) Color.WHITE else p.text, active).apply {
                gravity = Gravity.CENTER
                setPadding(dp(12), dp(8), dp(12), dp(8))
                background = if (active) {
                    rounded(p.accent, dp(14).toFloat())
                } else {
                    rounded(p.card, dp(14).toFloat(), p.stroke, dp(1))
                }
                setOnClickListener {
                    selectedCat = key
                    renderCategoryChips()
                    render()
                }
            }
            catRow.addView(chip, LinearLayout.LayoutParams(wrapP, wrapP).apply { rightMargin = dp(6) })
        }
    }

    private fun loadEvents(force: Boolean) {
        if (force) {
            statusView.text = "Обновляем афишу Москвы…"
        }
        EventsProvider.refreshAsync(this, force) { list, err ->
            if (isFinishing || isDestroyed) return@refreshAsync
            events = list
            lastError = err
            statusView.text = if (err != null && list.isEmpty()) err else EventsProvider.statusLine(this)
            render()
        }
    }

    private fun render() {
        listBox.removeAllViews()
        val filtered = if (selectedCat == "all") events else events.filter { it.catKey == selectedCat }

        if (filtered.isEmpty()) {
            val emptyCard = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                background = rounded(p.card, dp(16).toFloat(), p.stroke, dp(1))
                setPadding(dp(16), dp(16), dp(16), dp(16))
            }
            val msg = when {
                lastError != null -> "Не удалось загрузить ленту: $lastError"
                events.isEmpty() -> "Загружаем актуальные мероприятия Москвы…"
                else -> "В выбранной категории пока нет ближайших мероприятий."
            }
            emptyCard.addView(tv(msg, 14f, p.sub))
            val retry = tv("↻ Повторить загрузку", 14f, Color.WHITE, true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(12), dp(10), dp(12), dp(10))
                background = rounded(p.accent, dp(12).toFloat())
                setOnClickListener { loadEvents(true) }
            }
            emptyCard.addView(retry, LinearLayout.LayoutParams(matchP, wrapP).apply { topMargin = dp(12) })
            listBox.addView(emptyCard, LinearLayout.LayoutParams(matchP, wrapP))
            addExternalSourcesFooter()
            return
        }

        val today = LocalDate.now(msk)
        val tomorrow = today.plusDays(1)
        val dateFmt = DateTimeFormatter.ofPattern("d MMMM", Locale("ru"))
        val dowFmt = DateTimeFormatter.ofPattern("EEEE", Locale("ru"))

        val grouped = filtered.groupBy { it.dateIso }
        for ((iso, dayEvents) in grouped) {
            val ld = runCatching { LocalDate.parse(iso) }.getOrNull()
            val headerTitle = when {
                ld == null -> iso
                ld == today -> "Сегодня · ${today.format(dateFmt)}"
                ld == tomorrow -> "Завтра · ${tomorrow.format(dateFmt)}"
                else -> "${ld.format(dowFmt).replaceFirstChar { it.uppercase() }} · ${ld.format(dateFmt)}"
            }
            listBox.addView(
                tv(headerTitle, 17f, p.text, true).apply {
                    setPadding(dp(2), dp(12), 0, dp(8))
                }
            )
            for (ev in dayEvents) {
                listBox.addView(
                    buildEventCard(ev),
                    LinearLayout.LayoutParams(matchP, wrapP).apply { bottomMargin = dp(10) }
                )
            }
        }
        addExternalSourcesFooter()
    }

    private fun buildEventCard(ev: LiveEvent): View {
        val card = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            background = rounded(p.card, dp(16).toFloat(), p.stroke, dp(1))
        }

        // Левая вертикальная акцентная полоска (как на референсе)
        val stripe = View(ctx).apply {
            val r = dp(16).toFloat()
            background = GradientDrawable().apply {
                setColor(ev.accentColor)
                cornerRadii = floatArrayOf(r, r, 0f, 0f, 0f, 0f, r, r)
            }
        }
        card.addView(stripe, LinearLayout.LayoutParams(dp(4), matchP))

        // Содержимое карточки
        val body = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(12), dp(14), dp(14), dp(14))
        }

        // Левая колонка: время и иконка категории
        val timeCol = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            minimumWidth = dp(64)
        }
        timeCol.addView(
            tv(
                ev.timeLabel,
                if (ev.hasExactTime) 19f else 14f,
                if (ev.hasExactTime) p.blue else p.sub,
                true
            ).apply { gravity = Gravity.CENTER }
        )
        timeCol.addView(
            tv(ev.catIcon, 16f, p.sub).apply {
                gravity = Gravity.CENTER
                setPadding(0, dp(6), 0, 0)
            }
        )
        body.addView(timeCol, LinearLayout.LayoutParams(dp(66), wrapP).apply { rightMargin = dp(10) })

        // Правая колонка: ⚡ Название, площадка, блок адреса с копированием
        val infoCol = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }

        val titleRow = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.TOP
        }
        titleRow.addView(
            tv("⚡", 15f, ev.accentColor, true).apply {
                setPadding(0, 0, dp(6), 0)
            }
        )
        titleRow.addView(
            tv(ev.title, 16f, p.text, true).apply {
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
            },
            LinearLayout.LayoutParams(0, wrapP, 1f)
        )
        infoCol.addView(titleRow, LinearLayout.LayoutParams(matchP, wrapP))

        infoCol.addView(
            tv(ev.venue, 13.5f, p.sub).apply {
                setPadding(0, dp(3), 0, dp(8))
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
            }
        )

        if (ev.address.isNotBlank()) {
            val addrBox = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = rounded(p.cardAlt, dp(12).toFloat(), withAlpha(p.stroke, 0.7f), dp(1))
                setPadding(dp(10), dp(8), dp(10), dp(8))
                setOnClickListener { OrderOfferReader.openAddressInMaps(ctx, ev.address) }
            }
            addrBox.addView(
                tv("📍", 13f, p.blue).apply { setPadding(0, 0, dp(6), 0) }
            )
            addrBox.addView(
                tv(ev.address, 12.5f, p.text).apply {
                    maxLines = 2
                    ellipsize = TextUtils.TruncateAt.END
                },
                LinearLayout.LayoutParams(0, wrapP, 1f)
            )
            val copyBtn = tv("⧉", 17f, p.sub, true).apply {
                setPadding(dp(10), dp(2), dp(2), dp(2))
                setOnClickListener {
                    val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("address", ev.address))
                    Toast.makeText(ctx, "Адрес скопирован: ${ev.address}", Toast.LENGTH_SHORT).show()
                }
            }
            addrBox.addView(copyBtn)
            infoCol.addView(addrBox, LinearLayout.LayoutParams(matchP, wrapP))
        }

        body.addView(infoCol, LinearLayout.LayoutParams(0, wrapP, 1f))
        card.addView(body, LinearLayout.LayoutParams(0, wrapP, 1f))
        card.setOnClickListener {
            if (ev.address.isNotBlank()) {
                OrderOfferReader.openAddressInMaps(ctx, ev.address)
            } else if (ev.siteUrl.isNotBlank()) {
                runCatching { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(ev.siteUrl))) }
            }
        }
        return card
    }

    private fun addExternalSourcesFooter() {
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(10), 0, dp(4))
        }
        val links = listOf(
            "Яндекс Афиша ↗" to "https://afisha.yandex.ru/moscow/events",
            "Timepad ↗" to "https://afisha.timepad.ru/moscow"
        )
        links.forEachIndexed { idx, (label, url) ->
            val btn = tv(label, 12.5f, p.accent, true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(10), dp(9), dp(10), dp(9))
                background = rounded(p.card, dp(12).toFloat(), p.stroke, dp(1))
                setOnClickListener {
                    runCatching { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
                }
            }
            row.addView(
                btn,
                LinearLayout.LayoutParams(0, wrapP, 1f).apply {
                    if (idx == 0) rightMargin = dp(8)
                }
            )
        }
        listBox.addView(row, LinearLayout.LayoutParams(matchP, wrapP))
    }
}
