package com.surge.radar

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {

    private lateinit var previewBox: FrameLayout
    private var values = WidgetSettings.Values()

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        values = WidgetSettings.load(this)

        val scroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(18, 18, 18)) }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(32))
        }

        col.addView(heading("Настройки виджета"))

        previewBox = FrameLayout(this).apply {
            setBackgroundColor(Color.rgb(70, 82, 94))
            setPadding(dp(8), dp(12), dp(8), dp(12))
        }
        col.addView(
            previewBox,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { topMargin = dp(8) }
        )

        col.addView(heading("Размер"))
        val group = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        val names = listOf("Малый", "Средний", "Большой")
        names.forEachIndexed { i, n ->
            val rb = RadioButton(this).apply {
                id = 1000 + i
                text = n
                setTextColor(Color.WHITE)
            }
            group.addView(rb)
        }
        group.check(1000 + values.size)
        group.setOnCheckedChangeListener { _, id -> update(values.copy(size = id - 1000)) }
        col.addView(group)

        col.addView(slider("Прозрачность фона", 10, 100, values.bgAlpha) { update(values.copy(bgAlpha = it)) })
        col.addView(slider("Прозрачность всего виджета", 30, 100, values.widgetAlpha) { update(values.copy(widgetAlpha = it)) })
        col.addView(slider("Размер виджета", 70, 120, values.scale) { update(values.copy(scale = it)) })

        col.addView(heading("Что показывать"))
        col.addView(toggle("Радар", values.showRadar) { update(values.copy(showRadar = it)) })
        col.addView(toggle("График", values.showGraph) { update(values.copy(showGraph = it)) })
        col.addView(toggle("Ожидание", values.showWait) { update(values.copy(showWait = it)) })
        col.addView(toggle("Цена и вердикт", values.showDecision) { update(values.copy(showDecision = it)) })
        col.addView(toggle("Звук при росте спроса", values.sound) { update(values.copy(sound = it)) })

        scroll.addView(col)
        setContentView(scroll)
        refreshPreview()
    }

    private fun update(v: WidgetSettings.Values) {
        values = v
        WidgetSettings.save(this, v)
        refreshPreview()
    }

    private fun refreshPreview() {
        previewBox.removeAllViews()
        val w = RadarWidgetView(this, values)
        w.bind(WidgetData.sample())
        previewBox.addView(
            w,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER)
        )
    }

    private fun heading(t: String): TextView = TextView(this).apply {
        text = t
        setTextColor(Color.WHITE)
        textSize = 18f
        setPadding(0, dp(16), 0, dp(4))
    }

    private fun slider(title: String, lo: Int, hi: Int, start: Int, onChange: (Int) -> Unit): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val caption = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 15f
            setPadding(0, dp(14), 0, 0)
        }
        fun show(v: Int) {
            caption.text = "$title: $v%"
        }
        show(start)
        val bar = SeekBar(this).apply {
            max = hi - lo
            progress = start - lo
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    val v = p + lo
                    show(v)
                    if (fromUser) onChange(v)
                }

                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        box.addView(caption)
        box.addView(bar)
        return box
    }

    private fun toggle(title: String, checked: Boolean, onChange: (Boolean) -> Unit): Switch =
        Switch(this).apply {
            text = title
            isChecked = checked
            setTextColor(Color.WHITE)
            setPadding(0, dp(8), 0, dp(8))
            setOnCheckedChangeListener { _, c -> onChange(c) }
        }
}
