package com.surge.radar

import android.content.Context
import android.content.Intent
import android.net.Uri
import java.net.URLEncoder
import java.util.regex.Pattern
import kotlin.math.roundToInt

/** Распознанная входящая карточка заказа Яндекс Про (только чтение, без нажатий). */
data class OrderOffer(
    val from: String,
    val to: String,
    val priceRub: Int?,
    val tariff: OrderTariff,
    val surgeCoeff: Double?,
    val surgeBonusRub: Int,
    val pickupMin: Int?,
    val pickupKm: Double?,
    val tripMin: Int?,
    val tripKm: Double?,
    val raw: String,
    val capturedAt: Long
)

object OrderOfferReader {
    private val bonusMoney = Pattern.compile(
        "\\+\\s*(\\d{2,4})\\s*(?:₽|руб(?:\\.|лей|ля)?)",
        Pattern.CASE_INSENSITIVE or Pattern.UNICODE_CASE
    )
    private val priceMoney = Pattern.compile(
        "(?<![+\\d])(\\d{1,3}(?:[\\s\\u00A0]\\d{3})+|\\d{2,5})\\s*(?:₽|руб(?:\\.|лей|ля)?)(?!\\w)",
        Pattern.CASE_INSENSITIVE or Pattern.UNICODE_CASE
    )
    private val coeffPattern = Pattern.compile(
        "(?:×|x|х)\\s*([1-4](?:[.,][0-9]{1,2})?)",
        Pattern.CASE_INSENSITIVE or Pattern.UNICODE_CASE
    )
    private val hourMinPattern = Pattern.compile(
        "(\\d{1,2})\\s*ч(?:\\.|ас(?:а|ов)?)?\\s*(\\d{1,2})\\s*мин",
        Pattern.CASE_INSENSITIVE or Pattern.UNICODE_CASE
    )
    private val minPattern = Pattern.compile(
        "(?<!\\d)(\\d{1,3})\\s*мин(?:\\.|ут[ыа]?)?(?!\\w)",
        Pattern.CASE_INSENSITIVE or Pattern.UNICODE_CASE
    )
    private val kmPattern = Pattern.compile(
        "(?<!\\d)(\\d{1,3}(?:[.,]\\d{1,2})?)\\s*км(?!\\w)",
        Pattern.CASE_INSENSITIVE or Pattern.UNICODE_CASE
    )
    private val metersPattern = Pattern.compile(
        "(?<!\\d)(\\d{2,4})\\s*м(?!ин|\\w)",
        Pattern.CASE_INSENSITIVE or Pattern.UNICODE_CASE
    )
    private val addressHint = Regex(
        "(?iu)(?:^|[\\s,(\\-])(?:улиц|ул\\.|просп|пр-?т\\.?|шоссе|переул|пер\\.|бульвар|б-р|набереж|наб\\.|площад|пл\\.|проезд|алле|тупик|микрорайон|мкр\\.?|д\\.\\s*\\d|д\\s+\\d|дом\\s+\\d|корп|стр\\.\\s*\\d|москва|область|вокзал|аэропорт|терминал|метро|м\\.)"
    )
    private val navTabLabels = setOf("заказы", "предзаказы", "деньги", "чаты", "профиль")
    private val activeTripWords = listOf(
        "начать поездку",
        "завершить поездку",
        "завершить заказ",
        "я на месте",
        "бесплатное ожидание",
        "платное ожидание",
        "в пути"
    )
    private val offerWords = listOf("принять", "пропустить", "новый заказ", "подача", "стоимость", "фикс", "кэф", "доплата")
    private val fromWords = listOf("откуда", "подача", "начало", "забрать", "точка а", "pickup")
    private val toWords = listOf("куда", "адрес назначения", "конец", "доставить", "точка б", "destination")

    private fun clean(s: String) = s.replace(Regex("\\s+"), " ").trim().trim('·', '•', ':', '-', '—')

    fun parse(context: Context, texts: List<String>, activeCoeff: Double? = null): OrderOffer? {
        val lines = texts.map(::clean).filter { it.length > 1 && it.lowercase() !in navTabLabels }
        if (lines.isEmpty()) return null

        // Строго игнорируем уже принятый заказ и экран ожидания пассажира
        val isActiveTrip = lines.any { line ->
            val low = line.lowercase()
            low == "ожидание" || activeTripWords.any { low.contains(it) }
        }
        if (isActiveTrip) return null

        val all = lines.joinToString(" | ")
        val lowAll = all.lowercase()
        val hasOfferHint = offerWords.any { lowAll.contains(it) }
        if (!hasOfferHint) return null

        // 1. Определение тарифа
        val fallbackTariff = WidgetSettings.load(context).enabledTariffs()
            .firstOrNull()?.let(OrderTariff::fromAppTariff) ?: OrderTariff.COMFORT
        val tariff = OrderTariffRates.detect(lines, fallbackTariff)

        // 2. Адреса А и Б
        var from = ""
        var to = ""
        lines.forEachIndexed { index, line ->
            val lower = line.lowercase()
            if (from.isBlank() && fromWords.any(lower::contains)) {
                from = extractAddress(line) ?: lines.getOrNull(index + 1)?.takeIf(::looksAddress).orEmpty()
            }
            if (to.isBlank() && toWords.any(lower::contains)) {
                to = extractAddress(line) ?: lines.getOrNull(index + 1)?.takeIf(::looksAddress).orEmpty()
            }
        }
        val candidates = lines.filter(::looksAddress).distinct()
        if (from.isBlank() && candidates.isNotEmpty()) from = candidates[0]
        if (to.isBlank() && candidates.size > 1) to = candidates[1]

        // 3. Коэффициент и доплата (+120 ₽)
        var surgeCoeff: Double? = null
        val cm = coeffPattern.matcher(all.replace(',', '.'))
        while (cm.find()) {
            val v = cm.group(1)?.toDoubleOrNull()
            if (v != null && v in 1.0..5.0) {
                surgeCoeff = maxOf(surgeCoeff ?: 1.0, v)
            }
        }
        if (surgeCoeff == null && activeCoeff != null && activeCoeff > 1.0) {
            surgeCoeff = activeCoeff
        }

        var surgeBonus = 0
        val bm = bonusMoney.matcher(all)
        while (bm.find()) {
            val b = bm.group(1)?.toIntOrNull()
            if (b != null && b in 10..5000) {
                surgeBonus = maxOf(surgeBonus, b)
            }
        }

        // 4. Фиксированная цена заказа (если указана на карточке)
        var price: Int? = null
        val pm = priceMoney.matcher(all)
        while (pm.find()) {
            val rawNum = pm.group(1)?.replace(Regex("[\\s\\u00A0]"), "") ?: continue
            val n = rawNum.toIntOrNull()
            if (n != null && n in 80..100_000 && n != surgeBonus) {
                price = n
                break
            }
        }

        // 5. Время и расстояние подачи / поездки
        val minsFound = mutableListOf<Int>()
        val kmsFound = mutableListOf<Double>()
        for (line in lines) {
            val hm = hourMinPattern.matcher(line)
            if (hm.find()) {
                val h = hm.group(1)?.toIntOrNull() ?: 0
                val m = hm.group(2)?.toIntOrNull() ?: 0
                val totalM = h * 60 + m
                if (totalM in 1..600) minsFound.add(totalM)
            } else {
                val mm = minPattern.matcher(line)
                while (mm.find()) {
                    val m = mm.group(1)?.toIntOrNull()
                    if (m != null && m in 1..300) minsFound.add(m)
                }
            }
            val km = kmPattern.matcher(line)
            var foundKm = false
            while (km.find()) {
                val v = km.group(1)?.replace(',', '.')?.toDoubleOrNull()
                if (v != null && v in 0.1..500.0) {
                    kmsFound.add(v)
                    foundKm = true
                }
            }
            if (!foundKm) {
                val mtr = metersPattern.matcher(line)
                if (mtr.find()) {
                    val mv = mtr.group(1)?.toDoubleOrNull()
                    if (mv != null && mv in 50.0..9500.0) {
                        kmsFound.add((mv / 100.0).roundToInt() / 10.0)
                    }
                }
            }
        }

        val pickupMin: Int?
        val tripMin: Int?
        when {
            minsFound.size >= 2 -> {
                pickupMin = minsFound[0]
                tripMin = minsFound[1]
            }
            minsFound.size == 1 -> {
                if (minsFound[0] <= 15 && to.isBlank()) {
                    pickupMin = minsFound[0]
                    tripMin = null
                } else {
                    pickupMin = null
                    tripMin = minsFound[0]
                }
            }
            else -> {
                pickupMin = null
                tripMin = null
            }
        }

        val pickupKm: Double?
        val tripKm: Double?
        when {
            kmsFound.size >= 2 -> {
                pickupKm = kmsFound[0]
                tripKm = kmsFound[1]
            }
            kmsFound.size == 1 -> {
                if (kmsFound[0] <= 4.0 && to.isBlank()) {
                    pickupKm = kmsFound[0]
                    tripKm = null
                } else {
                    pickupKm = null
                    tripKm = kmsFound[0]
                }
            }
            else -> {
                pickupKm = null
                tripKm = null
            }
        }

        // Если вообще нет ни адресов, ни цены, ни расстояния/времени — это не карточка заказа
        if (from.isBlank() && to.isBlank() && price == null && tripMin == null && tripKm == null) return null

        val normalized = "${tariff.name}|$from|$to|$price|$pickupMin|$tripMin|$pickupKm|$tripKm"
        val prefs = context.getSharedPreferences("last_order_card", Context.MODE_PRIVATE)
        if (prefs.getString("fingerprint", "") == normalized) return null

        val offer = OrderOffer(
            from = from,
            to = to,
            priceRub = price,
            tariff = tariff,
            surgeCoeff = surgeCoeff,
            surgeBonusRub = surgeBonus,
            pickupMin = pickupMin,
            pickupKm = pickupKm,
            tripMin = tripMin,
            tripKm = tripKm,
            raw = lines.take(60).joinToString("\n"),
            capturedAt = System.currentTimeMillis()
        )
        save(context, normalized, offer)
        return offer
    }

    private fun save(context: Context, fingerprint: String, offer: OrderOffer) {
        val prefs = context.getSharedPreferences("last_order_card", Context.MODE_PRIVATE)
        prefs.edit()
            .putString("fingerprint", fingerprint)
            .putString("from", offer.from)
            .putString("to", offer.to)
            .putInt("price", offer.priceRub ?: -1)
            .putString("tariff", offer.tariff.name)
            .putFloat("coeff", (offer.surgeCoeff ?: -1.0).toFloat())
            .putInt("bonus", offer.surgeBonusRub)
            .putInt("pmin", offer.pickupMin ?: -1)
            .putFloat("pkm", (offer.pickupKm ?: -1.0).toFloat())
            .putInt("tmin", offer.tripMin ?: -1)
            .putFloat("tkm", (offer.tripKm ?: -1.0).toFloat())
            .putString("raw", offer.raw)
            .putLong("captured", offer.capturedAt)
            .apply()
        ReaderDiag.lastOrderAt = offer.capturedAt
    }

    private fun extractAddress(line: String): String? {
        val split = line.split(":", "—", "–", "->", "→")
        if (split.size < 2) return null
        return split.lastOrNull()?.let(::clean)?.takeIf(::looksAddress)
    }

    private fun looksAddress(s: String): Boolean =
        s.length >= 6 && addressHint.containsMatchIn(s) && !s.contains("₽") && !s.contains("руб", true)

    fun load(c: Context): OrderOffer? {
        val p = c.getSharedPreferences("last_order_card", Context.MODE_PRIVATE)
        val from = p.getString("from", "") ?: ""
        val to = p.getString("to", "") ?: ""
        val price = p.getInt("price", -1)
        val tmin = p.getInt("tmin", -1)
        val tkm = p.getFloat("tkm", -1f)
        if (from.isBlank() && to.isBlank() && price < 0 && tmin < 0 && tkm < 0f) return null
        return OrderOffer(
            from = from,
            to = to,
            priceRub = price.takeIf { it >= 0 },
            tariff = OrderTariff.byNameOrDefault(p.getString("tariff", null)),
            surgeCoeff = p.getFloat("coeff", -1f).toDouble().takeIf { it >= 1.0 },
            surgeBonusRub = p.getInt("bonus", 0),
            pickupMin = p.getInt("pmin", -1).takeIf { it >= 0 },
            pickupKm = p.getFloat("pkm", -1f).toDouble().takeIf { it >= 0.0 },
            tripMin = tmin.takeIf { it >= 0 },
            tripKm = tkm.toDouble().takeIf { it >= 0.0 },
            raw = p.getString("raw", "") ?: "",
            capturedAt = p.getLong("captured", 0L)
        )
    }

    fun summary(o: OrderOffer): String = buildString {
        append("Карточка заказа · ${o.tariff.title}\n")
        if (o.from.isNotBlank()) append("А: ${o.from}\n")
        if (o.to.isNotBlank()) append("Б: ${o.to}\n")
        if (o.priceRub != null) append("Цена на карточке: ${o.priceRub} ₽\n")
        if (o.tripMin != null || o.tripKm != null) {
            append("В пути: ${o.tripMin ?: "—"} мин · ${o.tripKm?.let { String.format(java.util.Locale.US, "%.1f км", it) } ?: "—"}\n")
        }
        append("Время: ${java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date(o.capturedAt))}")
    }

    fun openTrafficRoute(context: Context, offer: OrderOffer) {
        if (offer.from.isBlank() && offer.to.isBlank()) return
        val uri = if (offer.from.isNotBlank() && offer.to.isNotBlank()) {
            val route = URLEncoder.encode(offer.from, "UTF-8") + "~" + URLEncoder.encode(offer.to, "UTF-8")
            Uri.parse("https://yandex.ru/maps/?rtext=$route&rtt=auto")
        } else {
            val target = offer.to.ifBlank { offer.from }
            Uri.parse("https://yandex.ru/maps/?text=" + URLEncoder.encode(target, "UTF-8"))
        }
        runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }

    fun openAddressInMaps(context: Context, address: String) {
        if (address.isBlank()) return
        val uri = Uri.parse("https://yandex.ru/maps/?text=" + URLEncoder.encode(address, "UTF-8"))
        runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }
}
