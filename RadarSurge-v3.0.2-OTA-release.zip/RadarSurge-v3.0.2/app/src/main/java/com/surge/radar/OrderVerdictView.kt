package com.surge.radar

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Компактная карточка вердикта выгодности заказа в плавающем виджете.
 * Показывает поступивший тариф, расчётную/реальную цену, время, пробег, чистую прибыль и итог:
 * ВЫГОДНО / МОЖНО БРАТЬ / НЕВЫГОДНО.
 */
class OrderVerdictView(context: Context, private val cfg: WidgetSettings.Values) : LinearLayout(context) {

    var onClose: (() -> Unit)? = null
    var onOpenRoute: ((OrderOffer) -> Unit)? = null

    private val f = cfg.scale / 100f
    private val fk = cfg.fontPct / 100f
    private val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
    private val match = ViewGroup.LayoutParams.MATCH_PARENT
    private val bgA = (cfg.bgAlpha * 255 / 100).coerceIn(190, 255)

    private var currentOffer: OrderOffer? = null

    private fun px(v: Float): Int = (v * resources.displayMetrics.density * f).roundToInt()

    private fun tv(t: String, size: Float, color: Int, strong: Boolean = false): TextView =
        TextView(context).apply {
            text = t
            setTextSize(TypedValue.COMPLEX_UNIT_SP, size * f * fk)
            setTextColor(color)
            typeface = weightTypeface(if (strong) min(900, cfg.fontWeight + 200) else cfg.fontWeight)
            includeFontPadding = false
        }

    private val frame = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(Color.argb(bgA, 27, 35, 44), Color.argb(bgA, 16, 22, 29))
    ).apply { cornerRadius = px(16f).toFloat() }

    private val verdictBadge = tv("", 12f, Color.WHITE, true).apply {
        setPadding(px(8f), px(3f), px(8f), px(3f))
    }
    private val tariffBadge = tv("", 11f, 0xFFE8EDF2.toInt(), true).apply {
        setPadding(px(7f), px(3f), px(7f), px(3f))
        background = rounded(0x22FFFFFF, px(8f).toFloat(), 0x4493A1B0, px(1f).coerceAtLeast(1))
    }
    private val mainMetrics = tv("", 14f, 0xFFE8EDF2.toInt(), true)
    private val ecoLine = tv("", 12f, 0xFF55D68B.toInt(), true)
    private val detailLine = tv("", 10.5f, 0xFF93A1B0.toInt(), false)
    private val routeLine = tv("", 10.5f, 0xFFC5D2DE.toInt(), false).apply {
        maxLines = 2
        ellipsize = TextUtils.TruncateAt.END
    }
    private val routeBtn = tv("🗺 Маршрут в Картах", 11.5f, 0xFF4DB6AC.toInt(), true).apply {
        gravity = Gravity.CENTER
        setPadding(px(8f), px(5f), px(8f), px(5f))
        background = rounded(withAlpha(0xFF4DB6AC.toInt(), 0.14f), px(10f).toFloat(), withAlpha(0xFF4DB6AC.toInt(), 0.45f), px(1f).coerceAtLeast(1))
        setOnClickListener { currentOffer?.let { onOpenRoute?.invoke(it) } }
    }

    init {
        orientation = LinearLayout.VERTICAL
        background = frame
        setPadding(px(10f), px(8f), px(10f), px(9f))
        alpha = cfg.widgetAlpha / 100f
        minimumWidth = px(236f)

        val head = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        head.addView(verdictBadge, LinearLayout.LayoutParams(wrap, wrap))
        head.addView(tariffBadge, LinearLayout.LayoutParams(wrap, wrap).apply { leftMargin = px(6f) })
        val spacer = View(context)
        head.addView(spacer, LinearLayout.LayoutParams(0, 1, 1f))
        val closeBtn = tv("✕", 13.5f, 0xFF93A1B0.toInt(), true).apply {
            setPadding(px(8f), px(2f), px(2f), px(2f))
            setOnClickListener { onClose?.invoke() }
        }
        head.addView(closeBtn)
        addView(head, LinearLayout.LayoutParams(match, wrap))

        addView(mainMetrics, LinearLayout.LayoutParams(match, wrap).apply { topMargin = px(6f) })
        addView(ecoLine, LinearLayout.LayoutParams(match, wrap).apply { topMargin = px(3f) })
        addView(detailLine, LinearLayout.LayoutParams(match, wrap).apply { topMargin = px(3f) })
        addView(routeLine, LinearLayout.LayoutParams(match, wrap).apply { topMargin = px(4f) })
        addView(routeBtn, LinearLayout.LayoutParams(match, wrap).apply { topMargin = px(6f) })
    }

    fun bind(ev: OrderEvaluation, loadingRoute: Boolean = false) {
        currentOffer = ev.offer
        val vc = ev.verdict.color
        frame.setStroke(px(1.5f).coerceAtLeast(1), withAlpha(vc, 0.85f))

        verdictBadge.text = if (ev.verdict == OrderVerdict.INSUFFICIENT) ev.verdict.title else "${ev.verdict.title} ${ev.score}"
        verdictBadge.setTextColor(vc)
        verdictBadge.background = rounded(
            withAlpha(vc, 0.18f), px(8f).toFloat(),
            withAlpha(vc, 0.65f), px(1f).coerceAtLeast(1)
        )

        tariffBadge.text = ev.tariff.shortTitle

        val approx = if (ev.priceEstimated) "~" else ""
        val routeMark = if (loadingRoute) " · уточн…" else ""
        mainMetrics.text = String.format(
            Locale.US,
            "%s%d ₽ · %d мин · %.1f км%s",
            approx, ev.grossRub, ev.tripMin, ev.tripKm, routeMark
        )

        val modeLabel = if (cfg.netMode) "Чистыми" else "Грязными"
        val shownSum = if (cfg.netMode) ev.netRub else ev.grossRub
        ecoLine.text = "$modeLabel $shownSum ₽ · ${ev.rubPerHour} ₽/ч · ${ev.rubPerKm} ₽/км"
        ecoLine.setTextColor(vc)

        detailLine.text = "Подача ${ev.pickupMin}м · Ком -${ev.commissionRub}₽ · Бенз -${ev.fuelRub}₽" +
            if (ev.destZoneName.isNotBlank()) " · Б: ${ev.destZoneName} ${DemandModel.coefText(ev.destZonePct)}" else ""

        val a = ev.offer.from.removePrefix("Москва, ").take(32)
        val b = ev.offer.to.removePrefix("Москва, ").take(32)
        if (a.isNotBlank() || b.isNotBlank()) {
            routeLine.visibility = View.VISIBLE
            routeLine.text = when {
                a.isNotBlank() && b.isNotBlank() -> "$a → $b"
                b.isNotBlank() -> "→ $b"
                else -> "А: $a"
            }
            routeBtn.visibility = View.VISIBLE
        } else {
            routeLine.visibility = View.GONE
            routeBtn.visibility = View.GONE
        }
    }
}
