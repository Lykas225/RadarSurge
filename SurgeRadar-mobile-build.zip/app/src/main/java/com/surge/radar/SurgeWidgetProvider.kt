package com.surge.radar

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.SystemClock
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.graphics.Typeface
import android.view.View
import android.widget.RemoteViews

/** Виджет домашнего экрана: спрос по всем включённым тарифам для выбранной зоны. */
class SurgeWidgetProvider : AppWidgetProvider() {

    companion object {
        const val ACTION_REFRESH = "com.surge.radar.WIDGET_REFRESH"

        fun refreshAll(ctx: Context) {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, SurgeWidgetProvider::class.java))
            for (id in ids) mgr.updateAppWidget(id, buildViews(ctx))
        }

        private fun pending(ctx: Context): PendingIntent {
            val i = Intent(ctx, SurgeWidgetProvider::class.java).setAction(ACTION_REFRESH)
            return PendingIntent.getBroadcast(ctx, 0, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        }

        fun scheduleAlarm(ctx: Context) {
            val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val interval = WidgetSettings.load(ctx).refreshMin * 60_000L
            am.setInexactRepeating(
                AlarmManager.ELAPSED_REALTIME,
                SystemClock.elapsedRealtime() + interval,
                interval,
                pending(ctx)
            )
        }

        fun cancelAlarm(ctx: Context) {
            val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            am.cancel(pending(ctx))
        }

        private fun buildViews(ctx: Context): RemoteViews {
            val v = RemoteViews(ctx.packageName, R.layout.widget_surge)
            val cfg = WidgetSettings.load(ctx)
            val zone = MoscowRegionGrid.zones.firstOrNull { it.name == cfg.zone } ?: MoscowRegionGrid.zones.first()
            val tariffs = cfg.enabledTariffs()
            val base = DemandModel.baseCoeff(zone)

            v.setTextViewText(R.id.w_zone, zone.name)
            val rowIds = intArrayOf(R.id.w_row1, R.id.w_row2, R.id.w_row3)
            for (i in rowIds.indices) {
                val t = tariffs.getOrNull(i)
                if (t == null) {
                    if (i == 0) {
                        v.setViewVisibility(rowIds[i], View.VISIBLE)
                        v.setTextViewText(rowIds[i], "Тарифы выключены")
                    } else {
                        v.setViewVisibility(rowIds[i], View.GONE)
                    }
                    continue
                }
                val c = DemandModel.scale(base, t)
                val pct = DemandModel.pct(c)
                val s = SpannableStringBuilder(t.title)
                if (cfg.showDemand) {
                    s.append("  ")
                    val st = s.length
                    s.append("+$pct%")
                    s.setSpan(ForegroundColorSpan(DemandModel.textColor(pct)), st, s.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    s.setSpan(StyleSpan(Typeface.BOLD), st, s.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
                if (cfg.showWait) {
                    s.append("  ")
                    val st = s.length
                    s.append("~${DemandModel.waitMinutes(c)} мин")
                    s.setSpan(ForegroundColorSpan(Color.LTGRAY), st, s.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
                v.setViewVisibility(rowIds[i], View.VISIBLE)
                v.setTextViewText(rowIds[i], s)
            }

            v.setOnClickPendingIntent(R.id.w_refresh, pending(ctx))
            val open = PendingIntent.getActivity(
                ctx, 1, Intent(ctx, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            v.setOnClickPendingIntent(R.id.w_root, open)
            return v
        }
    }

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) appWidgetManager.updateAppWidget(id, buildViews(context))
        WeatherProvider.refreshAsync { refreshAll(context) }
        scheduleAlarm(context)
    }

    override fun onEnabled(context: Context) {
        scheduleAlarm(context)
    }

    override fun onDisabled(context: Context) {
        cancelAlarm(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_REFRESH) {
            WeatherProvider.refreshAsync(true) { refreshAll(context) }
            refreshAll(context)
        }
    }
}
