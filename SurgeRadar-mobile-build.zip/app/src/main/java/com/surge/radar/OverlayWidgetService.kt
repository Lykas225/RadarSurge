package com.surge.radar

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.*
import android.provider.Settings
import android.view.*
import android.widget.*
import java.util.Locale
import kotlin.math.roundToInt

class OverlayWidgetService : Service() {

    companion object {
        const val ACTION_UPDATE = "com.surge.radar.UPDATE"
        const val CHANNEL_ID = "surge_radar"
        const val NOTIFICATION_ID = 1001

        fun start(context: Context) {
            val intent = Intent(context, OverlayWidgetService::class.java)
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(intent)
            else context.startService(intent)
        }
    }

    private lateinit var wm: WindowManager
    private lateinit var root: LinearLayout
    private lateinit var surge: TextView
    private lateinit var route: TextView
    private lateinit var destination: TextView
    private lateinit var prediction: TextView
    private lateinit var decision: TextView
    private lateinit var soundButton: TextView

    private var soundEnabled = true
    private var tone: ToneGenerator? = null
    private var lastAlertTier = 0
    private var lastCoeff = 1.0
    private var lastRecordTime = 0L
    private var lastRecordCoeff = 0.0

    override fun onCreate() {
        super.onCreate()
        RadarEngine.init(this)
        createChannel()
        startForegroundCompat()

        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        tone = runCatching { ToneGenerator(AudioManager.STREAM_NOTIFICATION, 100) }.getOrNull()

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 14, 20, 14)
            setBackgroundColor(Color.argb(235, 20, 20, 20))
        }

        surge = tv("🔥 КЭФ: ожидание…", 15f, Color.WHITE)
        route = tv("Цена: -- ₽ | Время: -- мин", 13f, Color.WHITE)
        destination = tv("Финиш: --", 13f, Color.WHITE)
        prediction = tv("Прогноз: недостаточно данных", 13f, Color.YELLOW)
        decision = tv("🎯 Решение: ожидание данных", 13f, Color.LTGRAY)

        val row = LinearLayout(this)
        val map = tv("[ КАРТА ]", 12f, Color.YELLOW)
        map.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }

        soundButton = tv("[ ЗВУК: ВКЛ ]", 12f, Color.GREEN)
        soundButton.setOnClickListener {
            soundEnabled = !soundEnabled
            soundButton.text = if (soundEnabled) "[ ЗВУК: ВКЛ ]" else "[ ЗВУК: ВЫКЛ ]"
            soundButton.setTextColor(if (soundEnabled) Color.GREEN else Color.GRAY)
        }

        val close = tv("[ X ]", 12f, Color.RED)
        close.setOnClickListener { stopSelf() }

        row.addView(map)
        row.addView(soundButton)
        row.addView(close)

        root.addView(surge)
        root.addView(route)
        root.addView(destination)
        root.addView(prediction)
        root.addView(decision)
        root.addView(row)

        val type = if (Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 170
        }

        root.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0
            var sy = 0
            var tx = 0f
            var ty = 0f
            override fun onTouch(v: View?, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        sx = params.x; sy = params.y
                        tx = e.rawX; ty = e.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = sx + (e.rawX - tx).toInt()
                        params.y = sy + (e.rawY - ty).toInt()
                        wm.updateViewLayout(root, params)
                        return true
                    }
                }
                return false
            }
        })

        wm.addView(root, params)
    }

    private fun tv(text: String, size: Float, color: Int) =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            setPadding(0, 3, 16, 3)
        }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        intent ?: return START_STICKY
        if (!::root.isInitialized) return START_NOT_STICKY

        val coeff = if (intent.hasExtra("COEFF"))
            intent.getDoubleExtra("COEFF", lastCoeff) else lastCoeff

        lastCoeff = coeff

        val price = intent.getStringExtra("PRICE")
        val duration = intent.getStringExtra("DURATION")
        val zone = intent.getStringExtra("ZONE")
        val dest = intent.getStringExtra("DEST_NAME")
        val destCoeff = intent.getDoubleExtra("DEST_COEFF", -1.0)
        val priceNum = price?.replace("[^0-9.]".toRegex(), "")?.toDoubleOrNull()
        val durationNum = duration?.filter { it.isDigit() }?.toIntOrNull()

        // Пишем в историю только реальные новые наблюдения кэфа, а не каждый служебный интент
        val now = System.currentTimeMillis()
        val shouldRecord = intent.hasExtra("COEFF") &&
            (coeff != lastRecordCoeff || now - lastRecordTime > 10_000L)
        val p = if (shouldRecord) {
            lastRecordTime = now
            lastRecordCoeff = coeff
            RadarEngine.record(this, coeff, priceNum, durationNum, zone)
        } else {
            RadarEngine.predict(coeff, zone, priceNum, durationNum)
        }

        surge.text = String.format(Locale.US, "🔥 КЭФ ×%.1f%s",
            coeff, if (zone != null) " | $zone" else "")
        surge.setTextColor(
            when {
                coeff >= 2.3 -> Color.MAGENTA
                coeff >= 1.8 -> 0xFFFF7043.toInt()
                coeff >= 1.5 -> 0xFF00E676.toInt()
                else -> Color.LTGRAY
            }
        )

        if (price != null || duration != null) {
            route.text = "Цена: ${price ?: "-- ₽"} | Время: ${duration ?: "-- мин"}"
        }

        if (dest != null) {
            destination.text = if (destCoeff >= 0)
                String.format(Locale.US, "Финиш: %s | Там ×%.1f", dest, destCoeff)
            else "Финиш: $dest"
        }

        prediction.text = String.format(
            Locale.US,
            "Прогноз: %s | риск %d%% | через 5м ×%.1f | 10м ×%.1f | уверенность %d%%",
            p.label, p.probability, p.forecast5, p.forecast10, p.confidence
        )
        prediction.setTextColor(
            when {
                p.probability >= 80 -> Color.MAGENTA
                p.probability >= 60 -> 0xFFFFAB00.toInt()
                else -> Color.WHITE
            }
        )

        decision.text = "🎯 ${p.decision} | рейтинг ${p.decisionScore}/100"
        decision.setTextColor(when { p.decisionScore >= 75 -> 0xFF00E676.toInt(); p.decisionScore >= 55 -> 0xFFFFD740.toInt(); else -> Color.LTGRAY })

        val tier = when {
            p.probability >= 80 -> 3
            p.probability >= 60 -> 2
            p.probability >= 40 -> 1
            else -> 0
        }
        if (tier > lastAlertTier) {
            beep(tier >= 3)
            lastAlertTier = tier
        }
        if (tier == 0) lastAlertTier = 0

        return START_STICKY
    }

    private fun beep(high: Boolean) {
        if (!soundEnabled) return
        runCatching {
            tone?.startTone(
                if (high) ToneGenerator.TONE_CDMA_HIGH_L else ToneGenerator.TONE_PROP_BEEP2,
                if (high) 500 else 250
            )
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Surge Radar", NotificationManager.IMPORTANCE_LOW
            )
            channel.description = "Постоянная работа радара поверх Яндекс Про"
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun startForegroundCompat() {
        val notification = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Радар кэфа работает")
            .setContentText("Считывает данные Яндекс Про и прогнозирует всплески")
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    override fun onDestroy() {
        runCatching { if (::root.isInitialized) wm.removeView(root) }
        tone?.release()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
