package com.surge.radar

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate
import java.time.OffsetDateTime
import java.time.ZoneId
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.max

/**
 * Прилёты и прибытия поездов по расписанию Яндекс Расписаний (нужен бесплатный ключ API).
 * Считаем, сколько рейсов прибывает возле текущего момента: это и есть спрос на такси у аэропортов и вокзалов.
 * Запросов в сутки ограничено счётчиком, чтобы не выбрать лимит ключа.
 */
object ScheduleProvider {
    private const val BASE = "https://api.rasp.yandex-net.ru/v3.0"
    private const val PREFS = "rasp"
    private const val DAILY_LIMIT = 400

    private val arrivals = ConcurrentHashMap<String, LongArray>()
    @Volatile private var fetchedAt = 0L
    @Volatile private var fetching = false
    @Volatile var lastError: String = ""
        private set

    private fun prefs(c: Context) = c.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun key(c: Context): String = prefs(c).getString("key", "") ?: ""

    fun setKey(c: Context, k: String) {
        prefs(c).edit().putString("key", k.trim()).remove("codes").apply()
        arrivals.clear()
        fetchedAt = 0L
        lastError = ""
    }

    fun arrivalsBetween(poi: Poi, fromMs: Long, toMs: Long): Int? {
        val a = arrivals[poi.name] ?: return null
        return a.count { it in fromMs..toMs }
    }

    fun status(c: Context): String = when {
        key(c).isBlank() -> "ключ не задан, считаю по времени суток"
        lastError.isNotEmpty() -> "ошибка: $lastError"
        arrivals.isEmpty() -> "ещё не загружено"
        else -> "по расписанию Яндекса, запросов сегодня: ${used(c)}"
    }

    private fun today(): String = LocalDate.now(ZoneId.of("Europe/Moscow")).toString()

    private fun used(c: Context): Int {
        val p = prefs(c)
        return if (p.getString("day", "") == today()) p.getInt("count", 0) else 0
    }

    private fun spend(c: Context) {
        val p = prefs(c)
        val d = today()
        val n = if (p.getString("day", "") == d) p.getInt("count", 0) else 0
        p.edit().putString("day", d).putInt("count", n + 1).apply()
    }

    private fun get(c: Context, url: String): JSONObject {
        if (used(c) >= DAILY_LIMIT) throw Exception("лимит запросов на сегодня")
        spend(c)
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 8000
        conn.readTimeout = 8000
        try {
            val code = conn.responseCode
            if (code != 200) throw Exception(if (code == 403 || code == 401) "ключ не принят" else "HTTP $code")
            return JSONObject(conn.inputStream.use { it.readBytes() }.toString(Charsets.UTF_8))
        } finally {
            conn.disconnect()
        }
    }

    private fun norm(s: String): String = s.lowercase().replace('ё', 'е')

    private fun codeFor(c: Context, poi: Poi, key: String): String? {
        val p = prefs(c)
        val codes = JSONObject(p.getString("codes", "{}") ?: "{}")
        codes.optString(poi.name, "").takeIf { it.isNotEmpty() }?.let { return it }

        val airport = poi.kind == PoiKind.AIRPORT
        val url = "$BASE/nearest_stations/?apikey=$key&lat=${poi.lat}&lng=${poi.lon}&distance=3&limit=10" +
            "&station_types=${if (airport) "airport" else "train_station"}" +
            "&transport_types=${if (airport) "plane" else "train"}&lang=ru_RU&format=json"
        val arr = get(c, url).optJSONArray("stations") ?: return null
        var best: String? = null
        for (i in 0 until arr.length()) {
            val st = arr.optJSONObject(i) ?: continue
            val code = st.optString("code", "")
            if (code.isEmpty()) continue
            if (best == null) best = code
            val title = norm(st.optString("title", "") + " " + st.optString("popular_title", ""))
            if (poi.match.isNotEmpty() && title.contains(norm(poi.match))) {
                best = code
                break
            }
        }
        if (best != null) {
            codes.put(poi.name, best)
            p.edit().putString("codes", codes.toString()).apply()
        }
        return best
    }

    private fun fetchArrivals(c: Context, code: String, poi: Poi, key: String, now: Long): LongArray {
        val tt = if (poi.kind == PoiKind.AIRPORT) "plane" else "train"
        val out = ArrayList<Long>()
        var offset = 0
        var prevFirst = Long.MIN_VALUE
        for (page in 0 until 8) {
            val url = "$BASE/schedule/?apikey=$key&station=$code&event=arrival&date=${today()}" +
                "&transport_types=$tt&limit=100&offset=$offset&lang=ru_RU&format=json"
            val arr = get(c, url).optJSONArray("schedule") ?: break
            if (arr.length() == 0) break
            var first = Long.MIN_VALUE
            var last = 0L
            for (i in 0 until arr.length()) {
                val s = arr.optJSONObject(i)?.optString("arrival", "") ?: ""
                if (s.isEmpty() || s == "null") continue
                val t = runCatching { OffsetDateTime.parse(s).toInstant().toEpochMilli() }.getOrNull() ?: continue
                if (first == Long.MIN_VALUE) first = t
                last = max(last, t)
                out.add(t)
            }
            if (first == prevFirst) break // сервер повторил ту же страницу: постраничность не поддержана
            prevFirst = first
            if (arr.length() < 100 || last > now + 45 * 60_000L) break
            offset += 100
        }
        return out.toLongArray()
    }

    fun refreshAsync(c: Context, pois: List<Poi>, force: Boolean = false, onDone: (() -> Unit)? = null) {
        val app = c.applicationContext
        val key = key(app)
        val now = System.currentTimeMillis()
        if (key.isBlank() || fetching) return
        if (!force && now - fetchedAt < 60 * 60_000L) return
        fetching = true
        Thread {
            try {
                for (poi in pois) {
                    if (poi.kind != PoiKind.AIRPORT && poi.kind != PoiKind.STATION) continue
                    val code = codeFor(app, poi, key) ?: continue
                    arrivals[poi.name] = fetchArrivals(app, code, poi, key, now)
                }
                fetchedAt = now
                lastError = ""
            } catch (e: Exception) {
                lastError = e.message?.take(40) ?: "ошибка"
                fetchedAt = now - 50 * 60_000L // повтор примерно через 10 минут
            } finally {
                fetching = false
                onDone?.let { cb -> android.os.Handler(android.os.Looper.getMainLooper()).post { cb() } }
            }
        }.start()
    }
}
