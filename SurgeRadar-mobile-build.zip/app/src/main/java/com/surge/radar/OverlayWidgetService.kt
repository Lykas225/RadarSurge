package com.surge.radar

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.PixelFormat
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max

/**
 * Плавающий виджет поверх экрана. Работает сам по себе: спрос считается моделью
 * по выбранной зоне. Данные Яндекс Про (если приложение открыто) только дополняют картину.
 */
class OverlayWidgetService : Service() {

    companion object {
        const val CHANNEL_ID = "surge_radar"
        const val NOTIFICATION_ID = 1001
        private const val ORDER_TTL = 5 * 60_000L

        fun start(context: Context) {
            val intent = Intent(context, OverlayWidgetService::class.java)
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(intent)
            else context.startService(intent)
        }
    }

    private lateinit var wm: WindowManager
    private var widget: RadarWidgetView? = null
    private var cfg = WidgetSettings.Values()
    private var overlayReady = false
    private var tone: ToneGenerator? = null

    private val handler = Handler(Looper.getMainLooper())

    private var pendingFull = false
    private val onPrefsChanged = Runnable {
        if (pendingFull) {
            pendingFull = false
            buildWidget()
        } else {
            refreshData()
        }
    }
    private val prefsListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key != "zone" && key != "tariffs" && key != "overlayOn") pendingFull = true
        handler.removeCallbacks(onPrefsChanged)
        handler.postDelayed(onPrefsChanged, 80L)
    }

    private val tick = object : Runnable {
        override fun run() {
            WeatherProvider.refreshAsync { refreshData() }
            refreshData()
            SurgeWidgetProvider.refreshAll(this@OverlayWidgetService)
            handler.postDelayed(this, cfg.refreshMin * 60_000L)
        }
    }
    private val expireOrder = Runnable { refreshData() }

    // оповещения
    private var lastAlertTier = 0
    private var alertInit = false

    // данные Яндекс Про (необязательные)
    private var lastPrice: String? = null
    private var lastDuration: String? = null
    private var orderZone: String? = null
    private var lastDest: String? = null
    private var lastOrderCoeff = 0.0
    private var lastRecordTime = 0L
    private var lastRecordCoeff = 0.0
    private var lastPrediction: RadarPrediction? = null
    private var orderAt = 0L

    // кэш точек радара
    private var blips: List<Blip> = emptyList()
    private var blipsAt = 0L
    private var blipsKey = ""

    override fun onCreate() {
        super.onCreate()
        RadarEngine.init(this)
        createChannel()
        startForegroundCompat()

        if (!Settings.canDrawOverlays(this)) {
            WidgetSettings.setOverlayOn(this, false)
            stopSelf()
            return
        }

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        tone = runCatching { ToneGenerator(AudioManager.STREAM_NOTIFICATION, 100) }.getOrNull()
        WidgetSettings.prefs(this).registerOnSharedPreferenceChangeListener(prefsListener)
        overlayReady = true
        buildWidget()
    }

    private fun closeByUser() {
        WidgetSettings.setOverlayOn(this, false)
        stopSelf()
    }

    private fun buildWidget() {
        widget?.let { old -> runCatching { wm.removeView(old) } }
        cfg = WidgetSettings.load(this)

        val view = RadarWidgetView(this, cfg)
        view.onClose = { closeByUser() }
        view.onOpenMap = {
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }

        val type = if (Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

        val (px0, py0) = WidgetSettings.loadPos(this)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = px0
            y = py0
        }

        view.setOnTouchListener(DragListener(params, view))
        wm.addView(view, params)
        widget = view
        view.bind(WidgetData.empty())

        handler.removeCallbacks(tick)
        handler.post(tick)
    }

    private inner class DragListener(
        private val lp: WindowManager.LayoutParams,
        private val target: View
    ) : View.OnTouchListener {
        private var sx = 0
        private var sy = 0
        private var tx = 0f
        private var ty = 0f
        private var downAt = 0L
        private var moved = false

        override fun onTouch(v: View?, e: MotionEvent): Boolean {
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = lp.x
                    sy = lp.y
                    tx = e.rawX
                    ty = e.rawY
                    downAt = SystemClock.uptimeMillis()
                    moved = false
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - tx
                    val dy = e.rawY - ty
                    if (abs(dx) > 10f || abs(dy) > 10f) moved = true
                    lp.x = sx + dx.toInt()
                    lp.y = sy + dy.toInt()
                    runCatching { wm.updateViewLayout(target, lp) }
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        WidgetSettings.savePos(this@OverlayWidgetService, lp.x, lp.y)
                    } else if (cfg.size == WidgetSettings.SIZE_SMALL &&
                        SystemClock.uptimeMillis() - downAt > 700L
                    ) {
                        closeByUser() // долгое нажатие закрывает малый виджет
                    }
                    return true
                }
            }
            return false
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        intent ?: return START_STICKY
        if (!overlayReady) return START_NOT_STICKY

        // Необязательные данные из Яндекс Про
        var touched = false
        intent.getStringExtra("PRICE")?.let { lastPrice = it; touched = true }
        intent.getStringExtra("DURATION")?.let { lastDuration = it; touched = true }
        intent.getStringExtra("ZONE")?.let { orderZone = it }
        intent.getStringExtra("DEST_NAME")?.let { lastDest = it; touched = true }

        val newCoeff = if (intent.hasExtra("COEFF")) intent.getDoubleExtra("COEFF", 0.0) else 0.0
        if (newCoeff > 0.0) {
            lastOrderCoeff = newCoeff
            touched = true
        }

        if (touched && lastOrderCoeff > 0.0) {
            val priceNum = lastPrice?.replace("[^0-9.]".toRegex(), "")?.toDoubleOrNull()
            val durationNum = lastDuration?.filter { it.isDigit() }?.toIntOrNull()
            val now = System.currentTimeMillis()
            val record = newCoeff > 0.0 &&
                (newCoeff != lastRecordCoeff || now - lastRecordTime > 10_000L)
            lastPrediction = if (record) {
                lastRecordTime = now
                lastRecordCoeff = newCoeff
                RadarEngine.record(this, lastOrderCoeff, priceNum, durationNum, orderZone)
            } else {
                RadarEngine.predict(lastOrderCoeff, orderZone, priceNum, durationNum)
            }
        }

        if (touched) {
            orderAt = System.currentTimeMillis()
            handler.removeCallbacks(expireOrder)
            handler.postDelayed(expireOrder, ORDER_TTL + 500L)
            refreshData()
        }
        return START_STICKY
    }

    private fun pinnedZone(): SurgeZone =
        MoscowRegionGrid.zones.firstOrNull { it.name == cfg.zone } ?: MoscowRegionGrid.zones.first()

    private fun refreshData() {
        val view = widget ?: return
        cfg = WidgetSettings.load(this)
        val zone = pinnedZone()
        val tariffs = cfg.enabledTariffs()
        val now = System.currentTimeMillis()

        val base = DemandModel.baseCoeff(zone, now)
        val rows = tariffs.map { t ->
            val c = DemandModel.scale(base, t)
            TariffRow(t.title, DemandModel.pct(c), DemandModel.waitMinutes(c))
        }
        val maxPct = DemandModel.maxPct(base, tariffs)

        val primary = tariffs.maxByOrNull { it.k }
        val history = primary?.let { DemandModel.forecast(zone, it, now, 13, 15 * 60_000L) } ?: emptyList()

        var label = if (tariffs.isEmpty()) "Включите тариф" else DemandModel.label(maxPct)
        if (tariffs.isNotEmpty()) {
            val next = DemandModel.maxPct(DemandModel.baseCoeff(zone, now + 30 * 60_000L, false), tariffs)
            if (next - maxPct >= 8) label += " ↗" else if (maxPct - next >= 8) label += " ↘"
        }

        // Данные заказа из Яндекс Про показываем недолго
        val orderFresh = orderAt > 0L && now - orderAt < ORDER_TTL
        val orderLine = if (orderFresh && (lastPrice != null || lastDuration != null))
            "Цена: ${lastPrice ?: "-- ₽"} • Время: ${lastDuration ?: "-- мин"}" else ""
        val destLine = if (orderFresh) lastDest?.let { name ->
            val dz = MoscowRegionGrid.zones.firstOrNull { it.name == name }
            if (dz != null) {
                val dp = DemandModel.maxPct(DemandModel.baseCoeff(dz, now), tariffs)
                "Финиш: $name • там +$dp%"
            } else "Финиш: $name"
        } ?: "" else ""
        val pred = lastPrediction
        val decision = if (orderFresh && pred != null) "${pred.decision} • ${pred.decisionScore}/100" else ""
        val decisionColor = when {
            pred == null -> Color.LTGRAY
            pred.decisionScore >= 75 -> 0xFF00E676.toInt()
            pred.decisionScore >= 55 -> 0xFFFFD740.toInt()
            else -> Color.LTGRAY
        }

        val data = WidgetData(
            zoneName = zone.name,
            rows = rows,
            label = label,
            history = history,
            blips = currentBlips(zone, tariffs),
            orderLine = orderLine,
            destLine = destLine,
            decision = decision,
            decisionColor = decisionColor
        )
        view.bind(data)

        val tier = when {
            maxPct >= 70 -> 3
            maxPct >= 40 -> 2
            maxPct >= 20 -> 1
            else -> 0
        }
        if (alertInit && tier > lastAlertTier) beep(tier >= 3)
        lastAlertTier = tier
        alertInit = true
    }

    private fun currentBlips(zone: SurgeZone, tariffs: List<Tariff>): List<Blip> {
        val now = SystemClock.uptimeMillis()
        val key = zone.name + "|" + tariffs.size
        if (now - blipsAt < 60_000L && blipsKey == key && blips.isNotEmpty()) return blips
        blips = computeBlips(zone, tariffs)
        blipsAt = now
        blipsKey = key
        return blips
    }

    private fun computeBlips(center: SurgeZone, tariffs: List<Tariff>): List<Blip> {
        val zones = MoscowRegionGrid.zones
        val near = zones.filter { it !== center }
            .sortedBy { MoscowRegionGrid.distanceKm(center.lat, center.lon, it.lat, it.lon) }
            .take(14)
        if (near.isEmpty()) return emptyList()
        val maxD = max(
            1.0,
            near.maxOf { MoscowRegionGrid.distanceKm(center.lat, center.lon, it.lat, it.lon) }
        )
        return near.map { z ->
            val dLat = z.lat - center.lat
            val dLon = (z.lon - center.lon) * cos(Math.toRadians(center.lat))
            val d = MoscowRegionGrid.distanceKm(center.lat, center.lon, z.lat, z.lon)
            val pct = DemandModel.maxPct(DemandModel.baseCoeff(z), tariffs)
            val color = when {
                pct >= 40 -> 0xFFFF5252.toInt()
                pct >= 15 -> 0xFFFFA726.toInt()
                else -> 0xFF4CAF50.toInt()
            }
            Blip(atan2(-dLat, dLon), (d / maxD).toFloat().coerceIn(0.15f, 1f), color)
        }
    }

    private fun beep(high: Boolean) {
        if (!cfg.sound) return
        runCatching {
            tone?.startTone(
                if (high) ToneGenerator.TONE_CDMA_HIGH_L else ToneGenerator.TONE_PROP_BEEP2,
                if (high) 500 else 250
            )
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Surge Radar", NotificationManager.IMPORTANCE_LOW
            )
            channel.description = "Виджет спроса поверх экрана"
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun startForegroundCompat() {
        val notification = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Радар кэфа работает")
            .setContentText("Показывает спрос по тарифам поверх экрана")
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        if (overlayReady) {
            WidgetSettings.prefs(this).unregisterOnSharedPreferenceChangeListener(prefsListener)
            widget?.let { v -> runCatching { wm.removeView(v) } }
        }
        tone?.release()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
