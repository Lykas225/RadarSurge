package com.surge.radar

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Единственный компактный виджет. Настраиваются: масштаб, размер и жирность шрифта,
 * прозрачность, набор элементов. Показывает спрос по всем включённым тарифам.
 */
class RadarWidgetView(context: Context, private val cfg: WidgetSettings.Values) : LinearLayout(context) {

    var onClose: (() -> Unit)? = null

    private val f = cfg.scale / 100f
    private val fk = cfg.fontPct / 100f
    private val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
    private val match = ViewGroup.LayoutParams.MATCH_PARENT

    private fun px(v: Float): Int = (v * resources.displayMetrics.density * f).roundToInt()

    private fun lp(w: Int, h: Int, weight: Float = 0f) = LinearLayout.LayoutParams(w, h, weight)

    private fun tv(t: String, size: Float, color: Int, strong: Boolean = false): TextView =
        TextView(context).apply {
            text = t
            setTextSize(TypedValue.COMPLEX_UNIT_SP, size * f * fk)
            setTextColor(color)
            typeface = weightTypeface(if (strong) min(900, cfg.fontWeight + 200) else cfg.fontWeight)
            includeFontPadding = false
            setPadding(0, px(1f), 0, px(1f))
        }

    private val title = tv("SurgeRadar", 13f, Color.WHITE, true)
    private val zoneView = tv("", 11f, 0xFF9FB4C0.toInt()).apply {
        maxLines = 1
        ellipsize = TextUtils.TruncateAt.END
    }
    private val rowsBox = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
    private val labelView = tv("", 12f, 0xFF8FF0E2.toInt())
    private val orderLine = tv("", 11f, Color.LTGRAY)
    private val decisionLine = tv("", 12f, Color.WHITE, true)
    private val radar = RadarView(context)
    private val logo = RadarView(context, false)
    private val spark = SparkView(context)

    private val close = tv("✕", 15f, 0xFFB0BEC5.toInt()).apply {
        setPadding(px(12f), px(2f), px(2f), px(2f))
        setOnClickListener { onClose?.invoke() }
    }

    init {
        orientation = LinearLayout.VERTICAL
        val bgA = (cfg.bgAlpha * 255 / 100).coerceIn(0, 255)
        background = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.argb(bgA, 16, 40, 58), Color.argb(bgA, 6, 13, 22))
        ).apply {
            cornerRadius = px(20f).toFloat()
            setStroke(px(1.2f).coerceAtLeast(1), Color.argb((bgA * 0.75f).toInt(), 64, 224, 208))
        }
        setPadding(px(12f), px(9f), px(12f), px(10f))
        alpha = cfg.widgetAlpha / 100f
        minimumWidth = px(190f)

        val header = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(logo, lp(px(15f), px(15f)))
            addView(title, lp(0, wrap, 1f).apply { leftMargin = px(6f) })
            addView(close)
        }
        addView(header, lp(match, wrap))
        addView(zoneView, lp(match, wrap).apply { topMargin = px(1f) })

        val mid = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        mid.addView(rowsBox, lp(0, wrap, 1f))
        if (cfg.showRadar) mid.addView(radar, lp(px(52f), px(52f)).apply { leftMargin = px(8f) })
        addView(mid, lp(match, wrap).apply { topMargin = px(5f) })

        if (cfg.showGraph) addView(spark, lp(match, px(24f)).apply { topMargin = px(4f) })
        addView(labelView, lp(match, wrap).apply { topMargin = px(3f) })
        if (cfg.showDecision) {
            addView(orderLine, lp(match, wrap).apply { topMargin = px(2f) })
            addView(decisionLine, lp(match, wrap))
        }
    }

    private fun makeRow(r: TariffRow): View {
        val row = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, px(2f), 0, px(2f))
        }
        row.addView(tv(r.name, 13f, Color.WHITE), lp(0, wrap, 1f))
        if (cfg.showDemand) {
            val color = DemandModel.textColor(r.pct)
            val pill = tv("+${r.pct}%", 13f, color, true).apply {
                gravity = Gravity.CENTER
                minWidth = px(46f)
                setPadding(px(7f), px(2f), px(7f), px(2f))
                background = rounded(withAlpha(color, 0.16f), px(9f).toFloat(), withAlpha(color, 0.6f), px(1f).coerceAtLeast(1))
            }
            row.addView(pill, lp(wrap, wrap).apply { leftMargin = px(8f) })
        }
        if (cfg.showWait) {
            val w = tv("~${r.waitMin} мин", 11.5f, 0xFFB7C6CF.toInt()).apply {
                gravity = Gravity.END
                minWidth = px(46f)
            }
            row.addView(w, lp(wrap, wrap).apply { leftMargin = px(8f) })
        }
        return row
    }

    fun bind(d: WidgetData) {
        zoneView.text = d.zoneName
        zoneView.visibility = if (d.zoneName.isBlank()) View.GONE else View.VISIBLE

        rowsBox.removeAllViews()
        if (d.rows.isEmpty()) {
            rowsBox.addView(tv("Тарифы выключены", 12f, Color.LTGRAY))
        } else {
            for (r in d.rows) rowsBox.addView(makeRow(r))
        }

        labelView.text = d.label
        radar.blips = d.blips
        spark.values = d.history
        setLine(orderLine, d.orderLine)
        setLine(decisionLine, d.decision)
        decisionLine.setTextColor(d.decisionColor)
    }

    private fun setLine(v: TextView, t: String) {
        v.text = t
        v.visibility = if (t.isBlank()) View.GONE else View.VISIBLE
    }
}
