package com.surge.radar

import android.content.Context
import android.content.SharedPreferences

object WidgetSettings {
    const val SIZE_SMALL = 0
    const val SIZE_MEDIUM = 1
    const val SIZE_LARGE = 2

    private const val PREFS = "widget_settings"
    private const val POS = "widget_pos"

    data class Values(
        val size: Int = SIZE_LARGE,
        val bgAlpha: Int = 85,
        val widgetAlpha: Int = 100,
        val scale: Int = 100,
        val showRadar: Boolean = true,
        val showGraph: Boolean = true,
        val showWait: Boolean = true,
        val showDecision: Boolean = true,
        val sound: Boolean = true
    )

    fun prefs(c: Context): SharedPreferences =
        c.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun load(c: Context): Values {
        val p = prefs(c)
        val d = Values()
        return Values(
            size = p.getInt("size", d.size).coerceIn(0, 2),
            bgAlpha = p.getInt("bg", d.bgAlpha).coerceIn(10, 100),
            widgetAlpha = p.getInt("alpha", d.widgetAlpha).coerceIn(30, 100),
            scale = p.getInt("scale", d.scale).coerceIn(70, 120),
            showRadar = p.getBoolean("radar", d.showRadar),
            showGraph = p.getBoolean("graph", d.showGraph),
            showWait = p.getBoolean("wait", d.showWait),
            showDecision = p.getBoolean("decision", d.showDecision),
            sound = p.getBoolean("sound", d.sound)
        )
    }

    fun save(c: Context, v: Values) {
        prefs(c).edit()
            .putInt("size", v.size)
            .putInt("bg", v.bgAlpha)
            .putInt("alpha", v.widgetAlpha)
            .putInt("scale", v.scale)
            .putBoolean("radar", v.showRadar)
            .putBoolean("graph", v.showGraph)
            .putBoolean("wait", v.showWait)
            .putBoolean("decision", v.showDecision)
            .putBoolean("sound", v.sound)
            .apply()
    }

    fun loadPos(c: Context): Pair<Int, Int> {
        val p = c.applicationContext.getSharedPreferences(POS, Context.MODE_PRIVATE)
        return Pair(p.getInt("x", 24), p.getInt("y", 170))
    }

    fun savePos(c: Context, x: Int, y: Int) {
        c.applicationContext.getSharedPreferences(POS, Context.MODE_PRIVATE)
            .edit().putInt("x", x).putInt("y", y).apply()
    }
}
