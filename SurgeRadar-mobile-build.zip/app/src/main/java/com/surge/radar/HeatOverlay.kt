package com.surge.radar

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Point
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.MotionEvent
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Overlay
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class HeatItem(val zone: SurgeZone, val pct: Int)

/** Тепловая карта спроса: светящиеся зоны с кольцами, выбранная зона и моё местоположение. */
class HeatOverlay(private val onZoneTap: (SurgeZone) -> Unit) : Overlay() {

    var items: List<HeatItem> = emptyList()
    var glow: Float = 0.7f
    var pulse: Float = 1f
    var pinned: SurgeZone? = null
    var myLocation: GeoPoint? = null

    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
        setShadowLayer(4f, 0f, 0f, Color.BLACK)
    }
    private val pinPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.WHITE
    }

    private fun withAlpha(color: Int, a: Float): Int =
        Color.argb((255f * a).toInt().coerceIn(0, 255), Color.red(color), Color.green(color), Color.blue(color))

    override fun draw(canvas: Canvas?, mapView: MapView?, shadow: Boolean) {
        if (shadow || canvas == null || mapView == null) return
        val density = mapView.context.resources.displayMetrics.density
        val proj = mapView.projection
        val pt = Point()
        val pt2 = Point()
        val showText = mapView.zoomLevelDouble >= 10.0
        textPaint.textSize = 12f * density
        ringPaint.strokeWidth = 1.5f * density

        for (item in items) {
            val z = item.zone
            proj.toPixels(GeoPoint(z.lat, z.lon), pt)
            proj.toPixels(GeoPoint(z.lat + z.radiusMeters / 111_320.0, z.lon), pt2)
            val r = abs(pt.y - pt2.y).toFloat()
            if (r < 3f) continue
            val x = pt.x.toFloat()
            val y = pt.y.toFloat()

            if (item.pct < 10) {
                dotPaint.color = withAlpha(0xFF2DD4BF.toInt(), 0.35f)
                canvas.drawCircle(x, y, min(r * 0.12f, 5f * density), dotPaint)
                continue
            }

            val color = DemandModel.heatColor(item.pct)
            val strength = glow * min(1f, 0.4f + item.pct / 100f)
            val rr = r * pulse
            glowPaint.shader = RadialGradient(
                x, y, rr,
                intArrayOf(withAlpha(color, 0.85f * strength), withAlpha(color, 0.45f * strength), withAlpha(color, 0f)),
                floatArrayOf(0f, 0.55f, 1f),
                Shader.TileMode.CLAMP
            )
            canvas.drawCircle(x, y, rr, glowPaint)
            ringPaint.color = withAlpha(color, 0.75f * strength)
            canvas.drawCircle(x, y, rr * 0.55f, ringPaint)
            ringPaint.color = withAlpha(color, 0.4f * strength)
            canvas.drawCircle(x, y, rr * 0.9f, ringPaint)

            if (showText) canvas.drawText("+${item.pct}%", x, y + 4f * density, textPaint)
        }
        glowPaint.shader = null

        pinned?.let { z ->
            proj.toPixels(GeoPoint(z.lat, z.lon), pt)
            val x = pt.x.toFloat()
            val y = pt.y.toFloat()
            pinPaint.strokeWidth = 2.5f * density
            canvas.drawCircle(x, y, 13f * density, pinPaint)
            dotPaint.color = 0xFF1FD1C0.toInt()
            canvas.drawCircle(x, y, 4f * density, dotPaint)
        }

        myLocation?.let { gp ->
            proj.toPixels(gp, pt)
            val x = pt.x.toFloat()
            val y = pt.y.toFloat()
            dotPaint.color = Color.WHITE
            canvas.drawCircle(x, y, 8f * density, dotPaint)
            dotPaint.color = 0xFF2979FF.toInt()
            canvas.drawCircle(x, y, 5.5f * density, dotPaint)
        }
    }

    override fun onSingleTapConfirmed(e: MotionEvent?, mapView: MapView?): Boolean {
        if (e == null || mapView == null) return false
        val gp = mapView.projection.fromPixels(e.x.toInt(), e.y.toInt())
        val z = MoscowRegionGrid.nearest(gp.latitude, gp.longitude)
        val d = MoscowRegionGrid.distanceKm(gp.latitude, gp.longitude, z.lat, z.lon)
        if (d <= max(3.0, z.radiusMeters / 1000.0 * 1.3)) {
            onZoneTap(z)
            return true
        }
        return false
    }
}
