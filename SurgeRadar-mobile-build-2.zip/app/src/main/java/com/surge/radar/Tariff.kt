package com.surge.radar

/** k — во сколько раз коэффициент тарифа «мягче», чем у Эконома. */
enum class Tariff(val title: String, val bit: Int, val k: Double) {
    ECONOM("Эконом", 1, 1.0),
    COMFORT("Комфорт", 2, 0.85),
    COMFORT_PLUS("Комфорт+", 4, 0.7)
}
