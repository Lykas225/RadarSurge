package com.surge.radar

import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.math.max
import kotlin.math.roundToInt

data class RouteEstimate(
    val distanceKm: Double,
    val durationMin: Int,
    val fromLat: Double,
    val fromLon: Double,
    val toLat: Double,
    val toLon: Double,
    val source: String
)

/**
 * Бесплатный расчёт расстояния и времени в пути по адресам А → Б без ключей и аккаунта пассажира:
 * Nominatim (OpenStreetMap) для координат + OSRM для автомобильного маршрута + поправка на пробки Москвы.
 */
object RouteEstimator {
    private val mainHandler = Handler(Looper.getMainLooper())
    private val geoCache = object : LinkedHashMap<String, Pair<Double, Double>>(128, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Pair<Double, Double>>?): Boolean =
            size > 120
    }

    /** Коэффициент дорожных пробок Москвы по времени суток (МСК). */
    fun moscowTrafficFactor(nowMs: Long = System.currentTimeMillis()): Double {
        val mins = DemandModel.mskMinutes(nowMs)
        val hour = mins / 60.0
        val day = Math.floorDiv(nowMs + 3 * 3_600_000L, 86_400_000L)
        val dow = Math.floorMod(day + 3L, 7L).toInt() // 0=Пн .. 6=Вс
        val weekend = dow >= 5
        return if (weekend) {
            when {
                hour < 8.0 -> 1.08
                hour < 12.0 -> 1.22
                hour < 19.0 -> 1.38
                hour < 22.0 -> 1.25
                else -> 1.12
            }
        } else {
            when {
                hour < 6.5 -> 1.08
                hour < 10.0 -> 1.65
                hour < 16.5 -> 1.38
                hour < 20.5 -> 1.75
                hour < 22.5 -> 1.28
                else -> 1.12
            }
        }
    }

    /** Средняя скорость по Москве (км/ч) для оценки недостающего параметра (время или км). */
    fun avgCitySpeedKmh(nowMs: Long = System.currentTimeMillis()): Double =
        (42.0 / moscowTrafficFactor(nowMs)).coerceIn(18.0, 46.0)

    fun estimateAsync(
        fromAddress: String,
        toAddress: String,
        onResult: (RouteEstimate?) -> Unit
    ) {
        if (fromAddress.isBlank() || toAddress.isBlank()) {
            mainHandler.post { onResult(null) }
            return
        }
        Thread {
            val res = runCatching { computeSync(fromAddress, toAddress) }.getOrNull()
            mainHandler.post { onResult(res) }
        }.start()
    }

    private fun computeSync(fromAddress: String, toAddress: String): RouteEstimate? {
        val fromPt = geocode(fromAddress) ?: return null
        val toPt = geocode(toAddress) ?: return null

        val osrm = fetchOsrm(fromPt.first, fromPt.second, toPt.first, toPt.second)
        val factor = moscowTrafficFactor()
        if (osrm != null) {
            val km = max(0.5, osrm.first)
            val min = max(3, (osrm.second * factor).roundToInt())
            return RouteEstimate(km, min, fromPt.first, fromPt.second, toPt.first, toPt.second, "маршрут OSRM")
        }

        // Резервный расчёт по прямой × коэффициент извилистости дорог (1.32)
        val airKm = MoscowRegionGrid.distanceKm(fromPt.first, fromPt.second, toPt.first, toPt.second)
        val roadKm = max(0.8, airKm * 1.32)
        val min = max(3, (roadKm / avgCitySpeedKmh() * 60.0).roundToInt())
        return RouteEstimate(roadKm, min, fromPt.first, fromPt.second, toPt.first, toPt.second, "оценка по карте")
    }

    private fun geocode(rawAddress: String): Pair<Double, Double>? {
        val normalized = normalizeQuery(rawAddress)
        synchronized(geoCache) {
            geoCache[normalized]?.let { return it }
        }
        val query = if (normalized.contains("москва", true) || normalized.contains("область", true)) {
            normalized
        } else {
            "Москва, $normalized"
        }
        val encoded = URLEncoder.encode(query, "UTF-8")
        val url = "https://nominatim.openstreetmap.org/search?format=json&limit=1&countrycodes=ru" +
            "&viewbox=36.5,56.3,38.8,55.1&q=$encoded"
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 3500
            readTimeout = 4000
            setRequestProperty("User-Agent", "SurgeRadar/3.0 (Android)")
            setRequestProperty("Accept-Language", "ru")
        }
        return try {
            if (conn.responseCode !in 200..299) return null
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            val arr = JSONArray(body)
            if (arr.length() == 0) return null
            val obj = arr.getJSONObject(0)
            val lat = obj.optString("lat").toDoubleOrNull() ?: return null
            val lon = obj.optString("lon").toDoubleOrNull() ?: return null
            val pair = lat to lon
            synchronized(geoCache) { geoCache[normalized] = pair }
            pair
        } finally {
            conn.disconnect()
        }
    }

    private fun fetchOsrm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Pair<Double, Double>? {
        val url = String.format(
            java.util.Locale.US,
            "https://router.project-osrm.org/route/v1/driving/%.5f,%.5f;%.5f,%.5f?overview=false",
            lon1, lat1, lon2, lat2
        )
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 3500
            readTimeout = 4000
            setRequestProperty("User-Agent", "SurgeRadar/3.0 (Android)")
        }
        return try {
            if (conn.responseCode !in 200..299) return null
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            val routes = JSONObject(body).optJSONArray("routes") ?: return null
            if (routes.length() == 0) return null
            val r = routes.getJSONObject(0)
            val km = r.optDouble("distance", 0.0) / 1000.0
            val min = r.optDouble("duration", 0.0) / 60.0
            if (km <= 0.0 || min <= 0.0) null else (km to min)
        } finally {
            conn.disconnect()
        }
    }

    private fun normalizeQuery(s: String): String =
        s.replace(Regex("\\s+"), " ").trim()
}
