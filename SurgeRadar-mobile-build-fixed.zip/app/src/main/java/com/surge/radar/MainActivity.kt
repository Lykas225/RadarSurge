package com.surge.radar

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Polygon
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var map: MapView
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Configuration.getInstance().userAgentValue = packageName
        RadarEngine.init(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(18, 18, 18))
        }

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 12, 12, 12)
        }

        val buttons = LinearLayout(this)
        val start = Button(this).apply {
            text = "Запустить радар"
            setOnClickListener { startRadar() }
        }
        val accessibility = Button(this).apply {
            text = "Доступ к Яндекс Про"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
        val overlay = Button(this).apply {
            text = "Разрешение окна"
            setOnClickListener {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            }
        }
        buttons.addView(start, LinearLayout.LayoutParams(0, -2, 1f))
        buttons.addView(accessibility, LinearLayout.LayoutParams(0, -2, 1f))
        buttons.addView(overlay, LinearLayout.LayoutParams(0, -2, 1f))

        status = TextView(this).apply {
            text = "⚡ Радар всплеска: анализирует рост, ускорение, аномалию и историю зоны.\nЧем больше реальных наблюдений — тем точнее прогноз."
            setTextColor(Color.WHITE)
            setPadding(12, 8, 12, 8)
        }

        map = MapView(this).apply {
            setTileSource(TileSourceFactory.MAPNIK)
            setMultiTouchControls(true)
            controller.setZoom(10.5)
            controller.setCenter(GeoPoint(55.75, 37.62))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
            )
        }

        bar.addView(buttons)
        bar.addView(status)
        root.addView(bar)
        root.addView(map)
        setContentView(root)

        renderZones()
        requestNotificationPermission()
    }

    private fun startRadar() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Сначала разрешите окно поверх других приложений", Toast.LENGTH_LONG).show()
            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
            )
            return
        }
        OverlayWidgetService.start(this)
        Toast.makeText(this, "Радар запущен", Toast.LENGTH_SHORT).show()
    }

    private fun renderZones() {
        map.overlays.clear()

        for (zone in MoscowRegionGrid.zones) {
            val prediction = RadarEngine.predict(1.0, zone.name)
            if (prediction.confidence < 25) continue

            val risk = prediction.probability
            val fill = when {
                risk >= 80 -> Color.argb(110, 170, 0, 255)
                risk >= 60 -> Color.argb(100, 255, 87, 34)
                risk >= 40 -> Color.argb(90, 255, 193, 7)
                else -> Color.argb(70, 0, 200, 83)
            }

            val polygon = Polygon(map).apply {
                points = Polygon.pointsAsCircle(
                    GeoPoint(zone.lat, zone.lon), zone.radiusMeters
                )
                fillPaint.color = fill
                outlinePaint.color = Color.argb(180, 255, 255, 255)
                outlinePaint.strokeWidth = 2f
                title = String.format(
                    Locale.US,
                    "%s\nРиск всплеска: %d%%\n5 мин: ×%.1f\n10 мин: ×%.1f\nУверенность: %d%%",
                    zone.name,
                    risk,
                    prediction.forecast5,
                    prediction.forecast10,
                    prediction.confidence
                )
            }
            map.overlays.add(polygon)
        }

        map.invalidate()
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                77
            )
        }
    }

    override fun onResume() {
        super.onResume()
        if (::map.isInitialized) {
            renderZones()
        }
    }
}
