package com.surge.radar

import android.graphics.Color
import kotlin.math.PI
import kotlin.math.sin
import kotlin.random.Random

data class Blip(val angle: Double, val dist: Float, val color: Int)

data class WidgetData(
    val demandText: String,
    val demandColor: Int,
    val waitText: String,
    val label: String,
    val history: List<Double>,
    val blips: List<Blip>,
    val orderLine: String,
    val destLine: String,
    val decision: String,
    val decisionColor: Int
) {
    companion object {
        fun empty() = WidgetData(
            "+0%", 0xFFB0BEC5.toInt(), "—", "Ожидание данных",
            emptyList(), emptyList(), "", "", "", Color.LTGRAY
        )

        fun sample(): WidgetData {
            val rnd = Random(7)
            val colors = listOf(0xFFFF5252.toInt(), 0xFFFFA726.toInt(), 0xFF4CAF50.toInt())
            return WidgetData(
                "+45%", 0xFF69F0AE.toInt(), "~4 мин", "Пиковая активность",
                List(40) { 1.2 + 0.25 * sin(it / 3.0) + rnd.nextDouble() * 0.12 },
                List(12) { Blip(rnd.nextDouble() * 2 * PI, 0.2f + rnd.nextFloat() * 0.75f, colors.random(rnd)) },
                "Цена: 450 ₽ • Время: 12 мин",
                "Финиш: Жулебино • там ×1.8",
                "МОЖНО БРАТЬ • 62/100", 0xFFFFD740.toInt()
            )
        }
    }
}
