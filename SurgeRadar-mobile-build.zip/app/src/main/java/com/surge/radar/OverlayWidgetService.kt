package com.surge.radar

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.PixelFormat
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import java.util.Locale
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.roundToInt

class OverlayWidgetService : Service() {

    companion object {
        const val ACTION_UPDATE = "com.surge.radar.UPDATE"
        const val CHANNEL_ID = "surge_radar"
        const val NOTIFICATION_ID = 1001

        fun start(context: Context) {
            val intent = Intent(context, OverlayWidgetService::class.java)
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(intent)
            else context.startService(intent)
        }
    }

    private lateinit var wm: WindowManager
    private var widget: RadarWidgetView? = null
    private var cfg = WidgetSettings.Values()
    private var overlayReady = false
    private var tone: ToneGenerator? = null

    private val handler = Handler(Looper.getMainLooper())
    private val rebuild = Runnable { buildWidget() }
    private val prefsListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        handler.removeCallbacks(rebuild)
        handler.postDelayed(rebuild, 80L)
    }

    private var lastAlertTier = 0
    private var lastCoeff = 1.0
    private var lastRecordTime = 0L
    private var lastRecordCoeff = 0.0
    private var lastPrice: String? = null
    private var lastDuration: String? = null
    private var lastZone: String? = null
    private var lastDest: String? = null
    private var lastDestCoeff = -1.0
    private var lastData: WidgetData? = null

    private var blips: List<Blip> = emptyList()
    private var blipsAt = 0L
    private var blipsZone: String? = null

    override fun onCreate() {
        super.onCreate()
        RadarEngine.init(this)
        createChannel()
        startForegroundCompat()

        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        tone = runCatching { ToneGenerator(AudioManager.STREAM_NOTIFICATION, 100) }.getOrNull()
        WidgetSettings.prefs(this).registerOnSharedPreferenceChangeListener(prefsListener)
        overlayReady = true
        buildWidget()
    }

    private fun buildWidget() {
        widget?.let { old -> runCatching { wm.removeView(old) } }
        cfg = WidgetSettings.load(this)

        val view = RadarWidgetView(this, cfg)
        view.onClose = { stopSelf() }
        view.onOpenMap = {
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }

        val type = if (Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

        val (px0, py0) = WidgetSettings.loadPos(this)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = px0
            y = py0
        }

        view.setOnTouchListener(DragListener(params, view))
        wm.addView(view, params)
        widget = view
        view.bind(lastData ?: WidgetData.empty())
    }

    private inner class DragListener(
        private val lp: WindowManager.LayoutParams,
        private val target: View
    ) : View.OnTouchListener {
        private var sx = 0
        private var sy = 0
        private var tx = 0f
        private var ty = 0f
        private var downAt = 0L
        private var moved = false

        override fun onTouch(v: View?, e: MotionEvent): Boolean {
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = lp.x
                    sy = lp.y
                    tx = e.rawX
                    ty = e.rawY
                    downAt = SystemClock.uptimeMillis()
                    moved = false
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - tx
                    val dy = e.rawY - ty
                    if (abs(dx) > 10f || abs(dy) > 10f) moved = true
                    lp.x = sx + dx.toInt()
                    lp.y = sy + dy.toInt()
                    runCatching { wm.updateViewLayout(target, lp) }
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        WidgetSettings.savePos(this@OverlayWidgetService, lp.x, lp.y)
                    } else if (cfg.size == WidgetSettings.SIZE_SMALL &&
                        SystemClock.uptimeMillis() - downAt > 700L
                    ) {
                        stopSelf() // долгое нажатие закрывает малый виджет
                    }
                    return true
                }
            }
            return false
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        intent ?: return START_STICKY
        if (!overlayReady) return START_NOT_STICKY

        val coeff = if (intent.hasExtra("COEFF"))
            intent.getDoubleExtra("COEFF", lastCoeff) else lastCoeff
        lastCoeff = coeff

        intent.getStringExtra("PRICE")?.let { lastPrice = it }
        intent.getStringExtra("DURATION")?.let { lastDuration = it }
        intent.getStringExtra("ZONE")?.let { lastZone = it }
        intent.getStringExtra("DEST_NAME")?.let {
            lastDest = it
            lastDestCoeff = intent.getDoubleExtra("DEST_COEFF", -1.0)
        }

        val priceNum = lastPrice?.replace("[^0-9.]".toRegex(), "")?.toDoubleOrNull()
        val durationNum = lastDuration?.filter { it.isDigit() }?.toIntOrNull()

        // Пишем в историю только реальные новые наблюдения кэфа
        val now = System.currentTimeMillis()
        val shouldRecord = intent.hasExtra("COEFF") &&
            (coeff != lastRecordCoeff || now - lastRecordTime > 10_000L)
        val p = if (shouldRecord) {
            lastRecordTime = now
            lastRecordCoeff = coeff
            RadarEngine.record(this, coeff, priceNum, durationNum, lastZone)
        } else {
            RadarEngine.predict(coeff, lastZone, priceNum, durationNum)
        }

        val data = makeData(p)
        lastData = data
        widget?.bind(data)

        val tier = when {
            p.probability >= 80 -> 3
            p.probability >= 60 -> 2
            p.probability >= 40 -> 1
            else -> 0
        }
        if (tier > lastAlertTier) {
            beep(tier >= 3)
            lastAlertTier = tier
        }
        if (tier == 0) lastAlertTier = 0

        return START_STICKY
    }

    private fun makeData(p: RadarPrediction): WidgetData {
        val pct = ((lastCoeff - 1.0) * 100.0).roundToInt().coerceAtLeast(0)
        val demandColor = when {
            pct >= 100 -> 0xFFE040FB.toInt()
            pct >= 60 -> 0xFFFF7043.toInt()
            pct >= 20 -> 0xFF69F0AE.toInt()
            else -> 0xFFB0BEC5.toInt()
        }
        val label = when {
            p.probability >= 80 -> "Пиковая активность"
            p.probability >= 60 -> "Высокий спрос"
            p.probability >= 40 -> "Растущий спрос"
            else -> "Спокойно"
        }
        val order = if (lastPrice != null || lastDuration != null)
            "Цена: ${lastPrice ?: "-- ₽"} • Время: ${lastDuration ?: "-- мин"}" else ""
        val dest = lastDest?.let { n ->
            if (lastDestCoeff >= 0)
                String.format(Locale.US, "Финиш: %s • там ×%.1f", n, lastDestCoeff)
            else "Финиш: $n"
        } ?: ""
        val decisionColor = when {
            p.decisionScore >= 75 -> 0xFF00E676.toInt()
            p.decisionScore >= 55 -> 0xFFFFD740.toInt()
            else -> Color.LTGRAY
        }
        return WidgetData(
            demandText = "+$pct%",
            demandColor = demandColor,
            waitText = lastDuration?.let { "~$it" } ?: "—",
            label = label,
            history = RadarEngine.history(40, lastZone),
            blips = currentBlips(),
            orderLine = order,
            destLine = dest,
            decision = "${p.decision} • ${p.decisionScore}/100",
            decisionColor = decisionColor
        )
    }

    private fun currentBlips(): List<Blip> {
        val now = SystemClock.uptimeMillis()
        if (now - blipsAt < 2500L && blipsZone == lastZone && blips.isNotEmpty()) return blips
        blips = computeBlips(lastZone)
        blipsAt = now
        blipsZone = lastZone
        return blips
    }

    private fun computeBlips(zoneName: String?): List<Blip> {
        val zones = MoscowRegionGrid.zones
        val center = zones.firstOrNull { it.name == zoneName } ?: zones.first()
        val near = zones.filter { it !== center }
            .sortedBy { MoscowRegionGrid.distanceKm(center.lat, center.lon, it.lat, it.lon) }
            .take(14)
        if (near.isEmpty()) return emptyList()
        val maxD = max(
            1.0,
            near.maxOf { MoscowRegionGrid.distanceKm(center.lat, center.lon, it.lat, it.lon) }
        )
        return near.map { z ->
            val dLat = z.lat - center.lat
            val dLon = (z.lon - center.lon) * cos(Math.toRadians(center.lat))
            val d = MoscowRegionGrid.distanceKm(center.lat, center.lon, z.lat, z.lon)
            val prob = RadarEngine.predict(RadarEngine.latestCoeff(z.name) ?: 1.0, z.name).probability
            val color = when {
                prob >= 65 -> 0xFFFF5252.toInt()
                prob >= 40 -> 0xFFFFA726.toInt()
                else -> 0xFF4CAF50.toInt()
            }
            Blip(atan2(-dLat, dLon), (d / maxD).toFloat().coerceIn(0.15f, 1f), color)
        }
    }

    private fun beep(high: Boolean) {
        if (!cfg.sound) return
        runCatching {
            tone?.startTone(
                if (high) ToneGenerator.TONE_CDMA_HIGH_L else ToneGenerator.TONE_PROP_BEEP2,
                if (high) 500 else 250
            )
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Surge Radar", NotificationManager.IMPORTANCE_LOW
            )
            channel.description = "Постоянная работа радара поверх Яндекс Про"
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun startForegroundCompat() {
        val notification = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Радар кэфа работает")
            .setContentText("Считывает данные Яндекс Про и прогнозирует всплески")
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(rebuild)
        if (overlayReady) {
            WidgetSettings.prefs(this).unregisterOnSharedPreferenceChangeListener(prefsListener)
            widget?.let { v -> runCatching { wm.removeView(v) } }
        }
        tone?.release()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
