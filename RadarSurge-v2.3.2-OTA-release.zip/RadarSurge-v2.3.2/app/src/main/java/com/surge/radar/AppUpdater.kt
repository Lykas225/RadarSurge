package com.surge.radar

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Обновление приложения по воздуху (OTA) через GitHub Releases.
 * Поддерживает публичные репозитории без токена и приватные с GitHub Token.
 */
object AppUpdater {
    const val DEFAULT_REPO = "Lykas225/RadarSurge"
    private const val PREFS = "ota_updater"
    private const val AUTO_CHECK_INTERVAL_MS = 6 * 3_600_000L

    data class ReleaseInfo(
        val tag: String,
        val version: String,
        val title: String,
        val notes: String,
        val htmlUrl: String,
        val assetName: String,
        val browserDownloadUrl: String,
        val apiAssetUrl: String,
        val sizeBytes: Long
    )

    private val mainHandler = Handler(Looper.getMainLooper())
    private val checking = AtomicBoolean(false)
    private val downloading = AtomicBoolean(false)

    private fun prefs(c: Context) =
        c.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun repo(c: Context): String =
        prefs(c).getString("repo", DEFAULT_REPO)?.trim().orEmpty().ifBlank { DEFAULT_REPO }

    fun setRepo(c: Context, value: String) {
        val cleaned = value.trim()
            .removePrefix("https://github.com/")
            .removePrefix("http://github.com/")
            .removeSuffix("/")
            .removeSuffix(".git")
            .ifBlank { DEFAULT_REPO }
        prefs(c).edit().putString("repo", cleaned).apply()
    }

    fun token(c: Context): String =
        prefs(c).getString("token", "")?.trim().orEmpty()

    fun setToken(c: Context, value: String) {
        prefs(c).edit().putString("token", value.trim()).apply()
    }

    fun isAutoCheck(c: Context): Boolean =
        prefs(c).getBoolean("auto_check", true)

    fun setAutoCheck(c: Context, on: Boolean) {
        prefs(c).edit().putBoolean("auto_check", on).apply()
    }

    fun statusLine(c: Context): String {
        val p = prefs(c)
        val status = p.getString("last_status", "") ?: ""
        val at = p.getLong("last_check_at", 0L)
        if (at <= 0L) return "Проверка ещё не выполнялась"
        val time = SimpleDateFormat("dd.MM HH:mm", Locale.getDefault()).format(Date(at))
        return if (status.isBlank()) "Проверено: $time" else "$status ($time)"
    }

    private fun saveStatus(c: Context, text: String) {
        prefs(c).edit()
            .putString("last_status", text)
            .putLong("last_check_at", System.currentTimeMillis())
            .apply()
    }

    @Suppress("DEPRECATION")
    private fun packageInfo(c: Context): PackageInfo =
        if (Build.VERSION.SDK_INT >= 33) {
            c.packageManager.getPackageInfo(c.packageName, PackageManager.PackageInfoFlags.of(0L))
        } else {
            c.packageManager.getPackageInfo(c.packageName, 0)
        }

    fun currentVersionName(c: Context): String =
        runCatching { packageInfo(c).versionName ?: "0.0.0" }.getOrDefault("0.0.0")

    @Suppress("DEPRECATION")
    fun currentVersionCode(c: Context): Long = runCatching {
        val info = packageInfo(c)
        if (Build.VERSION.SDK_INT >= 28) info.longVersionCode else info.versionCode.toLong()
    }.getOrDefault(0L)

    fun currentVersionLabel(c: Context): String =
        "v${currentVersionName(c)} (сборка ${currentVersionCode(c)})"

    /** Сравнение версий вида v2.3.2 / 2.4.0-ota. */
    fun isNewerVersion(remote: String, current: String): Boolean {
        val r = parseVersionParts(remote)
        val cur = parseVersionParts(current)
        if (r.isEmpty()) return false
        val maxLen = maxOf(r.size, cur.size)
        for (i in 0 until maxLen) {
            val rv = r.getOrElse(i) { 0 }
            val cv = cur.getOrElse(i) { 0 }
            if (rv != cv) return rv > cv
        }
        return false
    }

    private fun parseVersionParts(raw: String): List<Int> {
        val match = Regex("(\d+(?:\.\d+)*)").find(raw.trim()) ?: return emptyList()
        return match.groupValues[1].split('.').mapNotNull { it.toIntOrNull() }
    }

    fun checkOnStartup(activity: Activity) {
        if (!isAutoCheck(activity)) return
        val lastAt = prefs(activity).getLong("last_check_at", 0L)
        if (System.currentTimeMillis() - lastAt < AUTO_CHECK_INTERVAL_MS) return
        checkForUpdates(activity, manual = false)
    }

    fun checkForUpdates(activity: Activity, manual: Boolean, onDone: (() -> Unit)? = null) {
        if (!checking.compareAndSet(false, true)) {
            if (manual) Toast.makeText(activity, "Проверка обновлений уже идёт…", Toast.LENGTH_SHORT).show()
            return
        }
        val app = activity.applicationContext
        val repository = repo(app)
        val authToken = token(app)
        val installed = currentVersionName(app)

        Thread {
            try {
                val release = fetchLatestRelease(repository, authToken)
                val newer = isNewerVersion(release.version, installed)
                if (!newer) {
                    cleanOldApks(app)
                    saveStatus(app, "Установлена актуальная версия v$installed")
                    mainHandler.post {
                        onDone?.invoke()
                        if (manual && isActivityAlive(activity)) {
                            Toast.makeText(
                                activity,
                                "У вас последняя версия (v$installed)",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                    return@Thread
                }

                saveStatus(app, "Доступна версия ${release.tag}")
                val skipped = prefs(app).getString("skipped_tag", "") ?: ""
                mainHandler.post {
                    onDone?.invoke()
                    if (!isActivityAlive(activity)) return@post
                    if (!manual && skipped == release.tag) return@post
                    showUpdateDialog(activity, release, installed)
                }
            } catch (e: Exception) {
                val msg = e.message ?: "Ошибка сети"
                saveStatus(app, msg)
                mainHandler.post {
                    onDone?.invoke()
                    if (manual && isActivityAlive(activity)) {
                        Toast.makeText(activity, msg, Toast.LENGTH_LONG).show()
                    }
                }
            } finally {
                checking.set(false)
            }
        }.start()
    }

    private fun fetchLatestRelease(repository: String, authToken: String): ReleaseInfo {
        val apiUrl = "https://api.github.com/repos/$repository/releases/latest"
        val conn = (URL(apiUrl).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 10_000
            readTimeout = 10_000
            setRequestProperty("Accept", "application/vnd.github+json")
            setRequestProperty("User-Agent", "SurgeRadar-Android")
            if (authToken.isNotBlank()) setRequestProperty("Authorization", "Bearer $authToken")
        }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        conn.disconnect()

        if (code == 404) {
            throw IllegalStateException(
                if (authToken.isBlank()) {
                    "Релиз не найден (404). Опубликуйте релиз или укажите токен для приватного репозитория."
                } else {
                    "Релиз не найден в $repository (404)."
                }
            )
        }
        if (code == 401 || code == 403) {
            throw IllegalStateException("Нет доступа к GitHub API ($code). Проверьте токен или лимит запросов.")
        }
        if (code !in 200..299) {
            throw IllegalStateException("Ошибка GitHub API: HTTP $code")
        }

        val json = JSONObject(body)
        val tag = json.optString("tag_name", "").trim()
        val title = json.optString("name", "").trim().ifBlank { tag }
        val notes = json.optString("body", "").trim()
        val htmlUrl = json.optString("html_url", "https://github.com/$repository/releases")
        val assets = json.optJSONArray("assets")

        var bestAsset: JSONObject? = null
        if (assets != null) {
            for (i in 0 until assets.length()) {
                val a = assets.optJSONObject(i) ?: continue
                val name = a.optString("name", "")
                if (!name.endsWith(".apk", ignoreCase = true)) continue
                if (bestAsset == null || name.contains("release", ignoreCase = true)) {
                    bestAsset = a
                }
            }
        }
        if (bestAsset == null) {
            throw IllegalStateException("В релизе $tag не найден APK-файл")
        }
        val version = tag.removePrefix("v").removePrefix("V").ifBlank { title }
        return ReleaseInfo(
            tag = tag.ifBlank { "v$version" },
            version = version,
            title = title,
            notes = notes,
            htmlUrl = htmlUrl,
            assetName = bestAsset.optString("name", "SurgeRadar.apk"),
            browserDownloadUrl = bestAsset.optString("browser_download_url", ""),
            apiAssetUrl = bestAsset.optString("url", ""),
            sizeBytes = bestAsset.optLong("size", -1L)
        )
    }

    private fun showUpdateDialog(activity: Activity, release: ReleaseInfo, installed: String) {
        val sizeText = if (release.sizeBytes > 0L) {
            String.format(Locale.US, "%.1f МБ", release.sizeBytes / (1024.0 * 1024.0))
        } else ""
        val notesBlock = release.notes.take(700).let { if (it.isBlank()) "" else "

Что нового:
$it" }
        val msg = buildString {
            append("Доступна новая версия ${release.tag}")
            if (sizeText.isNotBlank()) append(" ($sizeText)")
            append("
Установлена: v$installed")
            append(notesBlock)
            append("

Приложение скачает APK и откроет системное окно обновления поверх текущей версии.")
        }
        AlertDialog.Builder(activity)
            .setTitle("Обновление Радар Кэфа МСК")
            .setMessage(msg)
            .setPositiveButton("Обновить сейчас") { _, _ ->
                downloadAndInstall(activity, release)
            }
            .setNegativeButton("Позже", null)
            .setNeutralButton("Пропустить") { _, _ ->
                prefs(activity).edit().putString("skipped_tag", release.tag).apply()
            }
            .show()
    }

    private fun downloadAndInstall(activity: Activity, release: ReleaseInfo) {
        if (!downloading.compareAndSet(false, true)) {
            Toast.makeText(activity, "Загрузка обновления уже выполняется…", Toast.LENGTH_SHORT).show()
            return
        }
        val app = activity.applicationContext
        val authToken = token(app)
        val cancelled = AtomicBoolean(false)

        val d = activity.resources.displayMetrics.density
        val pad = (20 * d).toInt()
        val box = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, (14 * d).toInt(), pad, (8 * d).toInt())
        }
        val label = TextView(activity).apply {
            text = "Подготовка загрузки ${release.assetName}…"
            textSize = 14f
        }
        val bar = ProgressBar(activity, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            isIndeterminate = true
        }
        box.addView(label, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        box.addView(
            bar,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = (12 * d).toInt()
            }
        )

        val dialog = AlertDialog.Builder(activity)
            .setTitle("Загрузка ${release.tag}")
            .setView(box)
            .setCancelable(false)
            .setNegativeButton("Отмена") { _, _ -> cancelled.set(true) }
            .create()
        dialog.show()

        Thread {
            try {
                val updatesDir = File(app.cacheDir, "updates").apply { mkdirs() }
                cleanOldApks(app)
                val safeTag = release.tag.replace(Regex("[^A-Za-z0-9._-]"), "_")
                val partFile = File(updatesDir, "SurgeRadar-$safeTag.apk.part")
                val apkFile = File(updatesDir, "SurgeRadar-$safeTag.apk")

                // Для приватного репозитория скачиваем через GitHub Assets API с Accept: application/octet-stream
                val useApiAsset = authToken.isNotBlank() && release.apiAssetUrl.isNotBlank()
                val startUrl = if (useApiAsset) release.apiAssetUrl else release.browserDownloadUrl
                if (startUrl.isBlank()) throw IllegalStateException("Пустая ссылка на APK")

                val conn = openWithRedirects(startUrl, authToken, useApiAsset)
                val total = conn.contentLengthLong.let { if (it > 0L) it else release.sizeBytes }
                var downloaded = 0L
                val buf = ByteArray(16 * 1024)
                var lastUiAt = 0L

                conn.inputStream.use { input ->
                    FileOutputStream(partFile).use { output ->
                        while (true) {
                            if (cancelled.get()) throw InterruptedException("Загрузка отменена")
                            val read = input.read(buf)
                            if (read <= 0) break
                            output.write(buf, 0, read)
                            downloaded += read
                            val now = System.currentTimeMillis()
                            if (now - lastUiAt >= 120L) {
                                lastUiAt = now
                                val pct = if (total > 0L) ((downloaded * 100L) / total).toInt().coerceIn(0, 100) else -1
                                val mb = downloaded / (1024.0 * 1024.0)
                                val totalMb = if (total > 0L) total / (1024.0 * 1024.0) else 0.0
                                mainHandler.post {
                                    if (!dialog.isShowing) return@post
                                    if (pct >= 0) {
                                        bar.isIndeterminate = false
                                        bar.progress = pct
                                        label.text = String.format(Locale.US, "Загружено %.1f из %.1f МБ (%d%%)", mb, totalMb, pct)
                                    } else {
                                        label.text = String.format(Locale.US, "Загружено %.1f МБ…", mb)
                                    }
                                }
                            }
                        }
                    }
                }
                conn.disconnect()

                if (!isValidApkFile(partFile)) {
                    partFile.delete()
                    throw IllegalStateException("Скачанный файл повреждён или не является APK")
                }
                if (apkFile.exists()) apkFile.delete()
                if (!partFile.renameTo(apkFile)) {
                    partFile.copyTo(apkFile, overwrite = true)
                    partFile.delete()
                }

                mainHandler.post {
                    runCatching { if (dialog.isShowing) dialog.dismiss() }
                    if (isActivityAlive(activity)) {
                        installApk(activity, apkFile)
                    }
                }
            } catch (e: InterruptedException) {
                mainHandler.post {
                    runCatching { if (dialog.isShowing) dialog.dismiss() }
                    if (isActivityAlive(activity)) {
                        Toast.makeText(activity, "Загрузка отменена", Toast.LENGTH_SHORT).show()
                    }
                }
            } catch (e: Exception) {
                mainHandler.post {
                    runCatching { if (dialog.isShowing) dialog.dismiss() }
                    if (isActivityAlive(activity)) {
                        Toast.makeText(
                            activity,
                            "Ошибка загрузки: ${e.message ?: "проверьте интернет"}",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
            } finally {
                downloading.set(false)
            }
        }.start()
    }

    private fun openWithRedirects(initialUrl: String, authToken: String, octetStream: Boolean): HttpURLConnection {
        var current = initialUrl
        for (hop in 0 until 8) {
            val url = URL(current)
            val isGithubHost = url.host.equals("api.github.com", true) || url.host.equals("github.com", true)
            val conn = (url.openConnection() as HttpURLConnection).apply {
                instanceFollowRedirects = false
                requestMethod = "GET"
                connectTimeout = 15_000
                readTimeout = 30_000
                setRequestProperty("User-Agent", "SurgeRadar-Android")
                if (isGithubHost && authToken.isNotBlank()) {
                    setRequestProperty("Authorization", "Bearer $authToken")
                }
                if (isGithubHost && octetStream) {
                    setRequestProperty("Accept", "application/octet-stream")
                }
            }
            val code = conn.responseCode
            if (code == 301 || code == 302 || code == 303 || code == 307 || code == 308) {
                val loc = conn.getHeaderField("Location")
                conn.disconnect()
                if (loc.isNullOrBlank()) throw IllegalStateException("Некорректный редирект HTTP $code")
                current = URL(url, loc).toString()
                continue
            }
            if (code !in 200..299) {
                conn.disconnect()
                throw IllegalStateException("Сервер вернул HTTP $code")
            }
            return conn
        }
        throw IllegalStateException("Слишком много перенаправлений при загрузке APK")
    }

    private fun isValidApkFile(file: File): Boolean {
        if (!file.exists() || file.length() < 100_000L) return false
        val header = ByteArray(2)
        val read = file.inputStream().use { it.read(header) }
        return read == 2 && header[0] == 0x50.toByte() && header[1] == 0x4B.toByte()
    }

    private fun cleanOldApks(c: Context) {
        val dir = File(c.cacheDir, "updates")
        dir.listFiles()?.forEach { runCatching { it.delete() } }
    }

    fun tryFinishPendingInstall(activity: Activity) {
        val path = prefs(activity).getString("pending_apk_path", null) ?: return
        val file = File(path)
        if (!file.exists()) {
            prefs(activity).edit().remove("pending_apk_path").apply()
            return
        }
        if (activity.packageManager.canRequestPackageInstalls()) {
            prefs(activity).edit().remove("pending_apk_path").apply()
            installApk(activity, file)
        }
    }

    private fun installApk(activity: Activity, apkFile: File) {
        if (!activity.packageManager.canRequestPackageInstalls()) {
            prefs(activity).edit().putString("pending_apk_path", apkFile.absolutePath).apply()
            AlertDialog.Builder(activity)
                .setTitle("Разрешите установку обновлений")
                .setMessage(
                    "Чтобы установить скачанное обновление, включите переключатель «Установка неизвестных приложений» для «Радар Кэфа МСК» и вернитесь назад."
                )
                .setPositiveButton("Открыть настройки") { _, _ ->
                    val intent = Intent(
                        Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                        Uri.parse("package:${activity.packageName}")
                    )
                    runCatching { activity.startActivity(intent) }
                }
                .setNeutralButton("Установить") { _, _ -> installApk(activity, apkFile) }
                .setNegativeButton("Позже", null)
                .show()
            return
        }

        val uri = FileProvider.getUriForFile(activity, "${activity.packageName}.fileprovider", apkFile)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        val res = runCatching { activity.startActivity(intent) }
        if (res.isFailure) {
            Toast.makeText(activity, "Не удалось открыть установщик APK", Toast.LENGTH_LONG).show()
        }
    }

    private fun isActivityAlive(activity: Activity): Boolean =
        !activity.isFinishing && !activity.isDestroyed
}
