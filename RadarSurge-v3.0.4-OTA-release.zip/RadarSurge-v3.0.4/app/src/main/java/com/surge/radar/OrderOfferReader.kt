package com.surge.radar

import android.content.Context
import android.content.Intent
import android.net.Uri
import java.net.URLEncoder
import java.util.Locale
import java.util.regex.Pattern
import kotlin.math.roundToInt

/** Распознанная входящая карточка заказа Яндекс Про (только чтение, без нажатий). */
data class OrderOffer(
    val from: String,
    val to: String,
    val priceRub: Int?,
    val tariff: OrderTariff,
    val surgeCoeff: Double?,
    val surgeBonusRub: Int,
    val pickupMin: Int?,
    val pickupKm: Double?,
    val tripMin: Int?,
    val tripKm: Double?,
    val raw: String,
    val capturedAt: Long
)

object OrderOfferReader {
    private const val SAME_OFFER_COOLDOWN_MS = 20_000L

    private val bonusMoney = Pattern.compile(
        "\\+\\s*(\\d{2,4})\\s*(?:₽|руб(?:\\.|лей|ля)?)",
        Pattern.CASE_INSENSITIVE or Pattern.UNICODE_CASE
    )
    private val priceMoney = Pattern.compile(
        "(?<![+\\d])(\\d{1,3}(?:[\\s\\u00A0]\\d{3})+|\\d{2,5})\\s*(?:₽|руб(?:\\.|лей|ля)?)(?!\\w)",
        Pattern.CASE_INSENSITIVE or Pattern.UNICODE_CASE
    )
    private val coeffPattern = Pattern.compile(
        "(?:×|x|х)\\s*([1-4](?:[.,][0-9]{1,2})?)",
        Pattern.CASE_INSENSITIVE or Pattern.UNICODE_CASE
    )
    private val hourMinPattern = Pattern.compile(
        "(\\d{1,2})\\s*ч(?:\\.|ас(?:а|ов)?)?\\s*(\\d{1,2})\\s*мин",
        Pattern.CASE_INSENSITIVE or Pattern.UNICODE_CASE
    )
    private val minPattern = Pattern.compile(
        "(?<!\\d)(\\d{1,3})\\s*мин(?:\\.|ут[ыа]?)?(?!\\w)",
        Pattern.CASE_INSENSITIVE or Pattern.UNICODE_CASE
    )
    private val kmPattern = Pattern.compile(
        "(?<!\\d)(\\d{1,3}(?:[.,]\\d{1,2})?)\\s*км(?!\\w)",
        Pattern.CASE_INSENSITIVE or Pattern.UNICODE_CASE
    )
    private val metersPattern = Pattern.compile(
        "(?<!\\d)(\\d{2,4})\\s*м(?!ин|\\w)",
        Pattern.CASE_INSENSITIVE or Pattern.UNICODE_CASE
    )
    private val addressHint = Regex(
        "(?iu)(?:^|[\\s,(\\-])(?:улиц|ул\\.|просп|пр-?т\\.?|шоссе|ш\\.|переул|пер\\.|бульвар|б-р|набереж|наб\\.|площад|пл\\.|проезд|алле|тупик|микрорайон|мкр\\.?|д\\.\\s*\\d|д\\s+\\d|дом\\s+\\d|корп|стр\\.?\\s*\\d|москва|область|вокзал|аэропорт|терминал|метро|м\\.|тц\\b|трц\\b|жк\\b|бц\\b)"
    )
    private val embeddedBRegex = Regex("(?<!^)\\s+Б\\s+(?=[А-ЯЁA-Z0-9])")
    private val startsWithARegex = Regex("^[АA](?:[\\s.:)\\-—]+)(.+)$")
    private val startsWithBRegex = Regex("^[БB](?:[\\s.:)\\-—]+)(.+)$")
    private val abPrefixStrip = Regex("^(?:[АAБB]|точка\\s+[АAБB])[\\s.:)\\-—]+", RegexOption.IGNORE_CASE)

    private val navTabLabels = setOf("заказы", "предзаказы", "деньги", "чаты", "профиль")

    /** Фразы активного (уже принятого) заказа, ожидания или поездки. */
    private val activeTripWords = listOf(
        "начать поездку",
        "завершить поездку",
        "завершить заказ",
        "я на месте",
        "на месте",
        "поехали",
        "бесплатное ожидание",
        "платное ожидание",
        "в пути",
        "позвонить пассажиру",
        "позвонить клиенту",
        "отменить заказ",
        "отменить поездку",
        "до пассажира",
        "к клиенту"
    )

    /** Фразы не-карточных экранов Яндекс Про (главная карта, деньги, история, соглашения). */
    private val nonOfferScreenWords = listOf(
        "выйти на линию",
        "уйти с линии",
        "вывести деньги",
        "история заказов",
        "история поездок",
        "выполненные заказы",
        "пользовательское соглашение",
        "политика конфиденциальности",
        "принять условия",
        "принять правила",
        "принять оферту",
        "принять участие"
    )

    /** Слова в строке с деньгами, означающие баланс/бонус/цель, а не цену поездки. */
    private val nonPriceMoneyWords = listOf(
        "баланс", "доход", "заработ", "выплат", "на счёте", "на счете",
        "цель", "бонус", "гарант", "смен", "комисси", "штраф", "подписк", "лимит", "долг"
    )

    private val fromWords = listOf("откуда", "забрать", "точка а", "pickup")
    private val toWords = listOf("куда", "адрес назначения", "конец", "доставить", "точка б", "destination")

    private fun clean(s: String) = s.replace(Regex("\\s+"), " ").trim().trim('·', '•', ':', '-', '—')

    private fun stripAbPrefix(s: String): String =
        clean(s).replace(abPrefixStrip, "").trim()

    /** Разбивает многострочные блоки и склеенные строки «А ... Б ...» на отдельные строки. */
    private fun expandRawLines(texts: List<String>): List<String> {
        val out = ArrayList<String>(texts.size + 16)
        for (raw in texts) {
            for (part in raw.split('\n', '\r')) {
                val c = clean(part)
                if (c.isEmpty()) continue
                val m = embeddedBRegex.find(c)
                if (m != null && startsWithARegex.containsMatchIn(c)) {
                    val left = clean(c.substring(0, m.range.first))
                    val right = clean(c.substring(m.range.first))
                    if (left.isNotEmpty()) out.add(left)
                    if (right.isNotEmpty()) out.add(right)
                } else {
                    out.add(c)
                }
            }
        }
        return out
    }

    /** Проверяет, является ли строка настоящей кнопкой «Принять» входящего заказа. */
    private fun isAcceptButton(raw: String): Boolean {
        val low = clean(raw).lowercase()
        if (low.length !in 5..32) return false
        if (low.contains("услов") || low.contains("правил") || low.contains("оферт") || low.contains("участ")) {
            return false
        }
        return low == "принять" ||
            low == "принять заказ" ||
            low == "взять заказ" ||
            low == "взять" ||
            low.startsWith("принять ") ||
            low.startsWith("принять·") ||
            low.startsWith("принять(") ||
            (low.contains("принять") && (low.contains("×") || low.contains("x") || low.contains("+")))
    }

    /** Проверяет, является ли строка кнопкой «Пропустить» на карточке входящего заказа. */
    private fun isSkipButton(raw: String): Boolean {
        val low = clean(raw).lowercase()
        if (low.length !in 8..36) return false
        return low == "пропустить" ||
            low.startsWith("пропустить ") ||
            low.startsWith("пропустить·") ||
            low.startsWith("пропустить-") ||
            low.startsWith("пропустить(")
    }

    fun parse(
        context: Context,
        texts: List<String>,
        clickableTexts: List<String> = emptyList(),
        activeCoeff: Double? = null
    ): OrderOffer? {
        val expanded = expandRawLines(texts)
        if (expanded.isEmpty()) return null

        val navTabsVisible = expanded.count { it.lowercase() in navTabLabels }
        val lines = expanded.filter { it.lowercase() !in navTabLabels }
        if (lines.isEmpty()) return null

        // 2. Исключаем уже принятый заказ, ожидание, поездку
        val isActiveTrip = lines.any { line ->
            val low = line.lowercase()
            low == "ожидание" || activeTripWords.any { low.contains(it) }
        }
        if (isActiveTrip) {
            ReaderDiag.lastOrderCheck = "пропуск: активный заказ / ожидание"
            return null
        }

        // 3. Исключаем экран карты/линии, денег, истории и диалоги соглашений
        val isNonOffer = lines.any { line ->
            val low = line.lowercase()
            nonOfferScreenWords.any { low.contains(it) }
        }
        if (isNonOffer) {
            ReaderDiag.lastOrderCheck = "пропуск: экран карты / меню / соглашения"
            return null
        }

        // 4. ЖЁСТКИЙ ФИЛЬТР: на экране ОБЯЗАТЕЛЬНО должна быть кнопка «Принять» или «Пропустить»
        val btnPool = if (clickableTexts.isNotEmpty()) expandRawLines(clickableTexts) + lines else lines
        val hasAccept = btnPool.any(::isAcceptButton)
        val hasSkip = btnPool.any(::isSkipButton)
        if (!hasAccept && !hasSkip) {
            ReaderDiag.lastOrderCheck = "пропуск: нет кнопки «Принять»/«Пропустить»"
            return null
        }
        if (navTabsVisible >= 3 && !hasAccept) {
            ReaderDiag.lastOrderCheck = "пропуск: основной экран с вкладками без «Принять»"
            return null
        }

        val all = lines.joinToString(" | ")

        // 5. Определение тарифа
        val fallbackTariff = WidgetSettings.load(context).enabledTariffs()
            .firstOrNull()?.let(OrderTariff::fromAppTariff) ?: OrderTariff.COMFORT
        val tariff = OrderTariffRates.detect(lines, fallbackTariff)
        val explicitTariff = hasExplicitTariff(lines)

        // 6. Адреса А и Б (учитываем явные маркеры «А ...» / «Б ...» и отдельные узлы «А» / «Б»)
        var from = ""
        var to = ""

        lines.forEachIndexed { index, line ->
            if (from.isBlank()) {
                if (line == "А" || line == "A") {
                    val nxt = lines.getOrNull(index + 1)?.let(::stripAbPrefix).orEmpty()
                    if (looksReasonablePlace(nxt)) from = nxt
                } else {
                    val ma = startsWithARegex.find(line)
                    if (ma != null) {
                        val cand = clean(ma.groupValues[1])
                        if (looksReasonablePlace(cand)) from = cand
                    }
                }
            }
            if (to.isBlank()) {
                if (line == "Б" || line == "B") {
                    val nxt = lines.getOrNull(index + 1)?.let(::stripAbPrefix).orEmpty()
                    if (looksReasonablePlace(nxt)) to = nxt
                } else {
                    val mb = startsWithBRegex.find(line)
                    if (mb != null) {
                        val cand = clean(mb.groupValues[1])
                        if (looksReasonablePlace(cand)) to = cand
                    }
                }
            }
        }

        // Резервный поиск по словам «Откуда» / «Куда»
        lines.forEachIndexed { index, line ->
            val lower = line.lowercase()
            if (from.isBlank() && fromWords.any(lower::contains)) {
                from = extractAddress(line) ?: lines.getOrNull(index + 1)?.let(::stripAbPrefix)?.takeIf(::looksAddress).orEmpty()
            }
            if (to.isBlank() && toWords.any(lower::contains)) {
                to = extractAddress(line) ?: lines.getOrNull(index + 1)?.let(::stripAbPrefix)?.takeIf(::looksAddress).orEmpty()
            }
        }

        // Резервный поиск по адресным строкам с дедупликацией после снятия префикса «А » / «Б »
        val candidates = ArrayList<String>()
        val seenAddr = HashSet<String>()
        for (line in lines) {
            if (!looksAddress(line)) continue
            val norm = stripAbPrefix(line)
            val key = norm.lowercase()
            if (seenAddr.add(key)) candidates.add(norm)
        }
        if (from.isBlank() && candidates.isNotEmpty()) from = candidates[0]
        if (to.isBlank()) {
            val second = candidates.firstOrNull { !it.equals(from, ignoreCase = true) }
            if (second != null) to = second
        }
        if (from.equals(to, ignoreCase = true)) to = ""

        // 7. Коэффициент и доплата (+120 ₽)
        var surgeCoeff: Double? = null
        val cm = coeffPattern.matcher(all.replace(',', '.'))
        while (cm.find()) {
            val v = cm.group(1)?.toDoubleOrNull()
            if (v != null && v in 1.0..5.0) {
                surgeCoeff = maxOf(surgeCoeff ?: 1.0, v)
            }
        }
        if (surgeCoeff == null && activeCoeff != null && activeCoeff > 1.0) {
            surgeCoeff = activeCoeff
        }

        var surgeBonus = 0
        for (line in lines) {
            val low = line.lowercase()
            if (nonPriceMoneyWords.any { low.contains(it) }) continue
            val bm = bonusMoney.matcher(line)
            while (bm.find()) {
                val b = bm.group(1)?.toIntOrNull()
                if (b != null && b in 10..5000) {
                    surgeBonus = maxOf(surgeBonus, b)
                }
            }
        }

        // 8. Фиксированная цена заказа (исключая строки баланса/бонусов)
        var price: Int? = null
        for (line in lines) {
            val low = line.lowercase()
            if (nonPriceMoneyWords.any { low.contains(it) }) continue
            val pm = priceMoney.matcher(line)
            while (pm.find()) {
                val rawNum = pm.group(1)?.replace(Regex("[\\s\\u00A0]"), "") ?: continue
                val n = rawNum.toIntOrNull()
                if (n != null && n in 80..50_000 && n != surgeBonus) {
                    price = n
                    break
                }
            }
            if (price != null) break
        }

        // 9. Время и расстояние подачи / поездки (с сохранением контекста строки!)
        val minsFound = mutableListOf<Pair<Int, String>>()
        val kmsFound = mutableListOf<Pair<Double, String>>()
        for (line in lines) {
            val low = line.lowercase()
            val hm = hourMinPattern.matcher(line)
            if (hm.find()) {
                val h = hm.group(1)?.toIntOrNull() ?: 0
                val m = hm.group(2)?.toIntOrNull() ?: 0
                val totalM = h * 60 + m
                if (totalM in 1..600) minsFound.add(totalM to low)
            } else {
                val mm = minPattern.matcher(line)
                while (mm.find()) {
                    val m = mm.group(1)?.toIntOrNull()
                    if (m != null && m in 1..300) minsFound.add(m to low)
                }
            }
            val km = kmPattern.matcher(line)
            var foundKm = false
            while (km.find()) {
                val v = km.group(1)?.replace(',', '.')?.toDoubleOrNull()
                if (v != null && v in 0.1..500.0) {
                    kmsFound.add(v to low)
                    foundKm = true
                }
            }
            if (!foundKm) {
                val mtr = metersPattern.matcher(line)
                if (mtr.find()) {
                    val mv = mtr.group(1)?.toDoubleOrNull()
                    if (mv != null && mv in 50.0..9500.0) {
                        kmsFound.add(((mv / 100.0).roundToInt() / 10.0) to low)
                    }
                }
            }
        }

        // На карточке Яндекс Про одиночное «400 м · 1 мин» в шапке — это ПОДАЧА, а не время поездки!
        val pickupMin: Int?
        val tripMin: Int?
        when {
            minsFound.size >= 2 -> {
                pickupMin = minsFound[0].first
                tripMin = minsFound[1].first
            }
            minsFound.size == 1 -> {
                val (mVal, ctxLine) = minsFound[0]
                val explicitlyTrip = ctxLine.contains("поездк") || ctxLine.contains("маршрут") || ctxLine.contains("пути")
                if (explicitlyTrip) {
                    pickupMin = null
                    tripMin = mVal
                } else {
                    pickupMin = mVal
                    tripMin = null
                }
            }
            else -> {
                pickupMin = null
                tripMin = null
            }
        }

        val pickupKm: Double?
        val tripKm: Double?
        when {
            kmsFound.size >= 2 -> {
                pickupKm = kmsFound[0].first
                tripKm = kmsFound[1].first
            }
            kmsFound.size == 1 -> {
                val (kVal, ctxLine) = kmsFound[0]
                val explicitlyTrip = ctxLine.contains("поездк") || ctxLine.contains("маршрут") || ctxLine.contains("пути")
                if (explicitlyTrip) {
                    pickupKm = null
                    tripKm = kVal
                } else {
                    pickupKm = kVal
                    tripKm = null
                }
            }
            else -> {
                pickupKm = null
                tripKm = null
            }
        }

        // 10. Подтверждение содержательной части карточки
        val hasRouteMetrics = pickupMin != null || tripMin != null || pickupKm != null || tripKm != null
        val hasAddress = from.isNotBlank() || to.isNotBlank()
        val hasSubstantiveOrderData =
            (hasAddress && (hasRouteMetrics || price != null || explicitTariff || to.isNotBlank())) ||
                (hasRouteMetrics && (price != null || explicitTariff))
        if (!hasSubstantiveOrderData) {
            ReaderDiag.lastOrderCheck = "пропуск: недостаточно данных карточки заказа"
            return null
        }

        // 11. Защита от повторного срабатывания на ту же карточку во время обратного отсчёта (20 с)
        val now = System.currentTimeMillis()
        val normalized = "${tariff.name}|$from|$to|$price|$pickupMin|$tripMin|$pickupKm|$tripKm"
        val softKey = "${tariff.name}|$from|$to|$price"
        val prefs = context.getSharedPreferences("last_order_card", Context.MODE_PRIVATE)
        val prevFp = prefs.getString("fingerprint", "") ?: ""
        val prevSoft = prefs.getString("soft_key", "") ?: ""
        val prevAt = prefs.getLong("captured", 0L)
        if (prevFp == normalized || (prevSoft == softKey && now - prevAt < SAME_OFFER_COOLDOWN_MS)) {
            return null
        }

        val offer = OrderOffer(
            from = from,
            to = to,
            priceRub = price,
            tariff = tariff,
            surgeCoeff = surgeCoeff,
            surgeBonusRub = surgeBonus,
            pickupMin = pickupMin,
            pickupKm = pickupKm,
            tripMin = tripMin,
            tripKm = tripKm,
            raw = lines.take(60).joinToString("\n"),
            capturedAt = now
        )
        ReaderDiag.lastOrderCheck = "входящий заказ (${tariff.shortTitle}, А=${from.isNotBlank()}, Б=${to.isNotBlank()})"
        save(context, normalized, softKey, offer)
        return offer
    }

    private fun looksReasonablePlace(s: String): Boolean {
        if (s.length < 4) return false
        val low = s.lowercase()
        if (low.contains("принять") || low.contains("пропустить") || low.contains("приоритет") ||
            low.contains("пассажир") || low.contains("подача") || low.contains("₽")
        ) return false
        return s.any { it.isLetter() }
    }

    private fun hasExplicitTariff(lines: List<String>): Boolean {
        val joined = lines.joinToString(" ").lowercase()
        return joined.contains("эконом") || joined.contains("комфорт") ||
            joined.contains("детский") || joined.contains("бизнес") ||
            joined.contains("минивэн") || joined.contains("доставка") ||
            joined.contains("курьер") || joined.contains("ultima") ||
            joined.contains("econom") || joined.contains("comfort")
    }

    private fun save(context: Context, fingerprint: String, softKey: String, offer: OrderOffer) {
        val prefs = context.getSharedPreferences("last_order_card", Context.MODE_PRIVATE)
        prefs.edit()
            .putString("fingerprint", fingerprint)
            .putString("soft_key", softKey)
            .putString("from", offer.from)
            .putString("to", offer.to)
            .putInt("price", offer.priceRub ?: -1)
            .putString("tariff", offer.tariff.name)
            .putFloat("coeff", (offer.surgeCoeff ?: -1.0).toFloat())
            .putInt("bonus", offer.surgeBonusRub)
            .putInt("pmin", offer.pickupMin ?: -1)
            .putFloat("pkm", (offer.pickupKm ?: -1.0).toFloat())
            .putInt("tmin", offer.tripMin ?: -1)
            .putFloat("tkm", (offer.tripKm ?: -1.0).toFloat())
            .putString("raw", offer.raw)
            .putLong("captured", offer.capturedAt)
            .apply()
        ReaderDiag.lastOrderAt = offer.capturedAt
    }

    private fun extractAddress(line: String): String? {
        val split = line.split(":", "—", "–", "->", "→")
        if (split.size < 2) return null
        return split.lastOrNull()?.let(::stripAbPrefix)?.takeIf(::looksAddress)
    }

    private fun looksAddress(s: String): Boolean {
        val c = stripAbPrefix(s)
        return c.length >= 6 && addressHint.containsMatchIn(c) && !c.contains("₽") && !c.contains("руб", true)
    }

    fun load(c: Context): OrderOffer? {
        val p = c.getSharedPreferences("last_order_card", Context.MODE_PRIVATE)
        val from = p.getString("from", "") ?: ""
        val to = p.getString("to", "") ?: ""
        val price = p.getInt("price", -1)
        val tmin = p.getInt("tmin", -1)
        val tkm = p.getFloat("tkm", -1f)
        val pmin = p.getInt("pmin", -1)
        if (from.isBlank() && to.isBlank() && price < 0 && tmin < 0 && tkm < 0f && pmin < 0) return null
        return OrderOffer(
            from = from,
            to = to,
            priceRub = price.takeIf { it >= 0 },
            tariff = OrderTariff.byNameOrDefault(p.getString("tariff", null)),
            surgeCoeff = p.getFloat("coeff", -1f).toDouble().takeIf { it >= 1.0 },
            surgeBonusRub = p.getInt("bonus", 0),
            pickupMin = pmin.takeIf { it >= 0 },
            pickupKm = p.getFloat("pkm", -1f).toDouble().takeIf { it >= 0.0 },
            tripMin = tmin.takeIf { it >= 0 },
            tripKm = tkm.toDouble().takeIf { it >= 0.0 },
            raw = p.getString("raw", "") ?: "",
            capturedAt = p.getLong("captured", 0L)
        )
    }

    fun summary(o: OrderOffer): String = buildString {
        append("Карточка заказа · ${o.tariff.title}\n")
        if (o.from.isNotBlank()) append("А: ${o.from}\n")
        if (o.to.isNotBlank()) append("Б: ${o.to}\n")
        if (o.priceRub != null) append("Цена на карточке: ${o.priceRub} ₽\n")
        if (o.tripMin != null || o.tripKm != null) {
            append("В пути: ${o.tripMin ?: "—"} мин · ${o.tripKm?.let { String.format(Locale.US, "%.1f км", it) } ?: "—"}\n")
        }
        append("Время: ${java.text.SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(java.util.Date(o.capturedAt))}")
    }

    fun openTrafficRoute(context: Context, offer: OrderOffer) {
        if (offer.from.isBlank() && offer.to.isBlank()) return
        val uri = if (offer.from.isNotBlank() && offer.to.isNotBlank()) {
            val route = URLEncoder.encode(offer.from, "UTF-8") + "~" + URLEncoder.encode(offer.to, "UTF-8")
            Uri.parse("https://yandex.ru/maps/?rtext=$route&rtt=auto")
        } else {
            val target = offer.to.ifBlank { offer.from }
            Uri.parse("https://yandex.ru/maps/?text=" + URLEncoder.encode(target, "UTF-8"))
        }
        runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }

    fun openAddressInMaps(context: Context, address: String) {
        if (address.isBlank()) return
        val uri = Uri.parse("https://yandex.ru/maps/?text=" + URLEncoder.encode(address, "UTF-8"))
        runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }
}
