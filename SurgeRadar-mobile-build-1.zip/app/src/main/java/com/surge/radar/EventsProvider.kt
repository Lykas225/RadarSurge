package com.surge.radar

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.CopyOnWriteArrayList

/** Концерты Москвы из открытой афиши KudaGo (без ключа): когда начинаются и где. */
class EventInfo(
    val title: String,
    val startMs: Long,
    val endMs: Long,
    val venue: String,
    val lat: Double,
    val lon: Double
)

object EventsProvider {
    private const val URL_BASE = "https://kudago.com/public-api/v1.4/events/"
    private val events = CopyOnWriteArrayList<EventInfo>()
    @Volatile private var fetchedAt = 0L
    @Volatile private var fetching = false
    @Volatile var lastError: String = ""
        private set

    fun list(): List<EventInfo> = events

    fun status(): String = when {
        lastError.isNotEmpty() -> "афиша недоступна ($lastError)"
        fetchedAt == 0L -> "ещё не загружена"
        else -> "загружено концертов: ${events.size}"
    }

    fun refreshAsync(force: Boolean = false, onDone: (() -> Unit)? = null) {
        val now = System.currentTimeMillis()
        if (fetching) return
        if (!force && now - fetchedAt < 60 * 60_000L) return
        fetching = true
        Thread {
            try {
                val since = now / 1000L - 3 * 3600L
                val until = now / 1000L + 14 * 3600L
                val url = URL(
                    "$URL_BASE?lang=ru&location=msk&categories=concert&actual_since=$since&actual_until=$until" +
                        "&fields=id,title,dates,place&expand=place&page_size=100&text_format=text"
                )
                val conn = url.openConnection() as HttpURLConnection
                conn.connectTimeout = 8000
                conn.readTimeout = 8000
                conn.setRequestProperty("User-Agent", "SurgeRadar")
                if (conn.responseCode != 200) throw Exception("HTTP ${conn.responseCode}")
                val body = conn.inputStream.use { it.readBytes() }.toString(Charsets.UTF_8)
                conn.disconnect()

                val results = JSONObject(body).optJSONArray("results")
                val out = ArrayList<EventInfo>()
                if (results != null) {
                    for (i in 0 until results.length()) {
                        val o = results.optJSONObject(i) ?: continue
                        val place = o.optJSONObject("place") ?: continue
                        val coords = place.optJSONObject("coords") ?: continue
                        val lat = coords.optDouble("lat", Double.NaN)
                        val lon = coords.optDouble("lon", Double.NaN)
                        if (lat.isNaN() || lon.isNaN()) continue
                        val dates = o.optJSONArray("dates") ?: continue
                        for (j in 0 until dates.length()) {
                            val d = dates.optJSONObject(j) ?: continue
                            val s = d.optLong("start", 0L) * 1000L
                            var e = d.optLong("end", 0L) * 1000L
                            if (s <= 0L || s > now + 20 * 3_600_000L) continue
                            if (e <= s || e - s > 12 * 3_600_000L) e = s + 150 * 60_000L
                            if (e < now - 3_600_000L) continue
                            out.add(EventInfo(o.optString("title", "Концерт"), s, e, place.optString("title", ""), lat, lon))
                        }
                    }
                }
                events.clear()
                events.addAll(out)
                fetchedAt = now
                lastError = ""
            } catch (e: Exception) {
                lastError = e.message?.take(40) ?: "ошибка"
                fetchedAt = now - 50 * 60_000L // повтор примерно через 10 минут
            } finally {
                fetching = false
                onDone?.let { cb -> android.os.Handler(android.os.Looper.getMainLooper()).post { cb() } }
            }
        }.start()
    }
}
