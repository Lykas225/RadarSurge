package com.surge.radar

import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.roundToInt

/**
 * Расчёт спроса на такси по Москве и МО:
 * 1) При наличии свежего наблюдения Яндекс Про (0–3 мин) в вашей зоне показывается 100% реальный кэф без занижения.
 * 2) В течение 3–20 минут реальный кэф плавно затухает к базовой модели времени суток и погоды.
 * 3) В соседние зоны (радиус до 8.5 км) переносится затухающая по расстоянию аномалия спроса,
 *    чтобы карта и виджет реагировали на реальный всплеск вокруг водителя.
 */
object DemandModel {
    enum class Kind { CENTER, RESIDENTIAL, SUBURB, STATION, AIRPORT }

    private const val LIVE_WINDOW_MS = 20 * 60_000L
    private const val FULL_TRUST_MS = 3 * 60_000L
    private const val SPATIAL_RADIUS_KM = 8.5
    private const val SPATIAL_SIGMA_KM = 4.2

    private val centerWd = doubleArrayOf(
        0.35, 0.25, 0.15, 0.10, 0.10, 0.15, 0.25, 0.40, 0.55, 0.65, 0.55, 0.55,
        0.60, 0.60, 0.55, 0.60, 0.75, 0.95, 1.00, 0.95, 0.80, 0.70, 0.65, 0.50
    )
    private val centerWe = doubleArrayOf(
        0.85, 0.90, 0.80, 0.55, 0.30, 0.15, 0.10, 0.10, 0.15, 0.20, 0.30, 0.40,
        0.50, 0.55, 0.55, 0.60, 0.65, 0.70, 0.80, 0.85, 0.85, 0.85, 0.90, 0.90
    )
    private val residentialWd = doubleArrayOf(
        0.25, 0.15, 0.10, 0.10, 0.15, 0.40, 0.75, 0.95, 1.00, 0.80, 0.50, 0.40,
        0.40, 0.40, 0.40, 0.45, 0.50, 0.55, 0.60, 0.55, 0.50, 0.45, 0.40, 0.30
    )
    private val residentialWe = doubleArrayOf(
        0.45, 0.35, 0.25, 0.20, 0.15, 0.15, 0.15, 0.20, 0.25, 0.30, 0.40, 0.50,
        0.55, 0.55, 0.50, 0.50, 0.50, 0.55, 0.60, 0.65, 0.60, 0.60, 0.60, 0.55
    )
    private val station = doubleArrayOf(
        0.40, 0.30, 0.25, 0.20, 0.25, 0.40, 0.60, 0.80, 0.85, 0.75, 0.60, 0.55,
        0.55, 0.55, 0.55, 0.60, 0.70, 0.85, 0.90, 0.80, 0.70, 0.60, 0.50, 0.45
    )
    private val airport = doubleArrayOf(
        0.60, 0.50, 0.45, 0.50, 0.60, 0.70, 0.75, 0.70, 0.60, 0.55, 0.50, 0.50,
        0.50, 0.55, 0.55, 0.60, 0.65, 0.70, 0.75, 0.70, 0.70, 0.70, 0.65, 0.60
    )

    private val zoneByName: Map<String, SurgeZone> by lazy {
        MoscowRegionGrid.zones.associateBy { it.name }
    }

    fun kindOf(zone: SurgeZone): Kind {
        val n = zone.name
        return when {
            n.startsWith("Аэропорт") -> Kind.AIRPORT
            n.startsWith("Комсомольская") || n.startsWith("Белорусская") -> Kind.STATION
            n.startsWith("Центр") || n.startsWith("Сити") || n.startsWith("Таганка") ||
                n.startsWith("Парк Культуры") || n.startsWith("Фили") || n.startsWith("Красносельская") ||
                n.startsWith("Даниловский") || n.startsWith("Лефортово") -> Kind.CENTER
            n.startsWith("МО:") || n == "Зеленоград" || n == "Троицк" ||
                n == "Щербинка" || n == "Московский" -> Kind.SUBURB
            else -> Kind.RESIDENTIAL
        }
    }

    private const val MSK_OFFSET_MS = 3 * 3_600_000L
    private const val DAY_MS = 86_400_000L
    private val distFactorCache = ConcurrentHashMap<String, Double>()

    /** Время по Москве (UTC+3, без перехода на летнее) в виде ЧЧ:ММ. */
    fun mskTime(timeMs: Long): String {
        val m = Math.floorMod((timeMs + MSK_OFFSET_MS) / 60_000L, 1440L).toInt()
        return String.format(Locale.US, "%02d:%02d", m / 60, m % 60)
    }

    /** Детерминированный географический коэффициент района без случайного шума. */
    private fun geoFactor(zone: SurgeZone): Double = distFactorCache.getOrPut(zone.name) {
        val kind = kindOf(zone)
        val dist = MoscowRegionGrid.distanceKm(55.7558, 37.6173, zone.lat, zone.lon)
        when (kind) {
            Kind.CENTER -> 1.04
            Kind.STATION, Kind.AIRPORT -> 1.05
            Kind.RESIDENTIAL -> if (dist <= 10.0) 1.00 else 0.96
            Kind.SUBURB -> when {
                dist > 70.0 -> 0.72
                dist > 40.0 -> 0.80
                else -> 0.88
            }
        }
    }

    /** Минуты от начала суток по Москве. */
    fun mskMinutes(timeMs: Long): Int =
        Math.floorMod((timeMs + MSK_OFFSET_MS) / 60_000L, 1440L).toInt()

    fun kindIntensity(kind: Kind, timeMs: Long): Double {
        val local = timeMs + MSK_OFFSET_MS
        val days = Math.floorDiv(local, DAY_MS)
        val msOfDay = Math.floorMod(local, DAY_MS)
        val dow = Math.floorMod(days + 3L, 7L).toInt() // 0 = понедельник
        val hourF = msOfDay / 3_600_000.0
        val hour = hourF.toInt()
        val weekend = dow >= 5 || (dow == 4 && hour >= 20) || (dow == 0 && hour < 5)

        val arr = when (kind) {
            Kind.CENTER -> if (weekend) centerWe else centerWd
            Kind.RESIDENTIAL, Kind.SUBURB -> if (weekend) residentialWe else residentialWd
            Kind.STATION -> station
            Kind.AIRPORT -> airport
        }
        val i0 = hour % 24
        val i1 = (i0 + 1) % 24
        val frac = hourF - hour
        return arr[i0] * (1.0 - frac) + arr[i1] * frac
    }

    /** Коэффициент места «по времени суток» (для аэропортов, вокзалов и автовокзалов). */
    fun kindCoeff(kind: Kind, timeMs: Long): Double {
        val x = (kindIntensity(kind, timeMs) + WeatherProvider.boost()).coerceIn(0.0, 1.35)
        return (1.0 + 1.6 * max(0.0, x - 0.35)).coerceIn(1.0, 3.2)
    }

    fun intensity(zone: SurgeZone, timeMs: Long): Double =
        kindIntensity(kindOf(zone), timeMs) * geoFactor(zone)

    /** Чистая модельная оценка (без подмешивания реальных данных Яндекс Про). */
    fun modelBaseCoeff(zone: SurgeZone, timeMs: Long = System.currentTimeMillis()): Double {
        val x = (intensity(zone, timeMs) + WeatherProvider.boost()).coerceIn(0.0, 1.35)
        return (1.0 + 1.6 * max(0.0, x - 0.35)).coerceIn(1.0, 3.2)
    }

    /** Вес свежести реального наблюдения: 1.0 в первые 3 мин, затем плавное затухание до 0 к 20 мин. */
    private fun timeTrust(ageMs: Long): Double {
        if (ageMs <= FULL_TRUST_MS) return 1.0
        if (ageMs >= LIVE_WINDOW_MS) return 0.0
        val rem = (LIVE_WINDOW_MS - ageMs).toDouble() / (LIVE_WINDOW_MS - FULL_TRUST_MS).toDouble()
        return rem.coerceIn(0.0, 1.0).pow(1.35)
    }

    /** Коэффициент уровня Эконом (1.0 = нет надбавки) с приоритетом свежих данных Яндекс Про. */
    fun baseCoeff(
        zone: SurgeZone,
        timeMs: Long = System.currentTimeMillis(),
        useObserved: Boolean = true
    ): Double {
        val modelHere = modelBaseCoeff(zone, timeMs)
        if (!useObserved) return modelHere

        // 1. Прямое свежее наблюдение в этой же зоне (0–3 мин = 100% реальный кэф Яндекс Про)
        val direct = RadarEngine.freshObservation(zone.name, LIVE_WINDOW_MS, timeMs)
        if (direct != null) {
            val w = timeTrust(timeMs - direct.timestamp)
            return (modelHere * (1.0 - w) + direct.coeff * w).coerceIn(1.0, 5.0)
        }

        // 2. Пространственный перенос аномалии спроса из соседних зон (в радиусе до 8.5 км)
        val freshAll = RadarEngine.freshZones(LIVE_WINDOW_MS, timeMs)
        if (freshAll.isEmpty()) return modelHere

        var weightedDelta = 0.0
        var totalWeight = 0.0
        for (obs in freshAll) {
            val srcZone = obs.zoneName?.let { zoneByName[it] } ?: continue
            val d = MoscowRegionGrid.distanceKm(zone.lat, zone.lon, srcZone.lat, srcZone.lon)
            if (d > SPATIAL_RADIUS_KM) continue
            val tW = timeTrust(timeMs - obs.timestamp)
            if (tW <= 0.0) continue
            val sW = exp(-(d / SPATIAL_SIGMA_KM) * (d / SPATIAL_SIGMA_KM)) * 0.85
            val w = tW * sW
            val obsModel = modelBaseCoeff(srcZone, timeMs)
            val delta = obs.coeff - obsModel
            weightedDelta += delta * w
            totalWeight += w
        }
        if (totalWeight <= 0.01) return modelHere
        val blendedDelta = weightedDelta / max(1.0, totalWeight)
        return (modelHere + blendedDelta).coerceIn(1.0, 5.0)
    }

    /** Есть ли для данной зоны свежие реальные данные Яндекс Про (напрямую или рядом до 8.5 км). */
    fun isZoneLive(zone: SurgeZone, nowMs: Long = System.currentTimeMillis()): Boolean {
        if (RadarEngine.freshObservation(zone.name, LIVE_WINDOW_MS, nowMs) != null) return true
        for (obs in RadarEngine.freshZones(LIVE_WINDOW_MS, nowMs)) {
            val src = obs.zoneName?.let { zoneByName[it] } ?: continue
            if (MoscowRegionGrid.distanceKm(zone.lat, zone.lon, src.lat, src.lon) <= SPATIAL_RADIUS_KM) {
                return true
            }
        }
        return false
    }

    /** Честная подпись источника коэффициента именно для выбранной зоны. */
    fun zoneSourceLabel(zone: SurgeZone, nowMs: Long = System.currentTimeMillis()): String {
        val direct = RadarEngine.freshObservation(zone.name, LIVE_WINDOW_MS, nowMs)
        if (direct != null) {
            val minAgo = ((nowMs - direct.timestamp) / 60_000L).coerceAtLeast(0L)
            val age = if (minAgo == 0L) "только что" else "$minAgo мин назад"
            val src = direct.source?.takeIf { it.isNotBlank() }?.let { " · $it" } ?: ""
            return "Яндекс Про ($age$src)"
        }
        var nearestObs: RadarObservation? = null
        var nearestDist = Double.MAX_VALUE
        for (obs in RadarEngine.freshZones(LIVE_WINDOW_MS, nowMs)) {
            val src = obs.zoneName?.let { zoneByName[it] } ?: continue
            val d = MoscowRegionGrid.distanceKm(zone.lat, zone.lon, src.lat, src.lon)
            if (d <= SPATIAL_RADIUS_KM && d < nearestDist) {
                nearestDist = d
                nearestObs = obs
            }
        }
        if (nearestObs != null) {
            val minAgo = ((nowMs - nearestObs.timestamp) / 60_000L).coerceAtLeast(0L)
            val age = if (minAgo == 0L) "только что" else "$minAgo мин назад"
            return String.format(Locale.US, "Яндекс Про рядом %.1f км (%s)", nearestDist, age)
        }
        return "расчётная модель (откройте Яндекс Про)"
    }

    fun scale(base: Double, t: Tariff): Double = 1.0 + (base - 1.0) * t.k

    private val coefTexts = Array(401) { i ->
        val v = 1.0 + i / 100.0
        if (i % 10 == 0) String.format(Locale.US, "×%.1f", v)
        else String.format(Locale.US, "×%.2f", v)
    }

    /** Точный формат коэффициента: ×1.0, ×1.2, ×1.71. */
    fun coefText(pct: Int): String = coefTexts[pct.coerceIn(0, 400)]

    fun pct(coeff: Double): Int = ((coeff - 1.0) * 100.0).roundToInt().coerceAtLeast(0)

    fun maxPct(base: Double, tariffs: List<Tariff>): Int =
        if (tariffs.isEmpty()) 0 else pct(tariffs.maxOf { scale(base, it) })

    fun waitMinutes(coeff: Double): Int = (8.0 / coeff.pow(1.6)).roundToInt().coerceIn(2, 12)

    fun forecast(zone: SurgeZone, tariff: Tariff, startMs: Long, steps: Int, stepMs: Long): List<Double> =
        List(steps) { i -> scale(baseCoeff(zone, startMs + i * stepMs, i == 0), tariff) }

    fun label(pct: Int): String = when {
        pct >= 70 -> "Пиковая активность"
        pct >= 40 -> "Высокий спрос"
        pct >= 15 -> "Растущий спрос"
        else -> "Спокойно"
    }

    /** Единая радарная шкала: зелёный → жёлтый → оранжевый → красный. */
    fun textColor(pct: Int): Int = heatColor(pct)

    fun heatColor(pct: Int): Int = when {
        pct >= 70 -> 0xFFFF5964.toInt()  // очень высокий спрос — красный
        pct >= 40 -> 0xFFFF963F.toInt()  // повышенный спрос — оранжевый
        pct >= 15 -> 0xFFFFD34E.toInt()  // средний спрос — жёлтый
        else -> 0xFF55D68B.toInt()       // спокойная зона — зелёный
    }
}
