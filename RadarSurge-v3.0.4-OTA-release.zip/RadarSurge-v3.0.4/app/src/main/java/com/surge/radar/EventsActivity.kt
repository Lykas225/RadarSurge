package com.surge.radar

import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

/**
 * Экран «Москва · Мероприятия»:
 * 1) Нативная лента карточек по дням («Сегодня», «Завтра», далее) в палитре приложения.
 * 2) Автоматический фоновый обход HTTP 403 через встроенный движок Chromium WebView (извлечение JSON / JSON-LD).
 * 3) Вкладка «🌐 Сайт» для просмотра Яндекс Афиши / Timepad / Afisha.ru / KudaGo прямо внутри приложения.
 */
class EventsActivity : AppCompatActivity() {

    private val ctx: Context get() = this
    private val matchP = ViewGroup.LayoutParams.MATCH_PARENT
    private val wrapP = ViewGroup.LayoutParams.WRAP_CONTENT
    private val msk = ZoneId.of("Europe/Moscow")
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var p: Palette
    private lateinit var statusView: TextView
    private lateinit var tabFeedBtn: TextView
    private lateinit var tabWebBtn: TextView
    private lateinit var feedContainer: LinearLayout
    private lateinit var webContainer: LinearLayout
    private lateinit var catRow: LinearLayout
    private lateinit var listBox: LinearLayout
    private lateinit var webSourceRow: LinearLayout
    private lateinit var webProgress: ProgressBar
    private lateinit var browserWeb: WebView
    private var stealthWeb: WebView? = null

    private var selectedCat = "all"
    private var webMode = false
    private var selectedWebSource = 0
    private var events: List<LiveEvent> = emptyList()
    private var lastError: String? = null
    private var stealthQueue: List<Pair<String, String>> = emptyList()
    private var stealthIdx = 0
    private var stealthRunning = false

    private val webSources = listOf(
        "Яндекс Афиша" to "https://afisha.yandex.ru/moscow/events",
        "Timepad" to "https://afisha.timepad.ru/moscow",
        "Afisha.ru" to "https://www.afisha.ru/msk/events/",
        "KudaGo" to "https://kudago.com/msk/events/"
    )

    private fun dp(v: Int): Int = dpi(v)

    private fun tv(t: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(ctx).apply {
            text = t
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        p = Palette(WidgetSettings.load(this).dark)
        events = EventsProvider.cached(this)
        buildUi()
        render()
        loadEvents(false)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun buildUi() {
        val rootFrame = FrameLayout(ctx).apply { setBackgroundColor(p.bg) }

        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(12))
        }

        // Верхняя панель
        val topBar = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val backBtn = tv("‹ Назад", 15f, p.accent, true).apply {
            setPadding(0, dp(4), dp(16), dp(4))
            setOnClickListener { finish() }
        }
        val refreshBtn = tv("↻ Обновить", 14f, p.accent, true).apply {
            setPadding(dp(12), dp(6), dp(12), dp(6))
            background = rounded(withAlpha(p.accent, 0.14f), dp(12).toFloat(), withAlpha(p.accent, 0.45f), dp(1))
            setOnClickListener {
                if (webMode) browserWeb.reload() else loadEvents(true)
            }
        }
        topBar.addView(backBtn, LinearLayout.LayoutParams(0, wrapP, 1f))
        topBar.addView(refreshBtn)
        root.addView(topBar)

        root.addView(
            tv("Москва · Мероприятия", 23f, p.text, true).apply {
                setPadding(0, dp(8), 0, dp(2))
            }
        )

        statusView = tv(EventsProvider.statusLine(this), 12f, p.sub).apply {
            setPadding(0, 0, 0, dp(8))
        }
        root.addView(statusView)

        // Переключатель «Лента карточек» / «Встроенный сайт»
        val modeRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        tabFeedBtn = tv("📋 Лента", 13f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(8), dp(10), dp(8))
            setOnClickListener { switchMode(false) }
        }
        tabWebBtn = tv("🌐 Афиша-сайт", 13f, p.text, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(8), dp(10), dp(8))
            setOnClickListener { switchMode(true) }
        }
        modeRow.addView(tabFeedBtn, LinearLayout.LayoutParams(0, wrapP, 1f).apply { rightMargin = dp(6) })
        modeRow.addView(tabWebBtn, LinearLayout.LayoutParams(0, wrapP, 1f))
        root.addView(modeRow, LinearLayout.LayoutParams(matchP, wrapP).apply { bottomMargin = dp(10) })

        // Контейнер нативной ленты
        feedContainer = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        catRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        val catScroll = HorizontalScrollView(ctx).apply {
            isHorizontalScrollBarEnabled = false
            addView(catRow)
        }
        feedContainer.addView(catScroll, LinearLayout.LayoutParams(matchP, wrapP).apply { bottomMargin = dp(12) })
        renderCategoryChips()

        val scroll = ScrollView(ctx)
        listBox = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, dp(24))
        }
        scroll.addView(listBox, LinearLayout.LayoutParams(matchP, wrapP))
        feedContainer.addView(scroll, LinearLayout.LayoutParams(matchP, 0, 1f))

        // Контейнер встроенного браузера
        webContainer = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        webSourceRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        val webSrcScroll = HorizontalScrollView(ctx).apply {
            isHorizontalScrollBarEnabled = false
            addView(webSourceRow)
        }
        webContainer.addView(webSrcScroll, LinearLayout.LayoutParams(matchP, wrapP).apply { bottomMargin = dp(8) })
        webProgress = ProgressBar(ctx, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = View.GONE
        }
        webContainer.addView(webProgress, LinearLayout.LayoutParams(matchP, dp(3)))
        browserWeb = WebView(ctx).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.loadsImagesAutomatically = true
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                    val uri = runCatching { Uri.parse(url ?: "") }.getOrNull() ?: return true
                    return uri.scheme != "https" && uri.scheme != "http"
                }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(view: WebView?, newProgress: Int) {
                    webProgress.progress = newProgress
                    webProgress.visibility = if (newProgress >= 100) View.GONE else View.VISIBLE
                }
            }
        }
        webContainer.addView(browserWeb, LinearLayout.LayoutParams(matchP, 0, 1f))
        renderWebSourceChips()

        root.addView(feedContainer, LinearLayout.LayoutParams(matchP, 0, 1f))
        root.addView(webContainer, LinearLayout.LayoutParams(matchP, 0, 1f))
        rootFrame.addView(root, FrameLayout.LayoutParams(matchP, matchP))

        // Скрытый 1x1 WebView на реальном движке Chrome для обхода TLS/WAF 403 при загрузке ленты
        stealthWeb = WebView(ctx).apply {
            visibility = View.INVISIBLE
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.loadsImagesAutomatically = false
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    if (!stealthRunning || view == null) return
                    val stepIndex = stealthIdx
                    handler.postDelayed({
                        if (isFinishing || isDestroyed || !stealthRunning || stepIndex != stealthIdx) return@postDelayed
                        extractFromStealthPage(view)
                    }, 1200L)
                }
            }
        }
        rootFrame.addView(stealthWeb, FrameLayout.LayoutParams(1, 1))

        updateModeTabs()
        setContentView(rootFrame)
    }

    private fun switchMode(toWeb: Boolean) {
        webMode = toWeb
        updateModeTabs()
        feedContainer.visibility = if (webMode) View.GONE else View.VISIBLE
        webContainer.visibility = if (webMode) View.VISIBLE else View.GONE
        if (webMode && browserWeb.url.isNullOrBlank()) {
            browserWeb.loadUrl(webSources[selectedWebSource].second)
        }
    }

    private fun updateModeTabs() {
        tabFeedBtn.setTextColor(if (!webMode) Color.WHITE else p.text)
        tabFeedBtn.background = if (!webMode) rounded(p.accent, dp(12).toFloat()) else rounded(p.card, dp(12).toFloat(), p.stroke, dp(1))
        tabWebBtn.setTextColor(if (webMode) Color.WHITE else p.text)
        tabWebBtn.background = if (webMode) rounded(p.accent, dp(12).toFloat()) else rounded(p.card, dp(12).toFloat(), p.stroke, dp(1))
    }

    private fun renderWebSourceChips() {
        webSourceRow.removeAllViews()
        webSources.forEachIndexed { idx, (label, url) ->
            val active = idx == selectedWebSource
            val chip = tv(label, 12.5f, if (active) Color.WHITE else p.text, active).apply {
                gravity = Gravity.CENTER
                setPadding(dp(12), dp(7), dp(12), dp(7))
                background = if (active) rounded(p.accent, dp(12).toFloat()) else rounded(p.card, dp(12).toFloat(), p.stroke, dp(1))
                setOnClickListener {
                    selectedWebSource = idx
                    renderWebSourceChips()
                    browserWeb.loadUrl(url)
                }
            }
            webSourceRow.addView(chip, LinearLayout.LayoutParams(wrapP, wrapP).apply { rightMargin = dp(6) })
        }
    }

    private fun renderCategoryChips() {
        catRow.removeAllViews()
        for ((key, label) in EventsProvider.categories) {
            val active = key == selectedCat
            val chip = tv(label, 12.5f, if (active) Color.WHITE else p.text, active).apply {
                gravity = Gravity.CENTER
                setPadding(dp(12), dp(8), dp(12), dp(8))
                background = if (active) {
                    rounded(p.accent, dp(14).toFloat())
                } else {
                    rounded(p.card, dp(14).toFloat(), p.stroke, dp(1))
                }
                setOnClickListener {
                    selectedCat = key
                    renderCategoryChips()
                    render()
                }
            }
            catRow.addView(chip, LinearLayout.LayoutParams(wrapP, wrapP).apply { rightMargin = dp(6) })
        }
    }

    private fun loadEvents(force: Boolean) {
        if (force) statusView.text = "Обновляем афишу Москвы…"
        EventsProvider.refreshAsync(this, force) { list, err, needWebFallback ->
            if (isFinishing || isDestroyed) return@refreshAsync
            events = list
            lastError = err
            statusView.text = if (err != null && list.isEmpty()) err else EventsProvider.statusLine(this)
            render()
            if (needWebFallback) {
                startStealthExtraction()
            }
        }
    }

    private fun startStealthExtraction() {
        if (stealthRunning || isFinishing || isDestroyed) return
        stealthQueue = listOf(
            "KudaGo" to EventsProvider.kudaGoUrl(),
            "Timepad" to "https://afisha.timepad.ru/moscow",
            "Afisha.ru" to "https://www.afisha.ru/msk/events/"
        )
        stealthIdx = 0
        stealthRunning = true
        statusView.text = "Загружаем афишу через браузерный движок…"
        loadNextStealthSource()
    }

    private fun loadNextStealthSource() {
        val wv = stealthWeb
        if (wv == null || stealthIdx >= stealthQueue.size) {
            stealthRunning = false
            if (events.isEmpty()) {
                val vpnTip = if (EventsProvider.isVpnActive(this)) {
                    "Включён VPN — российские афиши часто блокируют зарубежные IP (403). Отключите VPN или откройте вкладку «🌐 Афиша-сайт»."
                } else {
                    lastError ?: "Сайты афиш временно недоступны. Откройте вкладку «🌐 Афиша-сайт»."
                }
                lastError = vpnTip
                statusView.text = vpnTip
                render()
            }
            return
        }
        val (_, url) = stealthQueue[stealthIdx]
        wv.loadUrl(url)
    }

    private fun extractFromStealthPage(wv: WebView) {
        val js = """
            (function() {
                try {
                    var txt = (document.body && document.body.innerText) ? document.body.innerText.trim() : '';
                    var kg = (txt.startsWith('{') && txt.indexOf('"results"') !== -1) ? txt : '';
                    var scripts = document.querySelectorAll('script[type="application/ld+json"]');
                    var lds = [];
                    for (var i = 0; i < scripts.length; i++) {
                        var c = scripts[i].textContent || '';
                        if (c.trim().length > 0) lds.push(c.trim());
                    }
                    return JSON.stringify({ kg: kg, ld: lds });
                } catch (e) {
                    return JSON.stringify({ kg: '', ld: [] });
                }
            })();
        """.trimIndent()

        wv.evaluateJavascript(js) { rawResult ->
            if (isFinishing || isDestroyed) return@evaluateJavascript
            val sourceName = stealthQueue.getOrNull(stealthIdx)?.first ?: "Афиша"
            var gotCount = 0
            runCatching {
                val unquoted = JSONObject("{\"v\":$rawResult}").optString("v", "")
                if (unquoted.startsWith("{")) {
                    val payload = JSONObject(unquoted)
                    val kg = payload.optString("kg", "")
                    val ldArr = payload.optJSONArray("ld")?.toString() ?: "[]"
                    val imported = EventsProvider.ingestFromWebView(this, sourceName, kg, ldArr, null)
                    gotCount = imported.size
                    if (imported.isNotEmpty()) {
                        events = imported
                        lastError = null
                        statusView.text = EventsProvider.statusLine(this)
                        render()
                    }
                }
            }
            if (gotCount > 0) {
                stealthRunning = false
            } else {
                stealthIdx++
                loadNextStealthSource()
            }
        }
    }

    private fun render() {
        listBox.removeAllViews()
        val filtered = if (selectedCat == "all") events else events.filter { it.catKey == selectedCat }

        if (filtered.isEmpty()) {
            val emptyCard = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                background = rounded(p.card, dp(16).toFloat(), p.stroke, dp(1))
                setPadding(dp(16), dp(16), dp(16), dp(16))
            }
            val msg = when {
                stealthRunning -> "Пробуем загрузить мероприятия Москвы через браузерный движок…"
                lastError != null -> lastError!!
                events.isEmpty() -> "Загружаем актуальные мероприятия Москвы…"
                else -> "В выбранной категории пока нет ближайших мероприятий."
            }
            emptyCard.addView(tv(msg, 13.5f, p.sub))
            val retry = tv("↻ Повторить загрузку", 14f, Color.WHITE, true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(12), dp(10), dp(12), dp(10))
                background = rounded(p.accent, dp(12).toFloat())
                setOnClickListener { loadEvents(true) }
            }
            emptyCard.addView(retry, LinearLayout.LayoutParams(matchP, wrapP).apply { topMargin = dp(12) })
            val openWeb = tv("🌐 Открыть встроенную афишу", 14f, p.text, true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(12), dp(10), dp(12), dp(10))
                background = rounded(p.cardAlt, dp(12).toFloat(), p.stroke, dp(1))
                setOnClickListener { switchMode(true) }
            }
            emptyCard.addView(openWeb, LinearLayout.LayoutParams(matchP, wrapP).apply { topMargin = dp(8) })
            listBox.addView(emptyCard, LinearLayout.LayoutParams(matchP, wrapP))
            addExternalSourcesFooter()
            return
        }

        val today = LocalDate.now(msk)
        val tomorrow = today.plusDays(1)
        val dateFmt = DateTimeFormatter.ofPattern("d MMMM", Locale("ru"))
        val dowFmt = DateTimeFormatter.ofPattern("EEEE", Locale("ru"))

        val grouped = filtered.groupBy { it.dateIso }
        for ((iso, dayEvents) in grouped) {
            val ld = runCatching { LocalDate.parse(iso) }.getOrNull()
            val headerTitle = when {
                ld == null -> iso
                ld == today -> "Сегодня · ${today.format(dateFmt)}"
                ld == tomorrow -> "Завтра · ${tomorrow.format(dateFmt)}"
                else -> "${ld.format(dowFmt).replaceFirstChar { it.uppercase() }} · ${ld.format(dateFmt)}"
            }
            listBox.addView(
                tv(headerTitle, 17f, p.text, true).apply {
                    setPadding(dp(2), dp(12), 0, dp(8))
                }
            )
            for (ev in dayEvents) {
                listBox.addView(
                    buildEventCard(ev),
                    LinearLayout.LayoutParams(matchP, wrapP).apply { bottomMargin = dp(10) }
                )
            }
        }
        addExternalSourcesFooter()
    }

    private fun buildEventCard(ev: LiveEvent): View {
        val card = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            background = rounded(p.card, dp(16).toFloat(), p.stroke, dp(1))
        }

        val stripe = View(ctx).apply {
            val r = dp(16).toFloat()
            background = GradientDrawable().apply {
                setColor(ev.accentColor)
                cornerRadii = floatArrayOf(r, r, 0f, 0f, 0f, 0f, r, r)
            }
        }
        card.addView(stripe, LinearLayout.LayoutParams(dp(4), matchP))

        val body = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(12), dp(14), dp(14), dp(14))
        }

        val timeCol = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            minimumWidth = dp(64)
        }
        timeCol.addView(
            tv(
                ev.timeLabel,
                if (ev.hasExactTime) 19f else 14f,
                if (ev.hasExactTime) p.blue else p.sub,
                true
            ).apply { gravity = Gravity.CENTER }
        )
        timeCol.addView(
            tv(ev.catIcon, 16f, p.sub).apply {
                gravity = Gravity.CENTER
                setPadding(0, dp(6), 0, 0)
            }
        )
        body.addView(timeCol, LinearLayout.LayoutParams(dp(66), wrapP).apply { rightMargin = dp(10) })

        val infoCol = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }

        val titleRow = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.TOP
        }
        titleRow.addView(tv("⚡", 15f, ev.accentColor, true).apply { setPadding(0, 0, dp(6), 0) })
        titleRow.addView(
            tv(ev.title, 16f, p.text, true).apply {
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
            },
            LinearLayout.LayoutParams(0, wrapP, 1f)
        )
        infoCol.addView(titleRow, LinearLayout.LayoutParams(matchP, wrapP))

        infoCol.addView(
            tv(ev.venue, 13.5f, p.sub).apply {
                setPadding(0, dp(3), 0, dp(8))
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
            }
        )

        if (ev.address.isNotBlank()) {
            val addrBox = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = rounded(p.cardAlt, dp(12).toFloat(), withAlpha(p.stroke, 0.7f), dp(1))
                setPadding(dp(10), dp(8), dp(10), dp(8))
                setOnClickListener { OrderOfferReader.openAddressInMaps(ctx, ev.address) }
            }
            addrBox.addView(tv("📍", 13f, p.blue).apply { setPadding(0, 0, dp(6), 0) })
            addrBox.addView(
                tv(ev.address, 12.5f, p.text).apply {
                    maxLines = 2
                    ellipsize = TextUtils.TruncateAt.END
                },
                LinearLayout.LayoutParams(0, wrapP, 1f)
            )
            val copyBtn = tv("⧉", 17f, p.sub, true).apply {
                setPadding(dp(10), dp(2), dp(2), dp(2))
                setOnClickListener {
                    val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("address", ev.address))
                    Toast.makeText(ctx, "Адрес скопирован: ${ev.address}", Toast.LENGTH_SHORT).show()
                }
            }
            addrBox.addView(copyBtn)
            infoCol.addView(addrBox, LinearLayout.LayoutParams(matchP, wrapP))
        }

        body.addView(infoCol, LinearLayout.LayoutParams(0, wrapP, 1f))
        card.addView(body, LinearLayout.LayoutParams(0, wrapP, 1f))
        card.setOnClickListener {
            if (ev.address.isNotBlank()) {
                OrderOfferReader.openAddressInMaps(ctx, ev.address)
            } else if (ev.siteUrl.isNotBlank()) {
                runCatching { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(ev.siteUrl))) }
            }
        }
        return card
    }

    private fun addExternalSourcesFooter() {
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(10), 0, dp(4))
        }
        val links = listOf(
            "Яндекс Афиша ↗" to "https://afisha.yandex.ru/moscow/events",
            "Timepad ↗" to "https://afisha.timepad.ru/moscow"
        )
        links.forEachIndexed { idx, (label, url) ->
            val btn = tv(label, 12.5f, p.accent, true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(10), dp(9), dp(10), dp(9))
                background = rounded(p.card, dp(12).toFloat(), p.stroke, dp(1))
                setOnClickListener {
                    runCatching { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
                }
            }
            row.addView(
                btn,
                LinearLayout.LayoutParams(0, wrapP, 1f).apply {
                    if (idx == 0) rightMargin = dp(8)
                }
            )
        }
        listBox.addView(row, LinearLayout.LayoutParams(matchP, wrapP))
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (webMode && ::browserWeb.isInitialized && browserWeb.canGoBack()) {
            browserWeb.goBack()
        } else {
            super.onBackPressed()
        }
    }

    override fun onDestroy() {
        stealthRunning = false
        handler.removeCallbacksAndMessages(null)
        stealthWeb?.destroy()
        stealthWeb = null
        if (::browserWeb.isInitialized) browserWeb.destroy()
        super.onDestroy()
    }
}
