# Surge Radar v1.2

Android-приложение для тестового радара коэффициента с прогнозом всплеска.

## Сборка через GitHub с телефона

В репозитории достаточно хранить любой один ZIP с проектом (имя не важно) в корне и workflow `.github/workflows/build.yml`. Можно также залить файлы проекта прямо в корень репозитория, без ZIP.
Workflow не использует `android-actions/setup-android`, чтобы не попадать на ошибку установки устаревшего пакета `tools`. Android SDK берётся с GitHub-hosted runner.

После запуска `Actions -> Build Surge Radar APK -> Run workflow` APK будет доступен в `Artifacts -> SurgeRadar-debug`.
