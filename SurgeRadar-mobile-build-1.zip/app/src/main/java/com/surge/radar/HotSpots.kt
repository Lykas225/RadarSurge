package com.surge.radar

import android.content.Context
import kotlin.math.max
import kotlin.math.min

class HotSpot(val poi: Poi, val pct: Int, val reason: String, val live: Boolean)

/**
 * Горячие места: аэропорты, вокзалы, концерты, больницы. Место попадает в список, когда его коэффициент
 * дошёл до выбранного порога. Аэропорты и вокзалы усиливаются расписанием прибытий, концерты временем
 * начала и окончания, больницы временем смены персонала.
 */
object HotSpots {

    fun refreshAsync(ctx: Context, force: Boolean = false, onDone: (() -> Unit)? = null) {
        val cfg = WidgetSettings.load(ctx)
        if (!cfg.schedOnline) return
        if ((cfg.hotCats and (PoiKind.AIRPORT.bit or PoiKind.STATION.bit)) != 0) {
            ScheduleProvider.refreshAsync(ctx, PoiCatalog.byKinds(cfg.hotCats), force, onDone)
        }
        if ((cfg.hotCats and PoiKind.EVENT.bit) != 0) {
            EventsProvider.refreshAsync(force, onDone)
        }
    }

    fun statusLine(ctx: Context): String =
        "Рейсы и поезда: ${ScheduleProvider.status(ctx)}\nКонцерты: ${EventsProvider.status()}"

    private fun km(a: Poi, lat: Double, lon: Double) = MoscowRegionGrid.distanceKm(a.lat, a.lon, lat, lon)

    fun compute(ctx: Context, cfg: WidgetSettings.Values, now: Long = System.currentTimeMillis()): List<HotSpot> {
        val tariffs = cfg.enabledTariffs()
        if (tariffs.isEmpty()) return emptyList()
        val result = ArrayList<HotSpot>()
        val min10 = 10 * 60_000L
        val min20 = 20 * 60_000L
        val min30 = 30 * 60_000L

        for (poi in PoiCatalog.byKinds(cfg.hotCats)) {
            val zone = MoscowRegionGrid.nearest(poi.lat, poi.lon)
            var base = DemandModel.baseCoeff(zone, now)
            var reason = ""
            var live = false

            when (poi.kind) {
                PoiKind.AIRPORT, PoiKind.STATION -> {
                    val kind = if (poi.kind == PoiKind.AIRPORT) DemandModel.Kind.AIRPORT else DemandModel.Kind.STATION
                    base = max(base, DemandModel.kindCoeff(kind, now))
                    val n = ScheduleProvider.arrivalsBetween(poi, now - min10, now + min30)
                    if (n != null) {
                        val per = if (poi.kind == PoiKind.AIRPORT) 0.05 else 0.08
                        base += min(0.8, n * per)
                        reason = (if (poi.kind == PoiKind.AIRPORT) "прилётов" else "поездов") + " за 30 мин: $n"
                        live = true
                    } else {
                        reason = "по времени суток"
                    }
                }
                PoiKind.EVENT -> {
                    var boost = 0.0
                    for (e in EventsProvider.list()) {
                        if (km(poi, e.lat, e.lon) > 1.2) continue
                        val capBoost = min(0.9, poi.capacity / 15000.0 * 0.9)
                        if (now in (e.endMs - min20)..(e.endMs + min30)) {
                            val b = 0.5 + capBoost
                            if (b > boost) {
                                boost = b
                                reason = "«${e.title.take(28)}» заканчивается ~${DemandModel.mskTime(e.endMs)}"
                                live = true
                            }
                        } else if (now in (e.startMs - 75 * 60_000L)..(e.startMs - min10)) {
                            val b = 0.25 + 0.5 * capBoost
                            if (b > boost) {
                                boost = b
                                reason = "«${e.title.take(28)}» начало ${DemandModel.mskTime(e.startMs)}"
                                live = true
                            }
                        }
                    }
                    if (boost <= 0.0) continue
                    base += boost
                }
                PoiKind.HOSPITAL -> {
                    val m = DemandModel.mskMinutes(now)
                    when {
                        m in 450..555 || m in 1170..1260 -> {
                            base += 0.45
                            reason = "смена персонала"
                        }
                        m in 930..1140 -> {
                            base += 0.2
                            reason = "часы посещений"
                        }
                        else -> reason = "обычный поток"
                    }
                }
            }

            val pct = DemandModel.maxPct(min(3.0, base), tariffs)
            if (pct >= cfg.hotMin) result.add(HotSpot(poi, pct, reason, live))
        }
        return result.sortedByDescending { it.pct }
    }
}
