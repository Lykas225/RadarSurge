package com.surge.radar

import android.content.Context
import java.util.Locale
import java.util.regex.Pattern

data class SurgeReading(
    val rawCoeff: Double,
    val baseEconomCoeff: Double,
    val tariff: OrderTariff,
    val bonusRub: Int,
    val source: String
)

/**
 * Точный парсер коэффициента спроса из экрана и уведомлений Яндекс Про:
 * - Не срабатывает на русские слова с «х» («в заказах 2», «в рублях 350», «в 2х минутах»).
 * - Игнорирует приоритет, баллы, баланс, цели и промо-бонусы.
 * - Поддерживает форматы: «×1.71», «1.71×», «x1.5», «кэф 1.6», а также рублёвые доплаты «+180 ₽».
 * - Нормализует считанный кэф по тарифу (например, Комфорт ×1.71 → база Эконома 1.84),
 *   чтобы при показе Комфорта не происходило повторное занижение на ×0.85.
 */
object SurgeSignalReader {

    private val nonSurgeWords = listOf(
        "баланс", "доход", "заработ", "выплат", "на счёте", "на счете",
        "цель", "бонус", "гарант", "смен", "комисси", "штраф", "подписк",
        "лимит", "долг", "чаев", "промо", "приоритет", "балл", "активност",
        "уровень", "рейтинг", "другу", "приглас", "вывести", "история"
    )

    private val surgeContextWords = listOf(
        "спрос", "доплат", "кэф", "коэффициент", "зона", "повыш", "пик", "горяч", "принять"
    )

    /**
     * Знак «×» (U+00D7) может идти с целым или дробным числом (×1.71, ×2),
     * а обычные буквы x / х — ТОЛЬКО с десятичной дробью и границей слова (x1.5, х2.1),
     * чтобы полностью исключить «в заказах 2», «в рублях 350», «в 2х минутах».
     */
    private val prefixMultPattern = Pattern.compile(
        "(?<![а-яёa-z0-9])(?:×\\s*([1-5](?:[.,]\\d{1,2})?)|[xх]\\s*([1-5][.,]\\d{1,2}))(?![а-яёa-z0-9])",
        Pattern.CASE_INSENSITIVE or Pattern.UNICODE_CASE
    )
    private val suffixMultPattern = Pattern.compile(
        "(?<![а-яёa-z0-9])([1-5][.,]\\d{1,2})\\s*(?:×|x|х)(?![а-яёa-z0-9])",
        Pattern.CASE_INSENSITIVE or Pattern.UNICODE_CASE
    )
    private val wordMultPattern = Pattern.compile(
        "(?:кэф|коэффициент|спрос)\\s*[:—–-]?\\s*([1-5](?:[.,]\\d{1,2})?)",
        Pattern.CASE_INSENSITIVE or Pattern.UNICODE_CASE
    )
    private val bonusRubPattern = Pattern.compile(
        "\\+\\s*(\\d{2,4})\\s*(?:₽|руб(?:\\.|лей|ля)?)",
        Pattern.CASE_INSENSITIVE or Pattern.UNICODE_CASE
    )

    /** Опорная средняя стоимость поездки по Москве для перевода «+N ₽» в эквивалентный кэф. */
    private fun baseTripRefRub(tariff: OrderTariff): Double = when (tariff) {
        OrderTariff.ECONOM -> 360.0
        OrderTariff.COMFORT -> 460.0
        OrderTariff.COMFORT_PLUS -> 580.0
        OrderTariff.KIDS -> 480.0
        OrderTariff.BUSINESS -> 900.0
        OrderTariff.MINIVAN -> 720.0
        OrderTariff.DELIVERY -> 340.0
    }

    fun normalizeToEconomBase(rawCoeff: Double, tariff: OrderTariff): Double {
        val k = tariff.surgeK.coerceIn(0.5, 1.0)
        return (1.0 + (rawCoeff - 1.0) / k).coerceIn(1.0, 5.0)
    }

    fun bonusToCoeff(bonusRub: Int, tariff: OrderTariff): Double =
        (1.0 + bonusRub.toDouble() / baseTripRefRub(tariff)).coerceIn(1.05, 4.5)

    fun extractFromScreen(
        context: Context,
        texts: List<String>,
        offer: OrderOffer? = null,
        fromNotification: Boolean = false
    ): SurgeReading? {
        val fallbackTariff = WidgetSettings.load(context).enabledTariffs()
            .firstOrNull()?.let(OrderTariff::fromAppTariff) ?: OrderTariff.COMFORT
        val tariff = offer?.tariff ?: OrderTariffRates.detect(texts, fallbackTariff)

        // Если это распознанная карточка входящего заказа — её кэф/доплата имеют высший приоритет
        if (offer != null) {
            val offerMult = offer.surgeCoeff
            if (offerMult != null && offerMult in 1.0..5.0) {
                return SurgeReading(
                    rawCoeff = offerMult,
                    baseEconomCoeff = normalizeToEconomBase(offerMult, tariff),
                    tariff = tariff,
                    bonusRub = offer.surgeBonusRub,
                    source = "заказ ${tariff.shortTitle} ${String.format(Locale.US, "×%.2f", offerMult)}"
                )
            }
            if (offer.surgeBonusRub in 30..1500) {
                val eq = bonusToCoeff(offer.surgeBonusRub, tariff)
                return SurgeReading(
                    rawCoeff = eq,
                    baseEconomCoeff = normalizeToEconomBase(eq, tariff),
                    tariff = tariff,
                    bonusRub = offer.surgeBonusRub,
                    source = "заказ ${tariff.shortTitle} +${offer.surgeBonusRub}₽"
                )
            }
            // Входящий заказ пришёл БЕЗ коэффициента и БЕЗ доплаты — фиксируем спокойный спрос ×1.0!
            return SurgeReading(
                rawCoeff = 1.0,
                baseEconomCoeff = 1.0,
                tariff = tariff,
                bonusRub = 0,
                source = "заказ ${tariff.shortTitle} без кэфа (×1.0)"
            )
        }

        // Поиск на обычном экране карты Яндекс Про или в push-уведомлении
        val mults = ArrayList<Double>(4)
        var bestBonus = 0

        for (raw in texts) {
            val line = raw.trim()
            if (line.length < 2) continue
            val low = line.lowercase()
            if (nonSurgeWords.any { low.contains(it) }) continue

            val norm = line.replace(',', '.')
            val pm = prefixMultPattern.matcher(norm)
            while (pm.find()) {
                val g = pm.group(1) ?: pm.group(2) ?: continue
                val v = g.toDoubleOrNull()
                if (v != null && v in 1.0..5.0) mults.add(v)
            }
            val sm = suffixMultPattern.matcher(norm)
            while (sm.find()) {
                val v = sm.group(1)?.toDoubleOrNull()
                if (v != null && v in 1.0..5.0) mults.add(v)
            }
            val wm = wordMultPattern.matcher(norm)
            while (wm.find()) {
                val v = wm.group(1)?.toDoubleOrNull()
                if (v != null && v in 1.0..5.0) mults.add(v)
            }

            // Рублёвая доплата на карте / баннере спроса / в уведомлении
            val allowBonus = fromNotification || line.length <= 24 || surgeContextWords.any { low.contains(it) }
            if (allowBonus) {
                val bm = bonusRubPattern.matcher(line)
                while (bm.find()) {
                    val b = bm.group(1)?.toIntOrNull()
                    if (b != null && b in 30..1500) {
                        bestBonus = maxOf(bestBonus, b)
                    }
                }
            }
        }

        val bestMult = mults.maxOrNull()
        if (bestMult != null) {
            val tag = if (fromNotification) "уведомление" else "экран"
            return SurgeReading(
                rawCoeff = bestMult,
                baseEconomCoeff = normalizeToEconomBase(bestMult, tariff),
                tariff = tariff,
                bonusRub = bestBonus,
                source = "$tag ${tariff.shortTitle} ${String.format(Locale.US, "×%.2f", bestMult)}"
            )
        }
        if (bestBonus in 30..1500) {
            val eq = bonusToCoeff(bestBonus, tariff)
            val tag = if (fromNotification) "уведомление" else "экран"
            return SurgeReading(
                rawCoeff = eq,
                baseEconomCoeff = normalizeToEconomBase(eq, tariff),
                tariff = tariff,
                bonusRub = bestBonus,
                source = "$tag ${tariff.shortTitle} +${bestBonus}₽"
            )
        }
        return null
    }
}
