package com.surge.radar

import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Тарифная сетка Москвы для расчёта стоимости поездки по поступившему тарифу,
 * когда на карточке заказа в Яндекс Про указаны маршрут и тариф, но скрыта фиксированная цена.
 */
enum class OrderTariff(
    val title: String,
    val shortTitle: String,
    val baseRub: Double,
    val includedMin: Double,
    val includedKm: Double,
    val perMin: Double,
    val perKm: Double,
    val minPrice: Double,
    val surgeK: Double
) {
    ECONOM("Эконом", "Эко", 149.0, 3.0, 1.0, 11.0, 11.0, 159.0, 1.0),
    COMFORT("Комфорт", "Ком", 199.0, 3.0, 1.0, 14.0, 14.0, 229.0, 0.85),
    COMFORT_PLUS("Комфорт+", "Ком+", 269.0, 3.0, 1.0, 18.0, 18.0, 299.0, 0.75),
    KIDS("Детский", "Дет", 219.0, 3.0, 1.0, 15.0, 15.0, 249.0, 0.85),
    BUSINESS("Бизнес", "Биз", 399.0, 3.0, 1.0, 28.0, 28.0, 449.0, 0.65),
    MINIVAN("Минивэн", "Вэн", 349.0, 3.0, 1.0, 22.0, 22.0, 399.0, 0.75),
    DELIVERY("Доставка", "Дост", 159.0, 3.0, 1.0, 10.0, 10.0, 169.0, 0.90);

    companion object {
        fun fromAppTariff(t: Tariff): OrderTariff = when (t) {
            Tariff.ECONOM -> ECONOM
            Tariff.COMFORT -> COMFORT
            Tariff.COMFORT_PLUS -> COMFORT_PLUS
        }

        fun byNameOrDefault(name: String?): OrderTariff =
            values().firstOrNull { it.name == name } ?: COMFORT
    }
}

object OrderTariffRates {

    fun detect(texts: List<String>, fallback: OrderTariff = OrderTariff.COMFORT): OrderTariff {
        val joined = texts.joinToString(" | ").lowercase()
        return when {
            joined.contains("комфорт+") || joined.contains("комфорт +") ||
                joined.contains("комфорт плюс") || joined.contains("comfort+") -> OrderTariff.COMFORT_PLUS
            joined.contains("бизнес") || joined.contains("business") ||
                joined.contains("ultima") || joined.contains("premier") -> OrderTariff.BUSINESS
            joined.contains("минивэн") || joined.contains("minivan") -> OrderTariff.MINIVAN
            joined.contains("детский") || joined.contains("kids") -> OrderTariff.KIDS
            joined.contains("доставка") || joined.contains("курьер") ||
                joined.contains("экспресс") -> OrderTariff.DELIVERY
            joined.contains("комфорт") || joined.contains("comfort") -> OrderTariff.COMFORT
            joined.contains("эконом") || joined.contains("econom") -> OrderTariff.ECONOM
            else -> fallback
        }
    }

    /** Расчётная стоимость поездки в рублях (округление до 10 ₽). */
    fun estimatePriceRub(
        tariff: OrderTariff,
        tripMin: Double,
        tripKm: Double,
        surgeCoeff: Double,
        surgeBonusRub: Int
    ): Int {
        val extraMin = max(0.0, tripMin - tariff.includedMin)
        val extraKm = max(0.0, tripKm - tariff.includedKm)
        val raw = tariff.baseRub + extraMin * tariff.perMin + extraKm * tariff.perKm
        val effCoeff = surgeCoeff.coerceIn(1.0, 4.0)
        val total = max(tariff.minPrice, raw) * effCoeff + max(0, surgeBonusRub)
        return ((total / 10.0).roundToInt() * 10).coerceAtLeast(tariff.minPrice.roundToInt())
    }

    /**
     * Когда точка Б скрыта, но цена на карточке есть: восстанавливаем примерную длину поездки,
     * обращая формулу тарифа. Возвращает (км, минуты) или null, если цена слишком мала.
     */
    fun inferTrip(
        tariff: OrderTariff,
        priceRub: Double,
        surgeCoeff: Double,
        surgeBonusRub: Int,
        speedKmh: Double
    ): Pair<Double, Int>? {
        val coeff = surgeCoeff.coerceIn(1.0, 4.0)
        val raw = (priceRub - max(0, surgeBonusRub)) / coeff
        if (raw <= tariff.minPrice) return null
        val speed = max(10.0, speedKmh)
        val perKmEff = tariff.perKm + tariff.perMin * 60.0 / speed
        val km = (raw - tariff.baseRub + tariff.perMin * tariff.includedMin + tariff.perKm * tariff.includedKm) / perKmEff
        if (km < 1.0) return null
        val kmClamped = km.coerceIn(1.0, 150.0)
        val minutes = max(4, (kmClamped / speed * 60.0).roundToInt())
        return Pair((kmClamped * 10.0).roundToInt() / 10.0, minutes)
    }
}
