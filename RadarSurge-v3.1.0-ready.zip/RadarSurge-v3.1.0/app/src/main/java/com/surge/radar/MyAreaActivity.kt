package com.surge.radar

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doAfterTextChanged
import java.util.Locale

/**
 * Экран «🎯 Мой район» — помощник для режима Яндекс Про «Мой район».
 *
 * Что делает: считает, окупается ли повышенная комиссия в выбранном радиусе, подсказывает лучшее
 * время и место включения, ведёт таймер и дневной лимит режима, рисует район на карте и включает
 * повышенную комиссию в оценку заказов. Сам режим включается в Яндекс Про («Заказы по пути → Мой район»).
 */
class MyAreaActivity : AppCompatActivity() {

    private val ctx: Context get() = this
    private val matchP = ViewGroup.LayoutParams.MATCH_PARENT
    private val wrapP = ViewGroup.LayoutParams.WRAP_CONTENT
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var p: Palette
    private lateinit var statusBox: LinearLayout
    private lateinit var dynBox: LinearLayout
    private lateinit var centerRow: LinearLayout
    private lateinit var durRow: LinearLayout
    private lateinit var radiusLabel: TextView
    private lateinit var centerNote: TextView
    private lateinit var extraValue: TextView
    private lateinit var limitValue: TextView
    private lateinit var startBtn: TextView

    private var countdown: TextView? = null
    private var bar: ProgressBar? = null
    private var inAreaText: TextView? = null

    private var myLoc: Location? = null
    private var radiusKm = 3.0f
    private var minutes = 60
    private var centerMode = 0
    private var customZone: String? = null

    private class Center(val lat: Double, val lon: Double, val name: String, val note: String?)

    private val locationListener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            val first = myLoc == null
            myLoc = location
            if (first || centerMode == 0) scheduleRender()
        }

        @Deprecated("Deprecated in Java")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
    }

    private val renderRunnable = Runnable { renderDynamic() }

    private val ticker = object : Runnable {
        override fun run() {
            tick()
            handler.postDelayed(this, 1000L)
        }
    }

    private val slowTick = object : Runnable {
        override fun run() {
            renderDynamic()
            handler.postDelayed(this, 60_000L)
        }
    }

    private fun dp(v: Int): Int = dpi(v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        p = Palette(WidgetSettings.load(this).dark)
        radiusKm = MyArea.radiusKm(this)
        minutes = MyArea.durationMin(this)
        centerMode = MyArea.centerMode(this)
        customZone = MyArea.customZone(this)
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        startLocation()
        renderStatus()
        renderDynamic()
        handler.removeCallbacks(ticker)
        handler.post(ticker)
        handler.removeCallbacks(slowTick)
        handler.postDelayed(slowTick, 60_000L)
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        handler.removeCallbacks(slowTick)
        handler.removeCallbacks(renderRunnable)
        runCatching {
            (getSystemService(LOCATION_SERVICE) as LocationManager).removeUpdates(locationListener)
        }
        super.onPause()
    }

    // ----- Местоположение -----

    private fun hasLocationPermission(): Boolean =
        checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    private fun startLocation() {
        if (!hasLocationPermission()) return
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        try {
            val last = listOf(
                LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER
            ).mapNotNull { runCatching { lm.getLastKnownLocation(it) }.getOrNull() }.maxByOrNull { it.time }
            if (last != null && System.currentTimeMillis() - last.time < 30 * 60_000L) myLoc = last
            val main = Looper.getMainLooper()
            if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 15_000L, 50f, locationListener, main)
            }
            if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 15_000L, 50f, locationListener, main)
            }
            lm.requestLocationUpdates(LocationManager.PASSIVE_PROVIDER, 0L, 0f, locationListener, main)
        } catch (_: SecurityException) {
        }
    }

    private fun pinnedZone(): SurgeZone {
        val cfg = WidgetSettings.load(this)
        return MoscowRegionGrid.zones.firstOrNull { it.name == cfg.zone } ?: MoscowRegionGrid.zones.first()
    }

    private fun resolveCenter(): Center {
        val pinned = pinnedZone()
        return when (centerMode) {
            0 -> {
                val l = myLoc
                if (l != null) {
                    val z = MoscowRegionGrid.nearest(l.latitude, l.longitude)
                    Center(l.latitude, l.longitude, "вы · ${z.name.removePrefix("МО: ")}", null)
                } else {
                    val why = if (hasLocationPermission()) "Нет сигнала GPS" else "Нет доступа к геопозиции"
                    Center(pinned.lat, pinned.lon, pinned.name.removePrefix("МО: "), "$why — взята закреплённая зона")
                }
            }
            2 -> {
                val z = MoscowRegionGrid.zones.firstOrNull { it.name == customZone } ?: pinned
                Center(
                    z.lat, z.lon, z.name.removePrefix("МО: "),
                    "Яндекс строит район вокруг вас: чтобы включить режим здесь, сначала приезжайте в эту зону"
                )
            }
            else -> Center(pinned.lat, pinned.lon, pinned.name.removePrefix("МО: "), null)
        }
    }

    private fun meLatLon(c: Center): Pair<Double, Double> {
        val l = myLoc
        return if (l != null) Pair(l.latitude, l.longitude) else Pair(c.lat, c.lon)
    }

    // ----- Построение интерфейса -----

    private fun tv(t: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(ctx).apply {
            text = t
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun card(): LinearLayout = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(p.card, dp(18).toFloat(), p.stroke, dp(1))
        setPadding(dp(14), dp(12), dp(14), dp(14))
    }

    private fun cardParams(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(matchP, wrapP).apply { topMargin = dp(10) }

    private fun button(t: String, filled: Boolean, onClick: () -> Unit): TextView =
        TextView(ctx).apply {
            text = t
            textSize = 14.5f
            gravity = Gravity.CENTER
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            setTextColor(if (filled) Color.WHITE else p.text)
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = if (filled) {
                GradientDrawable(
                    GradientDrawable.Orientation.LEFT_RIGHT,
                    intArrayOf(0xFF6A3FD0.toInt(), 0xFF3A7BD5.toInt())
                ).apply { cornerRadius = dp(14).toFloat() }
            } else rounded(p.cardAlt, dp(14).toFloat(), p.stroke, dp(1))
            setOnClickListener { onClick() }
        }

    private fun chip(t: String, selected: Boolean, onClick: () -> Unit): TextView =
        TextView(ctx).apply {
            text = t
            textSize = 13.5f
            gravity = Gravity.CENTER
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            setTextColor(if (selected) Color.WHITE else p.text)
            setPadding(dp(10), dp(9), dp(10), dp(9))
            background = if (selected) rounded(0xFF6A3FD0.toInt(), dp(12).toFloat())
            else rounded(p.cardAlt, dp(12).toFloat(), p.stroke, dp(1))
            setOnClickListener { onClick() }
        }

    private fun pill(t: String, color: Int, size: Float = 14.5f): TextView =
        tv(t, size, color, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(3), dp(10), dp(3))
            background = rounded(withAlpha(color, 0.16f), dp(12).toFloat(), withAlpha(color, 0.55f), dp(1))
        }

    private fun sectionTitle(t: String): TextView = tv(t, 15.5f, p.text, true)

    private fun buildUi() {
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(p.bg)
        }

        val top = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(10), dp(14), dp(6))
        }
        top.addView(tv("←", 24f, p.text, true).apply {
            setPadding(dp(12), dp(4), dp(12), dp(4))
            setOnClickListener { finish() }
        })
        val titles = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        titles.addView(tv("🎯 Мой район", 20f, p.text, true))
        titles.addView(tv("Помощник для режима Яндекс Про", 12f, p.sub))
        top.addView(titles, LinearLayout.LayoutParams(0, wrapP, 1f))
        root.addView(top, LinearLayout.LayoutParams(matchP, wrapP))

        val scroll = ScrollView(ctx).apply { isVerticalScrollBarEnabled = false }
        val content = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(2), dp(14), dp(28))
        }
        scroll.addView(content, ViewGroup.LayoutParams(matchP, wrapP))
        root.addView(scroll, LinearLayout.LayoutParams(matchP, 0, 1f))

        // 1. Статус сессии (динамический)
        statusBox = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        content.addView(statusBox, LinearLayout.LayoutParams(matchP, wrapP).apply { topMargin = dp(6) })

        // 2. Настройка района
        val setup = card()
        setup.addView(sectionTitle("Центр района"))
        centerRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        setup.addView(centerRow, LinearLayout.LayoutParams(matchP, wrapP).apply { topMargin = dp(8) })
        centerNote = tv("", 12f, p.sub).apply { setPadding(dp(2), dp(6), dp(2), 0) }
        setup.addView(centerNote)

        radiusLabel = tv("", 15f, p.text, true).apply { setPadding(0, dp(14), 0, 0) }
        setup.addView(radiusLabel)
        val seek = SeekBar(ctx).apply {
            max = 28 // 1.0 … 15.0 км, шаг 0.5
            progress = ((radiusKm - 1.0f) / 0.5f).toInt().coerceIn(0, 28)
            progressTintList = ColorStateList.valueOf(0xFFB388FF.toInt())
            thumbTintList = ColorStateList.valueOf(0xFFB388FF.toInt())
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, value: Int, fromUser: Boolean) {
                    radiusKm = 1.0f + value * 0.5f
                    MyArea.setRadiusKm(ctx, radiusKm)
                    updateRadiusLabel()
                    if (fromUser) scheduleRender()
                }

                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        setup.addView(seek, LinearLayout.LayoutParams(matchP, wrapP).apply { topMargin = dp(2) })
        setup.addView(
            tv("Радиус — ползунок «Укажите радиус работы» в Яндекс Про.", 11.5f, p.sub)
        )

        setup.addView(tv("Время режима", 15f, p.text, true).apply { setPadding(0, dp(14), 0, dp(6)) })
        durRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        setup.addView(durRow, LinearLayout.LayoutParams(matchP, wrapP))
        content.addView(setup, cardParams())

        // 3. Анализ (динамический)
        dynBox = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        content.addView(dynBox, LinearLayout.LayoutParams(matchP, wrapP))

        // 4. Параметры режима
        val params = card()
        params.addView(sectionTitle("Параметры режима"))
        extraValue = tv("", 15f, p.accent, true).apply { gravity = Gravity.CENTER }
        limitValue = tv("", 15f, p.accent, true).apply { gravity = Gravity.CENTER }
        params.addView(
            stepperRow("Надбавка к комиссии", extraValue,
                { MyArea.setExtraComm(ctx, MyArea.extraComm(ctx) - 1); updateParams(); scheduleRender() },
                { MyArea.setExtraComm(ctx, MyArea.extraComm(ctx) + 1); updateParams(); scheduleRender() }),
            LinearLayout.LayoutParams(matchP, wrapP).apply { topMargin = dp(8) }
        )
        params.addView(
            stepperRow("Лимит режима в сутки", limitValue,
                { MyArea.setDailyLimitMin(ctx, MyArea.dailyLimitMin(ctx) - 15); updateParams(); renderStatus() },
                { MyArea.setDailyLimitMin(ctx, MyArea.dailyLimitMin(ctx) + 15); updateParams(); renderStatus() }),
            LinearLayout.LayoutParams(matchP, wrapP).apply { topMargin = dp(6) }
        )
        params.addView(
            tv(
                "В режиме комиссия Яндекса выше обычной, а время в сутки ограничено. Точные цифры " +
                    "зависят от города и могут меняться — сверьтесь в Яндекс Про и поправьте здесь.",
                11.5f, p.sub
            ).apply { setPadding(0, dp(8), 0, 0) }
        )
        content.addView(params, cardParams())

        // 5. Действия
        startBtn = button("", true) { onStartStop() }
        content.addView(startBtn, LinearLayout.LayoutParams(matchP, wrapP).apply { topMargin = dp(12) })
        content.addView(button("🗺 Показать район на карте", false) { showOnMap() },
            LinearLayout.LayoutParams(matchP, wrapP).apply { topMargin = dp(8) })
        content.addView(button("Открыть Яндекс Про", false) { openYandex() },
            LinearLayout.LayoutParams(matchP, wrapP).apply { topMargin = dp(8) })
        content.addView(
            tv(
                "Оценки спроса — расчёт приложения по времени суток, погоде и данным, которые удалось " +
                    "прочитать в Яндекс Про. Это не официальные коэффициенты Яндекса.",
                11f, p.sub
            ).apply { setPadding(dp(4), dp(12), dp(4), 0) }
        )

        setContentView(root)
        rebuildCenterChips()
        rebuildDurChips()
        updateRadiusLabel()
        updateParams()
    }

    private fun stepperRow(
        label: String,
        value: TextView,
        onMinus: () -> Unit,
        onPlus: () -> Unit
    ): LinearLayout {
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        row.addView(tv(label, 14f, p.text), LinearLayout.LayoutParams(0, wrapP, 1f))
        fun stepBtn(sym: String, act: () -> Unit) = tv(sym, 20f, p.text, true).apply {
            gravity = Gravity.CENTER
            background = rounded(p.cardAlt, dp(12).toFloat(), p.stroke, dp(1))
            setOnClickListener { act() }
        }
        row.addView(stepBtn("−", onMinus), LinearLayout.LayoutParams(dp(42), dp(40)))
        row.addView(value, LinearLayout.LayoutParams(dp(78), wrapP))
        row.addView(stepBtn("+", onPlus), LinearLayout.LayoutParams(dp(42), dp(40)))
        return row
    }

    private fun updateRadiusLabel() {
        radiusLabel.text = "Радиус: ${MyArea.fmtKm(radiusKm.toDouble())} км"
    }

    private fun updateParams() {
        extraValue.text = "+${MyArea.extraComm(this)}%"
        limitValue.text = "${MyArea.dailyLimitMin(this)} мин"
    }

    private fun rebuildCenterChips() {
        centerRow.removeAllViews()
        val items = listOf(0 to "📍 Где я", 1 to "📌 Закреплённая", 2 to "🔎 Другая")
        for ((mode, title) in items) {
            val c = chip(title, centerMode == mode) {
                if (mode == 2) {
                    pickZone()
                } else {
                    centerMode = mode
                    MyArea.setCenterMode(ctx, mode)
                    rebuildCenterChips()
                    scheduleRender()
                }
            }
            centerRow.addView(
                c,
                LinearLayout.LayoutParams(0, wrapP, 1f).apply { if (mode != 2) rightMargin = dp(6) }
            )
        }
    }

    private fun rebuildDurChips() {
        durRow.removeAllViews()
        val opts = listOf(30, 60, 90, 120)
        for ((i, m) in opts.withIndex()) {
            durRow.addView(
                chip("$m мин", minutes == m) {
                    minutes = m
                    MyArea.setDurationMin(ctx, m)
                    rebuildDurChips()
                },
                LinearLayout.LayoutParams(0, wrapP, 1f).apply { if (i != opts.lastIndex) rightMargin = dp(6) }
            )
        }
    }

    private fun pickZone() {
        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(8), dp(18), dp(8))
        }
        val input = EditText(ctx).apply {
            hint = "Название района или города"
            setSingleLine(true)
        }
        val list = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        box.addView(input)
        box.addView(ScrollView(ctx).apply { addView(list) }, LinearLayout.LayoutParams(matchP, dp(300)))

        val dialog = AlertDialog.Builder(this).setTitle("Выберите зону").setView(box)
            .setNegativeButton("Отмена", null).create()

        fun fill(q: String) {
            list.removeAllViews()
            val s = q.trim().lowercase(Locale.getDefault())
            val found = MoscowRegionGrid.zones
                .filter { DemandModel.kindOf(it) != DemandModel.Kind.AIRPORT }
                .filter { s.isEmpty() || it.name.lowercase(Locale.getDefault()).contains(s) }
                .take(40)
            for (z in found) {
                list.addView(
                    TextView(ctx).apply {
                        text = z.name.removePrefix("МО: ")
                        textSize = 16f
                        setPadding(dp(4), dp(11), dp(4), dp(11))
                        setOnClickListener {
                            customZone = z.name
                            MyArea.setCustomZone(ctx, z.name)
                            centerMode = 2
                            MyArea.setCenterMode(ctx, 2)
                            rebuildCenterChips()
                            scheduleRender()
                            dialog.dismiss()
                        }
                    }
                )
            }
            if (found.isEmpty()) list.addView(TextView(ctx).apply { text = "Ничего не найдено"; setPadding(dp(4), dp(11), dp(4), dp(11)) })
        }
        input.doAfterTextChanged { fill(it?.toString() ?: "") }
        fill("")
        dialog.show()
    }

    // ----- Отрисовка -----

    private fun scheduleRender() {
        handler.removeCallbacks(renderRunnable)
        handler.postDelayed(renderRunnable, 250L)
    }

    private fun fmtTimer(ms: Long): String {
        val s = (ms / 1000L).coerceAtLeast(0L)
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec)
        else String.format(Locale.US, "%02d:%02d", m, sec)
    }

    private fun tick() {
        val s = MyArea.session(this)
        if (s == null) {
            if (countdown != null) {
                countdown = null
                bar = null
                inAreaText = null
                renderStatus()
                Toast.makeText(this, "Время режима «Мой район» вышло", Toast.LENGTH_LONG).show()
            }
            return
        }
        val total = (s.endAt - s.startAt).coerceAtLeast(1L)
        val left = (s.endAt - System.currentTimeMillis()).coerceAtLeast(0L)
        countdown?.text = fmtTimer(left)
        bar?.progress = (1000L * left / total).toInt()
        updateInArea(s)
    }

    private fun updateInArea(s: MyArea.Session) {
        val me = myLoc
        val t = inAreaText ?: return
        if (me == null) {
            t.text = "Положение не определено"
            t.setTextColor(p.sub)
            return
        }
        val d = MoscowRegionGrid.distanceKm(s.lat, s.lon, me.latitude, me.longitude)
        if (d <= s.radiusKm) {
            t.text = "✔ Вы в районе · до границы ${MyArea.fmtKm(s.radiusKm - d)} км"
            t.setTextColor(0xFF55D68B.toInt())
        } else {
            t.text = "⚠ Вы за границей района на ${MyArea.fmtKm(d - s.radiusKm)} км — вернитесь к центру"
            t.setTextColor(p.warn)
        }
    }

    private fun renderStatus() {
        statusBox.removeAllViews()
        val s = MyArea.session(this)
        val used = (MyArea.usedTodayMs(this) / 60_000L).toInt()
        val limit = MyArea.dailyLimitMin(this)
        val c = card()
        if (s != null) {
            c.background = rounded(withAlpha(0xFF6A3FD0.toInt(), if (p.dark) 0.18f else 0.10f), dp(18).toFloat(), 0xFFB388FF.toInt(), dp(1))
            c.addView(tv("🎯 Режим включён", 15.5f, p.text, true))
            val cd = tv(fmtTimer(MyArea.remainingMs(this)), 34f, 0xFFB388FF.toInt(), true).apply {
                typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            }
            countdown = cd
            c.addView(cd)
            val pb = ProgressBar(ctx, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = 1000
                progressTintList = ColorStateList.valueOf(0xFFB388FF.toInt())
                progressBackgroundTintList = ColorStateList.valueOf(p.stroke)
            }
            bar = pb
            c.addView(pb, LinearLayout.LayoutParams(matchP, dp(6)).apply { topMargin = dp(4) })
            c.addView(
                tv("${s.name} · радиус ${MyArea.fmtKm(s.radiusKm)} км", 13.5f, p.text).apply { setPadding(0, dp(8), 0, 0) }
            )
            val inArea = tv("", 13f, p.sub).apply { setPadding(0, dp(2), 0, 0) }
            inAreaText = inArea
            c.addView(inArea)
            c.addView(
                tv("Сегодня в режиме: $used из $limit мин. Комиссия в оценке заказов: " +
                    "${MyArea.effectiveCommission(this, WidgetSettings.load(this).commissionPct)}%.", 12.5f, p.sub)
                    .apply { setPadding(0, dp(4), 0, 0) }
            )
            tick()
        } else {
            countdown = null
            bar = null
            inAreaText = null
            val left = (MyArea.remainingTodayMs(this) / 60_000L).toInt()
            c.addView(tv("🎯 Режим выключен", 15.5f, p.text, true))
            c.addView(
                tv(
                    if (left > 0) "Сегодня можно ещё $left мин из $limit. Не тратьте лимит впустую — " +
                        "ниже видно, когда и где включать выгоднее."
                    else "Дневной лимит режима исчерпан ($limit мин).",
                    13f, p.sub
                ).apply { setPadding(0, dp(4), 0, 0) }
            )
            c.addView(
                tv("В Яндекс Про: Заказы по пути → Мой район → радиус и время → Поехали.", 12.5f, p.sub)
                    .apply { setPadding(0, dp(4), 0, 0) }
            )
        }
        statusBox.addView(c, LinearLayout.LayoutParams(matchP, wrapP))
        startBtn.text = if (s != null) "■ Завершить режим" else "▶ Начать сессию «Мой район»"
    }

    private fun renderDynamic() {
        dynBox.removeAllViews()
        val center = resolveCenter()
        val (meLat, meLon) = meLatLon(center)
        val a = MyArea.analyze(this, center.lat, center.lon, radiusKm.toDouble(), meLat, meLon)

        centerNote.text = center.note ?: "Центр: ${center.name}"
        centerNote.visibility = View.VISIBLE

        // --- Анализ района ---
        val c1 = card()
        c1.addView(sectionTitle("Анализ района"))
        c1.addView(tv("${center.name} · радиус ${MyArea.fmtKm(radiusKm.toDouble())} км", 12.5f, p.sub))
        c1.addView(pill(a.verdict.title, a.verdict.color, 15f).apply { }, LinearLayout.LayoutParams(wrapP, wrapP).apply { topMargin = dp(10) })
        c1.addView(tv(a.verdictText, 13.5f, p.text).apply { setPadding(0, dp(8), 0, 0) })

        val stats = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        fun stat(label: String, pct: Int, color: Int): LinearLayout =
            LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                background = rounded(p.cardAlt, dp(14).toFloat(), p.stroke, dp(1))
                setPadding(dp(6), dp(8), dp(6), dp(8))
                addView(tv(DemandModel.coefText(pct), 18f, color, true).apply { gravity = Gravity.CENTER })
                addView(tv(label, 11f, p.sub).apply { gravity = Gravity.CENTER })
            }
        stats.addView(stat("в районе", a.avgPct, DemandModel.textColor(a.avgPct)), LinearLayout.LayoutParams(0, wrapP, 1f).apply { rightMargin = dp(6) })
        stats.addView(stat("максимум", a.maxPct, DemandModel.textColor(a.maxPct)), LinearLayout.LayoutParams(0, wrapP, 1f).apply { rightMargin = dp(6) })
        stats.addView(stat("по городу", a.cityPct, p.sub), LinearLayout.LayoutParams(0, wrapP, 1f).apply { rightMargin = dp(6) })
        stats.addView(stat("порог", a.breakEvenPct, p.warn), LinearLayout.LayoutParams(0, wrapP, 1f))
        c1.addView(stats, LinearLayout.LayoutParams(matchP, wrapP).apply { topMargin = dp(10) })
        c1.addView(
            tv("Порог — какой коэффициент нужен, чтобы повышенная комиссия не снизила доход.", 11.5f, p.sub)
                .apply { setPadding(0, dp(6), 0, 0) }
        )

        val top = a.zones.firstOrNull()
        if (top != null && top.pct >= 10) {
            val dir = MyArea.directionText(center.lat, center.lon, top.zone.lat, top.zone.lon)
            val where = if (top.distKm < 0.8) "в центре района" else "${MyArea.fmtKm(top.distKm)} км на $dir от центра"
            c1.addView(
                tv("🔥 Горячее всего: ${top.zone.name.removePrefix("МО: ")} ${DemandModel.coefText(top.pct)} — $where",
                    13.5f, p.accent, true).apply { setPadding(0, dp(10), 0, 0) }
            )
        }
        a.airportWarning?.let {
            c1.addView(tv("✈ $it", 12.5f, p.warn, true).apply { setPadding(0, dp(8), 0, 0) })
        }
        dynBox.addView(c1, cardParams())

        // --- Когда включать ---
        if (a.slots.isNotEmpty()) {
            val c2 = card()
            c2.addView(sectionTitle("Когда включать"))
            val scroll = HorizontalScrollView(ctx).apply { isHorizontalScrollBarEnabled = false }
            val line = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
            val best = a.bestSlot
            for ((i, sl) in a.slots.withIndex()) {
                val color = DemandModel.textColor(sl.pct)
                val isBest = best != null && sl.timeMs == best.timeMs && a.slots.size > 1
                val box = LinearLayout(ctx).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER
                    background = rounded(
                        if (isBest) withAlpha(0xFF6A3FD0.toInt(), 0.22f) else p.cardAlt,
                        dp(14).toFloat(), if (isBest) 0xFFB388FF.toInt() else p.stroke, dp(1)
                    )
                    setPadding(dp(12), dp(8), dp(12), dp(8))
                }
                box.addView(tv(if (i == 0) "сейчас" else DemandModel.mskTime(sl.timeMs), 12f, p.sub).apply { gravity = Gravity.CENTER })
                box.addView(tv(DemandModel.coefText(sl.pct), 16f, color, true).apply { gravity = Gravity.CENTER })
                line.addView(box, LinearLayout.LayoutParams(wrapP, wrapP).apply { rightMargin = dp(6) })
            }
            scroll.addView(line)
            c2.addView(scroll, LinearLayout.LayoutParams(matchP, wrapP).apply { topMargin = dp(8) })
            val now0 = a.slots.first().pct
            val hint = when {
                best != null && best.timeMs != a.slots.first().timeMs && best.pct >= now0 + 8 -> {
                    val mins = ((best.timeMs - System.currentTimeMillis()) / 60_000L).toInt().coerceAtLeast(1)
                    "Через ~$mins мин (в ${DemandModel.mskTime(best.timeMs)}) спрос в районе выше: " +
                        "${DemandModel.coefText(best.pct)} против ${DemandModel.coefText(now0)} сейчас. " +
                        "Лимит режима ограничен — выгоднее включать на пике."
                }
                best != null && best.pct + 8 <= now0 ->
                    "Сейчас — лучшее время в ближайшие 3 часа, дальше спрос в районе падает."
                else -> "В ближайшие 3 часа спрос в районе почти не меняется. Прогноз — по модели приложения."
            }
            c2.addView(tv(hint, 12.5f, p.sub).apply { setPadding(0, dp(8), 0, 0) })
            dynBox.addView(c2, cardParams())
        }

        // --- Что внутри района ---
        val c3 = card()
        c3.addView(sectionTitle("Что внутри района"))
        val zoneList = a.zones.take(4)
        for (zr in zoneList) {
            val row = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(6), 0, dp(2))
            }
            row.addView(tv("📍", 18f, p.text), LinearLayout.LayoutParams(dp(30), wrapP))
            val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
            col.addView(tv(zr.zone.name.removePrefix("МО: "), 14.5f, p.text, true).apply {
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            })
            col.addView(tv("${MyArea.fmtKm(zr.distKm)} км от центра", 11.5f, p.sub))
            row.addView(col, LinearLayout.LayoutParams(0, wrapP, 1f))
            row.addView(pill(DemandModel.coefText(zr.pct), DemandModel.textColor(zr.pct), 14f))
            c3.addView(row)
        }
        for (h in a.spots) {
            val row = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(6), 0, dp(2))
            }
            row.addView(tv(h.poi.kind.emoji, 18f, p.text), LinearLayout.LayoutParams(dp(30), wrapP))
            val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
            col.addView(tv(h.poi.name, 14.5f, p.text, true).apply {
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            })
            col.addView(tv(h.reason, 11.5f, if (h.live) p.accent else p.sub).apply {
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            })
            row.addView(col, LinearLayout.LayoutParams(0, wrapP, 1f))
            row.addView(pill(DemandModel.coefText(h.pct), DemandModel.textColor(h.pct), 14f))
            c3.addView(row)
        }
        if (a.spots.isEmpty()) {
            c3.addView(tv("Вокзалов и больниц в этом радиусе нет.", 12.5f, p.sub).apply { setPadding(0, dp(8), 0, 0) })
        }
        dynBox.addView(c3, cardParams())

        // --- Где лучше включить ---
        if (a.alternatives.isNotEmpty()) {
            val c4 = card()
            c4.addView(sectionTitle("Где выгоднее включить"))
            c4.addView(
                tv("Яндекс строит район вокруг вашего положения — поезжайте в нужное место и включайте режим там.",
                    12f, p.sub).apply { setPadding(0, dp(2), 0, dp(4)) }
            )
            for (alt in a.alternatives) {
                val row = LinearLayout(ctx).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(0, dp(6), 0, dp(2))
                    setOnClickListener {
                        customZone = alt.zone.name
                        MyArea.setCustomZone(ctx, alt.zone.name)
                        centerMode = 2
                        MyArea.setCenterMode(ctx, 2)
                        rebuildCenterChips()
                        scheduleRender()
                    }
                }
                val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
                col.addView(tv(alt.zone.name.removePrefix("МО: "), 14.5f, p.text, true).apply {
                    maxLines = 1
                    ellipsize = TextUtils.TruncateAt.END
                })
                col.addView(tv("${MyArea.fmtKm(alt.distFromMeKm)} км от вас, на ${alt.direction}", 11.5f, p.sub))
                row.addView(col, LinearLayout.LayoutParams(0, wrapP, 1f))
                row.addView(pill("район ${DemandModel.coefText(alt.avgPct)}", DemandModel.textColor(alt.avgPct), 13.5f))
                c4.addView(row)
            }
            dynBox.addView(c4, cardParams())
        }
    }

    // ----- Действия -----

    private fun onStartStop() {
        if (MyArea.isActive(this)) {
            MyArea.stop(this)
            renderStatus()
            Toast.makeText(this, "Сессия «Мой район» завершена. Выключите режим и в Яндекс Про.", Toast.LENGTH_LONG).show()
            return
        }
        val leftMin = (MyArea.remainingTodayMs(this) / 60_000L).toInt()
        if (leftMin <= 0) {
            Toast.makeText(this, "Дневной лимит режима исчерпан. Его можно изменить в параметрах.", Toast.LENGTH_LONG).show()
            return
        }
        val m = minOf(minutes, leftMin)
        val c = resolveCenter()
        MyArea.start(this, c.lat, c.lon, c.name, radiusKm.toDouble(), m)
        renderStatus()
        Toast.makeText(
            this,
            "Сессия запущена на $m мин. Включите «Мой район» в Яндекс Про с радиусом ${MyArea.fmtKm(radiusKm.toDouble())} км.",
            Toast.LENGTH_LONG
        ).show()
    }

    private fun showOnMap() {
        val s = MyArea.session(this)
        if (s == null) {
            val c = resolveCenter()
            MyArea.setPreview(this, c.lat, c.lon, c.name, radiusKm.toDouble())
        }
        startActivity(
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra("AREA_FOCUS", true)
        )
    }

    private fun openYandex() {
        if (YandexLink.isInstalled(this)) YandexLink.openYandexPro(this)
        else Toast.makeText(this, "Яндекс Про не найден на телефоне", Toast.LENGTH_SHORT).show()
    }
}
