package com.surge.radar

import android.content.Context
import android.content.Intent
import android.net.Uri
import java.net.URLEncoder
import java.util.regex.Pattern

/** Extracts only visible order-card text; it does not interact with acceptance buttons. */
data class OrderOffer(val from: String, val to: String, val priceRub: Int?, val raw: String, val capturedAt: Long)

object OrderOfferReader {
    private val money = Pattern.compile("(?<!\\d)(\\d{2,5})\\s*(?:₽|руб(?:\\.|лей|ля)?)(?!\\w)", Pattern.CASE_INSENSITIVE or Pattern.UNICODE_CASE)
    private val addressHint = Regex("(?iu)(?:^|[\\s,(\\-])(?:улиц|ул\\.|просп|пр-?т\\.?|шоссе|переул|пер\\.|бульвар|б-р|набереж|наб\\.|площад|пл\\.|проезд|алле|тупик|микрорайон|мкр\\.?|д\\.\\s*\\d|д\\s+\\d|дом\\s+\\d|корп|стр\\.\\s*\\d|москва|область|вокзал|аэропорт)")
    private val fromWords = listOf("откуда", "подача", "начало", "забрать", "pickup")
    private val toWords = listOf("куда", "адрес назначения", "конец", "доставить", "destination")
    private fun clean(s: String) = s.replace(Regex("\\s+"), " ").trim().trim('·', '•', ':', '-', '—')

    fun parse(context: Context, texts: List<String>): OrderOffer? {
        val lines = texts.map(::clean).filter { it.length > 2 }
        val all = lines.joinToString(" | ")
        val orderLike = all.contains("принять", true) || all.contains("заказ", true) || all.contains("поездка", true) || all.contains("стоимость", true) || all.contains("подача", true)
        if (!orderLike) return null
        var from = ""; var to = ""
        lines.forEachIndexed { index, line ->
            val lower = line.lowercase()
            if (from.isBlank() && fromWords.any(lower::contains)) {
                from = extractAddress(line) ?: lines.getOrNull(index + 1)?.takeIf(::looksAddress).orEmpty()
            }
            if (to.isBlank() && toWords.any(lower::contains)) {
                to = extractAddress(line) ?: lines.getOrNull(index + 1)?.takeIf(::looksAddress).orEmpty()
            }
        }
        val candidates = lines.filter(::looksAddress).distinct()
        if (from.isBlank() && candidates.isNotEmpty()) from = candidates[0]
        if (to.isBlank() && candidates.size > 1) to = candidates[1]
        val matcher = money.matcher(all.replace(',', '.'))
        var price: Int? = null
        while (matcher.find()) { val n = matcher.group(1).toIntOrNull(); if (n != null && n in 50..100_000) { price = n; break } }
        if (from.isBlank() && to.isBlank() && price == null) return null
        val normalized = "$from|$to|$price"
        val prefs = context.getSharedPreferences("last_order_card", Context.MODE_PRIVATE)
        if (prefs.getString("fingerprint", "") == normalized) return null
        val offer = OrderOffer(from, to, price, lines.take(60).joinToString("\n"), System.currentTimeMillis())
        prefs.edit().putString("fingerprint", normalized).putString("from", from).putString("to", to)
            .putInt("price", price ?: -1).putString("raw", offer.raw).putLong("captured", offer.capturedAt).apply()
        ReaderDiag.lastOrderAt = offer.capturedAt
        ReaderDiag.lastOrderSummary = summary(offer)
        return offer
    }
    private fun extractAddress(line: String): String? {
        val split = line.split(":", "—", "–", "->", "→")
        if (split.size < 2) return null
        return split.lastOrNull()?.let(::clean)?.takeIf(::looksAddress)
    }
    private fun looksAddress(s: String): Boolean = s.length >= 8 && addressHint.containsMatchIn(s) && !s.contains("₽") && !s.contains("руб", true)
    fun load(c: Context): OrderOffer? {
        val p = c.getSharedPreferences("last_order_card", Context.MODE_PRIVATE)
        val from = p.getString("from", "") ?: ""; val to = p.getString("to", "") ?: ""; val price = p.getInt("price", -1)
        if (from.isBlank() && to.isBlank() && price < 0) return null
        return OrderOffer(from, to, price.takeIf { it >= 0 }, p.getString("raw", "") ?: "", p.getLong("captured", 0))
    }
    fun summary(o: OrderOffer): String = buildString {
        append("Карточка заказа распознана\n")
        if (o.from.isNotBlank()) append("Откуда: ${o.from}\n")
        if (o.to.isNotBlank()) append("Куда: ${o.to}\n")
        append("Стоимость: ${o.priceRub?.let { "$it ₽" } ?: "не распознана"}\n")
        append("Время: ${java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date(o.capturedAt))}")
    }
    fun openTrafficRoute(context: Context, offer: OrderOffer) {
        if (offer.from.isBlank() || offer.to.isBlank()) return
        val route = URLEncoder.encode(offer.from, "UTF-8") + "~" + URLEncoder.encode(offer.to, "UTF-8")
        val uri = Uri.parse("https://yandex.ru/maps/?rtext=$route&rtt=auto")
        runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }
}
