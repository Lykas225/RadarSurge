package com.surge.radar

import android.content.Context
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout

/** Одно окно, три вида: мини-окошко, компактное окно, вердикт по заказу. Виден всегда только один. */
class WidgetHost(context: Context, cfg: WidgetSettings.Values) : FrameLayout(context) {

    enum class Mode { PILL, CARD, VERDICT }

    val pill = PillView(context, cfg)
    val card = RadarWidgetView(context, cfg)
    val verdict = VerdictView(context, cfg)

    var mode: Mode = Mode.PILL
        private set

    init {
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
        addView(pill, FrameLayout.LayoutParams(wrap, wrap))
        addView(card, FrameLayout.LayoutParams(wrap, wrap))
        addView(verdict, FrameLayout.LayoutParams(wrap, wrap))
        show(Mode.PILL)
    }

    fun show(m: Mode) {
        mode = m
        pill.visibility = if (m == Mode.PILL) View.VISIBLE else View.GONE
        card.visibility = if (m == Mode.CARD) View.VISIBLE else View.GONE
        verdict.visibility = if (m == Mode.VERDICT) View.VISIBLE else View.GONE
    }
}
