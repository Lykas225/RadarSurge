package com.surge.radar

import android.content.Context
import android.content.SharedPreferences

object WidgetSettings {
    const val SIZE_SMALL = 0
    const val SIZE_MEDIUM = 1
    const val SIZE_LARGE = 2

    private const val PREFS = "widget_settings"
    private const val POS = "widget_pos"

    data class Values(
        val size: Int = SIZE_LARGE,
        val bgAlpha: Int = 85,
        val widgetAlpha: Int = 100,
        val scale: Int = 100,
        val showRadar: Boolean = true,
        val showGraph: Boolean = true,
        val showDemand: Boolean = true,
        val showWait: Boolean = true,
        val showDecision: Boolean = true,
        val sound: Boolean = true,
        val dark: Boolean = true,
        val mapAnim: Boolean = true,
        val glow: Int = 70,
        val refreshMin: Int = 5,
        val tariffMask: Int = 7,
        val zone: String? = null,
        val overlayOn: Boolean = false
    ) {
        fun isOn(t: Tariff): Boolean = (tariffMask and t.bit) != 0
        fun enabledTariffs(): List<Tariff> = Tariff.values().filter { isOn(it) }
    }

    fun prefs(c: Context): SharedPreferences =
        c.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun load(c: Context): Values {
        val p = prefs(c)
        val d = Values()
        return Values(
            size = p.getInt("size", d.size).coerceIn(0, 2),
            bgAlpha = p.getInt("bg", d.bgAlpha).coerceIn(10, 100),
            widgetAlpha = p.getInt("alpha", d.widgetAlpha).coerceIn(30, 100),
            scale = p.getInt("scale", d.scale).coerceIn(70, 120),
            showRadar = p.getBoolean("radar", d.showRadar),
            showGraph = p.getBoolean("graph", d.showGraph),
            showDemand = p.getBoolean("demand", d.showDemand),
            showWait = p.getBoolean("wait", d.showWait),
            showDecision = p.getBoolean("decision", d.showDecision),
            sound = p.getBoolean("sound", d.sound),
            dark = p.getBoolean("dark", d.dark),
            mapAnim = p.getBoolean("anim", d.mapAnim),
            glow = p.getInt("glow", d.glow).coerceIn(10, 100),
            refreshMin = p.getInt("refresh", d.refreshMin).coerceIn(1, 60),
            tariffMask = p.getInt("tariffs", d.tariffMask) and 7,
            zone = p.getString("zone", null),
            overlayOn = p.getBoolean("overlayOn", d.overlayOn)
        )
    }

    /** Сохраняет всё, кроме выбранной зоны и состояния оверлея (у них свои setZone/setOverlayOn). */
    fun save(c: Context, v: Values) {
        prefs(c).edit()
            .putInt("size", v.size)
            .putInt("bg", v.bgAlpha)
            .putInt("alpha", v.widgetAlpha)
            .putInt("scale", v.scale)
            .putBoolean("radar", v.showRadar)
            .putBoolean("graph", v.showGraph)
            .putBoolean("demand", v.showDemand)
            .putBoolean("wait", v.showWait)
            .putBoolean("decision", v.showDecision)
            .putBoolean("sound", v.sound)
            .putBoolean("dark", v.dark)
            .putBoolean("anim", v.mapAnim)
            .putInt("glow", v.glow)
            .putInt("refresh", v.refreshMin)
            .putInt("tariffs", v.tariffMask)
            .apply()
    }

    fun setZone(c: Context, name: String) {
        prefs(c).edit().putString("zone", name).apply()
    }

    fun setMask(c: Context, mask: Int) {
        prefs(c).edit().putInt("tariffs", mask and 7).apply()
    }

    fun setOverlayOn(c: Context, on: Boolean) {
        prefs(c).edit().putBoolean("overlayOn", on).apply()
    }

    fun loadPos(c: Context): Pair<Int, Int> {
        val p = c.applicationContext.getSharedPreferences(POS, Context.MODE_PRIVATE)
        return Pair(p.getInt("x", 24), p.getInt("y", 170))
    }

    fun savePos(c: Context, x: Int, y: Int) {
        c.applicationContext.getSharedPreferences(POS, Context.MODE_PRIVATE)
            .edit().putInt("x", x).putInt("y", y).apply()
    }
}
