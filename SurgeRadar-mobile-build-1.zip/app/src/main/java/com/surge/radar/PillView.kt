package com.surge.radar

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.min
import kotlin.math.roundToInt

/** Мини-окошко: точка источника, лучший процент спроса и стрелка тренда. Почти не занимает экран. */
class PillView(context: Context, private val cfg: WidgetSettings.Values) : LinearLayout(context) {

    private val f = cfg.scale / 100f
    private val fk = cfg.fontPct / 100f
    private val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
    private val bgAlpha255 = (cfg.bgAlpha * 255 / 100).coerceIn(0, 255)

    private fun px(v: Float): Int = (v * resources.displayMetrics.density * f).roundToInt()

    private fun tv(t: String, size: Float, color: Int, strong: Boolean): TextView =
        TextView(context).apply {
            text = t
            setTextSize(TypedValue.COMPLEX_UNIT_SP, size * f * fk)
            setTextColor(color)
            typeface = weightTypeface(if (strong) min(900, cfg.fontWeight + 200) else cfg.fontWeight)
            includeFontPadding = false
        }

    private val dot = tv("●", 8f, 0xFF607D8B.toInt(), false)
    private val pctView = tv("—", 13f, Color.WHITE, true)
    private val arrowView = tv("", 12f, 0xFF8FF0E2.toInt(), true)
    private val frame = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(Color.argb(bgAlpha255, 16, 40, 58), Color.argb(bgAlpha255, 6, 13, 22))
    ).apply { cornerRadius = px(13f).toFloat() }

    init {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        background = frame
        setPadding(px(9f), px(4f), px(9f), px(4f))
        alpha = cfg.widgetAlpha / 100f
        addView(dot, LinearLayout.LayoutParams(wrap, wrap))
        addView(pctView, LinearLayout.LayoutParams(wrap, wrap).apply { leftMargin = px(5f) })
        addView(arrowView, LinearLayout.LayoutParams(wrap, wrap).apply { leftMargin = px(4f) })
        setBorder(0xFF40E0D0.toInt())
    }

    private fun setBorder(color: Int) {
        val a = (bgAlpha255 * 0.9f).toInt().coerceIn(0, 255)
        frame.setStroke(px(1.2f).coerceAtLeast(1), Color.argb(a, Color.red(color), Color.green(color), Color.blue(color)))
    }

    fun bind(pct: Int, arrow: String, live: Boolean, hasTariffs: Boolean) {
        dot.setTextColor(if (live) 0xFF69F0AE.toInt() else 0xFF607D8B.toInt())
        if (!hasTariffs) {
            pctView.text = "—"
            pctView.setTextColor(Color.LTGRAY)
            arrowView.text = ""
            setBorder(0xFF40E0D0.toInt())
            return
        }
        pctView.text = DemandModel.coefText(pct)
        pctView.setTextColor(DemandModel.textColor(pct))
        arrowView.text = arrow
        setBorder(if (pct >= 15) DemandModel.heatColor(pct) else 0xFF40E0D0.toInt())
    }
}
