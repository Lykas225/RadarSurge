package com.surge.radar

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.min
import kotlin.math.roundToInt

/** Список горячих мест, который раскрывается из окошка по двойному тапу. Закрывается сам. */
class HotListView(context: Context, private val cfg: WidgetSettings.Values) : LinearLayout(context) {

    private val f = cfg.scale / 100f
    private val fk = cfg.fontPct / 100f
    private val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

    private fun px(v: Float): Int = (v * resources.displayMetrics.density * f).roundToInt()

    private fun tv(t: String, size: Float, color: Int, strong: Boolean = false): TextView =
        TextView(context).apply {
            text = t
            setTextSize(TypedValue.COMPLEX_UNIT_SP, size * f * fk)
            setTextColor(color)
            typeface = weightTypeface(if (strong) min(900, cfg.fontWeight + 200) else cfg.fontWeight)
            includeFontPadding = false
        }

    private val box = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }

    init {
        orientation = LinearLayout.VERTICAL
        val a = (cfg.bgAlpha * 255 / 100).coerceIn(160, 255)
        background = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.argb(a, 16, 40, 58), Color.argb(a, 6, 13, 22))
        ).apply {
            cornerRadius = px(16f).toFloat()
            setStroke(px(1.2f).coerceAtLeast(1), Color.argb(a, 255, 138, 61))
        }
        setPadding(px(10f), px(8f), px(10f), px(8f))
        minimumWidth = px(176f)
        addView(tv("🔥 Горячие места", 12f, Color.WHITE, true))
        addView(box, LinearLayout.LayoutParams(wrap, wrap).apply { topMargin = px(4f) })
    }

    fun bind(list: List<HotSpot>, minPct: Int) {
        box.removeAllViews()
        if (list.isEmpty()) {
            box.addView(tv("Нет мест от ${DemandModel.coefText(minPct)}", 11f, Color.LTGRAY))
            return
        }
        for (h in list) {
            val color = DemandModel.textColor(h.pct)
            val row = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, px(3f), 0, px(3f))
            }
            val col = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
            col.addView(tv("${h.poi.kind.emoji} ${h.poi.name}", 11.5f, Color.WHITE, true).apply {
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                maxWidth = px(118f)
            })
            col.addView(tv(h.reason, 9.5f, if (h.live) 0xFF8FF0E2.toInt() else 0xFF9FB4C0.toInt()).apply {
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
                maxWidth = px(118f)
            })
            row.addView(col, LinearLayout.LayoutParams(0, wrap, 1f))
            val pill = tv(DemandModel.coefText(h.pct), 12f, color, true).apply {
                gravity = Gravity.CENTER
                minWidth = px(38f)
                setPadding(px(5f), px(1f), px(5f), px(1f))
                background = rounded(withAlpha(color, 0.16f), px(8f).toFloat(), withAlpha(color, 0.6f), px(1f).coerceAtLeast(1))
            }
            row.addView(pill, LinearLayout.LayoutParams(wrap, wrap).apply { leftMargin = px(6f) })
            box.addView(row)
        }
    }
}
