package com.surge.radar

enum class PoiKind(val emoji: String, val title: String, val bit: Int) {
    AIRPORT("✈", "Аэропорты", 1),
    STATION("🚆", "Вокзалы", 2),
    EVENT("🎤", "Концерты и события", 4),
    HOSPITAL("🏥", "Больницы", 8)
}

/** Место притяжения пассажиров. capacity: вместимость площадки; match: часть названия станции в расписании. */
class Poi(
    val name: String,
    val kind: PoiKind,
    val lat: Double,
    val lon: Double,
    val capacity: Int = 0,
    val match: String = ""
)

object PoiCatalog {
    val fixed: List<Poi> = listOf(
        Poi("Шереметьево", PoiKind.AIRPORT, 55.9726, 37.4146, 0, "Шереметьево"),
        Poi("Домодедово", PoiKind.AIRPORT, 55.4086, 37.9063, 0, "Домодедово"),
        Poi("Внуково", PoiKind.AIRPORT, 55.5915, 37.2615, 0, "Внуково"),
        Poi("Жуковский", PoiKind.AIRPORT, 55.5533, 38.1500, 0, "Жуковск"),

        Poi("Ярославский вокзал", PoiKind.STATION, 55.7777, 37.6575, 0, "Ярославск"),
        Poi("Казанский вокзал", PoiKind.STATION, 55.7731, 37.6559, 0, "Казанск"),
        Poi("Ленинградский вокзал", PoiKind.STATION, 55.7765, 37.6554, 0, "Ленинградск"),
        Poi("Белорусский вокзал", PoiKind.STATION, 55.7777, 37.5820, 0, "Белорусск"),
        Poi("Киевский вокзал", PoiKind.STATION, 55.7440, 37.5656, 0, "Киевск"),
        Poi("Курский вокзал", PoiKind.STATION, 55.7570, 37.6600, 0, "Курск"),
        Poi("Павелецкий вокзал", PoiKind.STATION, 55.7297, 37.6393, 0, "Павелецк"),
        Poi("Савёловский вокзал", PoiKind.STATION, 55.7940, 37.5870, 0, "Савеловск"),
        Poi("Рижский вокзал", PoiKind.STATION, 55.7936, 37.6360, 0, "Рижск"),

        Poi("Лужники", PoiKind.EVENT, 55.7158, 37.5539, 80000),
        Poi("Открытие Банк Арена", PoiKind.EVENT, 55.8180, 37.4400, 45000),
        Poi("Олимпийский", PoiKind.EVENT, 55.7819, 37.6269, 35000),
        Poi("ВТБ Арена", PoiKind.EVENT, 55.7919, 37.5598, 20000),
        Poi("ЦСКА Арена", PoiKind.EVENT, 55.7907, 37.5353, 12000),
        Poi("Крокус Сити Холл", PoiKind.EVENT, 55.8260, 37.3880, 6200),
        Poi("Кремлёвский дворец", PoiKind.EVENT, 55.7517, 37.6144, 6000),
        Poi("Известия Холл", PoiKind.EVENT, 55.7658, 37.6070, 2000),
        Poi("Зарядье", PoiKind.EVENT, 55.7508, 37.6288, 1500),

        Poi("Больница им. Пирогова", PoiKind.HOSPITAL, 55.7076, 37.5868),
        Poi("Боткинская больница", PoiKind.HOSPITAL, 55.7792, 37.5608),
        Poi("НИИ Склифосовского", PoiKind.HOSPITAL, 55.7728, 37.6340),
        Poi("Госпиталь Бурденко", PoiKind.HOSPITAL, 55.7662, 37.7060),
        Poi("Сеченовский университет", PoiKind.HOSPITAL, 55.7292, 37.5705)
    )

    fun byKinds(mask: Int): List<Poi> = fixed.filter { (it.kind.bit and mask) != 0 }
}
