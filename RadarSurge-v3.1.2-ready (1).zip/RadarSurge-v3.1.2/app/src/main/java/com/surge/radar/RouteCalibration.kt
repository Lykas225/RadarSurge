package com.surge.radar

import android.content.Context
import kotlin.math.max
import kotlin.math.min

/**
 * Самообучение расчёта маршрута по настоящим цифрам Яндекс Про.
 *
 * Когда на карточке заказа Яндекс Про сам показал время и расстояние поездки, мы сравниваем их
 * с «сырым» расчётом OSRM (без пробок) и запоминаем отношение отдельно для каждого времени суток
 * (будни/выходные × 5 периодов). Дальше, когда Яндекс Про цифры скрыл, время считается
 * по выученному коэффициенту, а не по фиксированной таблице пробок.
 */
object RouteCalibration {
    private const val PREFS = "route_calib"
    @Volatile private var app: Context? = null

    fun attach(c: Context) {
        if (app == null) app = c.applicationContext
    }

    private fun prefs() = app?.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** 0..9: будни/выходные × (ночь, утро, день, вечер, поздний вечер). */
    fun bucket(nowMs: Long = System.currentTimeMillis()): Int {
        val hour = DemandModel.mskMinutes(nowMs) / 60.0
        val day = Math.floorDiv(nowMs + 3 * 3_600_000L, 86_400_000L)
        val dow = Math.floorMod(day + 3L, 7L).toInt()
        val weekend = if (dow >= 5) 1 else 0
        val period = when {
            hour < 6.5 -> 0
            hour < 10.0 -> 1
            hour < 16.5 -> 2
            hour < 20.5 -> 3
            else -> 4
        }
        return weekend * 5 + period
    }

    @Synchronized
    fun record(rawKm: Double, rawMin: Double, cardKm: Double, cardMin: Double, nowMs: Long = System.currentTimeMillis()) {
        val p = prefs() ?: return
        if (rawKm < 1.0 || rawMin < 2.0 || cardKm <= 0.0 || cardMin <= 0.0) return
        val kr = cardKm / rawKm
        val tr = cardMin / rawMin
        // отсекаем явные ошибки геокодирования
        if (kr !in 0.6..1.6 || tr !in 0.5..4.0) return

        val b = bucket(nowMs)
        val nT = p.getInt("tn$b", 0)
        val fT = p.getFloat("tf$b", 0f).toDouble()
        val nK = p.getInt("kn", 0)
        val fK = p.getFloat("kf", 0f).toDouble()
        val aT = max(1.0 / (nT + 1), 0.15)
        val aK = max(1.0 / (nK + 1), 0.10)
        val newT = if (nT == 0) tr else fT + aT * (tr - fT)
        val newK = if (nK == 0) kr else fK + aK * (kr - fK)
        p.edit()
            .putInt("tn$b", nT + 1).putFloat("tf$b", newT.toFloat())
            .putInt("kn", nK + 1).putFloat("kf", newK.toFloat())
            .apply()
    }

    /** Коэффициент времени к OSRM без пробок; defaultFactor — таблица пробок, пока данных мало. */
    fun timeFactor(defaultFactor: Double): Double {
        val p = prefs() ?: return defaultFactor
        val b = bucket()
        val n = p.getInt("tn$b", 0)
        if (n == 0) return defaultFactor
        val learned = p.getFloat("tf$b", defaultFactor.toFloat()).toDouble()
        val w = min(1.0, n / 6.0)
        return (w * learned + (1.0 - w) * defaultFactor).coerceIn(0.6, 3.0)
    }

    /** Поправка длины маршрута: OSRM может выбирать путь чуть иначе, чем Яндекс. */
    fun kmFactor(): Double {
        val p = prefs() ?: return 1.0
        val n = p.getInt("kn", 0)
        if (n < 3) return 1.0
        val learned = p.getFloat("kf", 1f).toDouble()
        val w = min(1.0, n / 10.0)
        return (1.0 + w * (learned - 1.0)).coerceIn(0.85, 1.25)
    }

    fun sampleCount(): Int {
        val p = prefs() ?: return 0
        return p.getInt("tn${bucket()}", 0)
    }

    fun sourceTag(): String {
        val n = sampleCount()
        return if (n > 0) "обучено по $n карточкам" else "типовые пробки"
    }

    fun status(): String {
        val p = prefs() ?: return ""
        val b = bucket()
        val n = p.getInt("tn$b", 0)
        val total = (0..9).sumOf { p.getInt("tn$it", 0) }
        return if (n > 0) {
            String.format(java.util.Locale.US, "время ×%.2f (по %d карточкам этого времени суток, всего %d)",
                p.getFloat("tf$b", 1f), n, total)
        } else {
            "ещё не обучено для этого времени суток (всего карточек: $total) — учусь на карточках с точным временем"
        }
    }
}
