package com.surge.radar

import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference
import kotlin.math.max
import kotlin.math.roundToInt

data class RouteEstimate(
    val distanceKm: Double,
    val durationMin: Int,
    val fromLat: Double,
    val fromLon: Double,
    val toLat: Double,
    val toLon: Double,
    val source: String
)

/**
 * Быстрый расчёт расстояния и времени в пути по адресам А → Б без ключей:
 * параллельное геокодирование А и Б (Photon + Nominatim с очисткой названий заведений и корпусов)
 * + автомобильный маршрут OSRM + поправка на пробки Москвы по времени суток.
 */
object RouteEstimator {
    private const val MSK_LAT = 55.7558
    private const val MSK_LON = 37.6173
    private const val MAX_REGION_KM = 120.0

    private val mainHandler = Handler(Looper.getMainLooper())
    private val geoCache = object : LinkedHashMap<String, Pair<Double, Double>>(160, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Pair<Double, Double>>?): Boolean =
            size > 150
    }
    private val streetKw = Regex(
        "(?iu)(?:улиц\\w*|ул\\.|просп\\w*|пр-?т\\.?|шоссе|ш\\.|переул\\w*|пер\\.|бульвар\\w*|б-р|набереж\\w*|наб\\.|площад\\w*|пл\\.|проезд\\w*|алле\\w*|тупик\\w*)"
    )

    /** Коэффициент дорожных пробок Москвы по времени суток (МСК). */
    fun moscowTrafficFactor(nowMs: Long = System.currentTimeMillis()): Double {
        val mins = DemandModel.mskMinutes(nowMs)
        val hour = mins / 60.0
        val day = Math.floorDiv(nowMs + 3 * 3_600_000L, 86_400_000L)
        val dow = Math.floorMod(day + 3L, 7L).toInt() // 0=Пн .. 6=Вс
        val weekend = dow >= 5
        return if (weekend) {
            when {
                hour < 8.0 -> 1.06
                hour < 12.0 -> 1.20
                hour < 19.0 -> 1.35
                hour < 22.0 -> 1.22
                else -> 1.08
            }
        } else {
            when {
                hour < 6.5 -> 1.06
                hour < 10.0 -> 1.62
                hour < 16.5 -> 1.35
                hour < 20.5 -> 1.72
                hour < 22.5 -> 1.25
                else -> 1.08
            }
        }
    }

    /** Средняя скорость по Москве (км/ч). */
    fun avgCitySpeedKmh(nowMs: Long = System.currentTimeMillis()): Double =
        (42.0 / moscowTrafficFactor(nowMs)).coerceIn(18.0, 48.0)

    fun estimateAsync(
        fromAddress: String,
        toAddress: String,
        onResult: (RouteEstimate?) -> Unit
    ) {
        if (fromAddress.isBlank() || toAddress.isBlank()) {
            mainHandler.post { onResult(null) }
            return
        }
        Thread {
            val res = runCatching { computeSync(fromAddress, toAddress) }.getOrNull()
            mainHandler.post { onResult(res) }
        }.start()
    }

    private fun computeSync(fromAddress: String, toAddress: String): RouteEstimate? {
        val fromRef = AtomicReference<Pair<Double, Double>?>(null)
        val toRef = AtomicReference<Pair<Double, Double>?>(null)
        val latch = CountDownLatch(2)

        Thread {
            try {
                fromRef.set(geocodeSmart(fromAddress))
            } finally {
                latch.countDown()
            }
        }.start()

        Thread {
            try {
                toRef.set(geocodeSmart(toAddress))
            } finally {
                latch.countDown()
            }
        }.start()

        latch.await(6, TimeUnit.SECONDS)
        val fromPt = fromRef.get() ?: return null
        val toPt = toRef.get() ?: return null

        val osrm = runCatching { fetchOsrm(fromPt.first, fromPt.second, toPt.first, toPt.second) }.getOrNull()
        val factor = moscowTrafficFactor()
        if (osrm != null) {
            val km = max(0.5, osrm.first)
            val min = max(3, (osrm.second * factor).roundToInt())
            return RouteEstimate(km, min, fromPt.first, fromPt.second, toPt.first, toPt.second, "маршрут OSRM")
        }

        val airKm = MoscowRegionGrid.distanceKm(fromPt.first, fromPt.second, toPt.first, toPt.second)
        val roadKm = max(0.8, airKm * 1.32)
        val min = max(3, (roadKm / avgCitySpeedKmh() * 60.0).roundToInt())
        return RouteEstimate(roadKm, min, fromPt.first, fromPt.second, toPt.first, toPt.second, "оценка по карте")
    }

    private fun geocodeSmart(rawAddress: String): Pair<Double, Double>? {
        val cacheKey = rawAddress.trim().lowercase()
        synchronized(geoCache) {
            geoCache[cacheKey]?.let { return it }
        }
        val variants = buildGeocodeVariants(rawAddress)
        for (query in variants) {
            val pt = runCatching { geocodePhoton(query) }.getOrNull()
                ?: runCatching { geocodeNominatim(query) }.getOrNull()
            if (pt != null && isInsideMoscowRegion(pt.first, pt.second)) {
                synchronized(geoCache) { geoCache[cacheKey] = pt }
                return pt
            }
        }
        return null
    }

    private fun isInsideMoscowRegion(lat: Double, lon: Double): Boolean =
        MoscowRegionGrid.distanceKm(MSK_LAT, MSK_LON, lat, lon) <= MAX_REGION_KM

    private fun buildGeocodeVariants(rawAddress: String): List<String> {
        val base = rawAddress
            .replace(Regex("^(?:[АAБB]|точка\\s+[АAБB])[\\s.:)\\-—]+", RegexOption.IGNORE_CASE), "")
            .replace(Regex("\\s+"), " ")
            .trim()
            .trim(',')
        if (base.isBlank()) return emptyList()

        val out = ArrayList<String>(4)
        fun add(q: String) {
            val c = q.replace(Regex("\\s+"), " ").trim().trim(',')
            if (c.isNotBlank() && c !in out) out.add(c)
        }
        fun ensureMoscow(s: String): String =
            if (s.contains("москва", true) || s.contains("область", true)) s else "Москва, $s"

        // Если перед улицей указано название заведения («Pana Москва, Переведеновский пер., 2А»), отсекаем префикс
        val parts = base.split(',').map { it.trim() }.filter { it.isNotEmpty() }
        val streetIdx = parts.indexOfFirst { streetKw.containsMatchIn(it) }
        val core = if (streetIdx > 0) parts.subList(streetIdx, parts.size).joinToString(", ") else base

        val expanded = expandAbbreviations(core)
        add(ensureMoscow(expanded))

        // Упрощаем сложный номер дома: 38/19с1 -> 38/19 -> 38
        val noBuildSuffix = expanded.replace(
            Regex("(?iu)(\\d+[а-яa-z]?)(?:/\\d+)?(?:с|стр\\.?|к|корп\\.?)\\s*\\d+[а-яa-z]?"),
            "$1"
        )
        add(ensureMoscow(noBuildSuffix))

        val baseNumOnly = noBuildSuffix.replace(Regex("(?iu)(\\d+)/\\d+[а-яa-z]?"), "$1")
        add(ensureMoscow(baseNumOnly))

        add(ensureMoscow(base))
        return out
    }

    private fun expandAbbreviations(s: String): String =
        s.replace(Regex("(?iu)(^|[\\s,])пер\\."), "$1переулок")
            .replace(Regex("(?iu)(^|[\\s,])ул\\."), "$1улица")
            .replace(Regex("(?iu)(^|[\\s,])пр-?т\\.?"), "$1проспект")
            .replace(Regex("(?iu)(^|[\\s,])наб\\."), "$1набережная")
            .replace(Regex("(?iu)(^|[\\s,])б-р\\b"), "$1бульвар")
            .replace(Regex("(?iu)(^|[\\s,])пл\\."), "$1площадь")
            .replace(Regex("(?iu)(^|[\\s,])ш\\."), "$1шоссе")

    private fun geocodePhoton(query: String): Pair<Double, Double>? {
        val encoded = URLEncoder.encode(query, "UTF-8")
        val url = "https://photon.komoot.io/api/?q=$encoded&lat=$MSK_LAT&lon=$MSK_LON&limit=4"
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 2800
            readTimeout = 3000
            setRequestProperty("User-Agent", "SurgeRadar/3.0 (Android)")
            setRequestProperty("Accept", "application/json")
        }
        return try {
            if (conn.responseCode !in 200..299) return null
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            val features = JSONObject(body).optJSONArray("features") ?: return null
            for (i in 0 until features.length()) {
                val f = features.optJSONObject(i) ?: continue
                val coords = f.optJSONObject("geometry")?.optJSONArray("coordinates") ?: continue
                if (coords.length() < 2) continue
                val lon = coords.optDouble(0, Double.NaN)
                val lat = coords.optDouble(1, Double.NaN)
                if (!lat.isNaN() && !lon.isNaN() && isInsideMoscowRegion(lat, lon)) {
                    return lat to lon
                }
            }
            null
        } finally {
            conn.disconnect()
        }
    }

    private fun geocodeNominatim(query: String): Pair<Double, Double>? {
        val encoded = URLEncoder.encode(query, "UTF-8")
        val url = "https://nominatim.openstreetmap.org/search?format=json&limit=3&countrycodes=ru" +
            "&viewbox=36.5,56.3,38.8,55.1&bounded=1&q=$encoded"
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 3000
            readTimeout = 3200
            setRequestProperty("User-Agent", "SurgeRadar/3.0 (Android)")
            setRequestProperty("Accept-Language", "ru")
        }
        return try {
            if (conn.responseCode !in 200..299) return null
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            val arr = JSONArray(body)
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val lat = obj.optString("lat").toDoubleOrNull() ?: continue
                val lon = obj.optString("lon").toDoubleOrNull() ?: continue
                if (isInsideMoscowRegion(lat, lon)) return lat to lon
            }
            null
        } finally {
            conn.disconnect()
        }
    }

    private fun fetchOsrm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Pair<Double, Double>? {
        val url = String.format(
            Locale.US,
            "https://router.project-osrm.org/route/v1/driving/%.5f,%.5f;%.5f,%.5f?overview=false",
            lon1, lat1, lon2, lat2
        )
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 3200
            readTimeout = 3500
            setRequestProperty("User-Agent", "SurgeRadar/3.0 (Android)")
        }
        return try {
            if (conn.responseCode !in 200..299) return null
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            val routes = JSONObject(body).optJSONArray("routes") ?: return null
            if (routes.length() == 0) return null
            val r = routes.getJSONObject(0)
            val km = r.optDouble("distance", 0.0) / 1000.0
            val min = r.optDouble("duration", 0.0) / 60.0
            if (km <= 0.0 || min <= 0.0) null else (km to min)
        } finally {
            conn.disconnect()
        }
    }
}
