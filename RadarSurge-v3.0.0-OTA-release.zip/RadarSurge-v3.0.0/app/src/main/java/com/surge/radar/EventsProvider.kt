package com.surge.radar

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.concurrent.atomic.AtomicBoolean

data class LiveEvent(
    val id: String,
    val title: String,
    val venue: String,
    val address: String,
    val startMs: Long,
    val dateIso: String,
    val timeLabel: String,
    val hasExactTime: Boolean,
    val catKey: String,
    val catIcon: String,
    val accentColor: Int,
    val siteUrl: String
)

/**
 * Живые мероприятия Москвы (концерты, спорт, театр, стендап, фестивали, шоу) из открытого API KudaGo.
 * Ключ не требуется, данные кэшируются на 30 минут, выдуманных событий нет.
 */
object EventsProvider {
    private const val PREFS = "events_cache"
    private const val CACHE_TTL_MS = 30 * 60_000L
    private val MSK = ZoneId.of("Europe/Moscow")
    private val mainHandler = Handler(Looper.getMainLooper())
    private val loading = AtomicBoolean(false)

    val categories: List<Pair<String, String>> = listOf(
        "all" to "Все",
        "concert" to "🎵 Концерты",
        "sport" to "⚽ Спорт",
        "theater" to "🎭 Театр",
        "stand-up" to "🎤 Стендап",
        "festival" to "🎪 Фестивали",
        "show" to "✨ Шоу",
        "exhibition" to "🖼 Выставки"
    )

    private fun prefs(c: Context) = c.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun cached(c: Context): List<LiveEvent> {
        val raw = prefs(c).getString("json", null) ?: return emptyList()
        return runCatching { parseKudaGo(raw) }.getOrDefault(emptyList())
    }

    fun statusLine(c: Context): String {
        val at = prefs(c).getLong("at", 0L)
        val err = prefs(c).getString("err", "") ?: ""
        if (at <= 0L) return if (err.isBlank()) "Загрузка афиши Москвы…" else err
        val time = DemandModel.mskTime(at)
        val count = cached(c).size
        return if (count > 0) "Афиша Москвы · обновлено в $time ($count)" else "Обновлено в $time"
    }

    fun refreshAsync(
        c: Context,
        force: Boolean = false,
        onDone: (List<LiveEvent>, String?) -> Unit
    ) {
        val app = c.applicationContext
        val p = prefs(app)
        val cachedList = cached(app)
        val age = System.currentTimeMillis() - p.getLong("at", 0L)
        if (!force && cachedList.isNotEmpty() && age < CACHE_TTL_MS) {
            mainHandler.post { onDone(cachedList, null) }
            return
        }
        if (!loading.compareAndSet(false, true)) return

        Thread {
            try {
                val nowSec = System.currentTimeMillis() / 1000L
                val startOfToday = LocalDate.now(MSK).atStartOfDay(MSK).toEpochSecond()
                val endWindow = LocalDate.now(MSK).plusDays(7).atStartOfDay(MSK).toEpochSecond()
                val since = maxOf(startOfToday, nowSec - 3 * 3600L)
                val urlStr = "https://kudago.com/public-api/v1.4/events/" +
                    "?location=msk&actual_since=$since&actual_until=$endWindow" +
                    "&expand=place,dates&fields=id,title,dates,place,categories,site_url" +
                    "&page_size=100&order_by=dates"

                val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 9000
                    readTimeout = 10_000
                    setRequestProperty("User-Agent", "SurgeRadar/3.0 (Android)")
                    setRequestProperty("Accept", "application/json")
                }
                val code = conn.responseCode
                val body = (if (code in 200..299) conn.inputStream else conn.errorStream)
                    ?.bufferedReader()?.use { it.readText() }.orEmpty()
                conn.disconnect()

                if (code !in 200..299) {
                    throw IllegalStateException("Сервер афиши вернул HTTP $code")
                }
                val list = parseKudaGo(body)
                p.edit()
                    .putString("json", body)
                    .putLong("at", System.currentTimeMillis())
                    .putString("err", "")
                    .apply()
                mainHandler.post { onDone(list, null) }
            } catch (e: Exception) {
                val msg = e.message ?: "Не удалось загрузить афишу"
                p.edit().putString("err", msg).apply()
                val fallback = cached(app)
                mainHandler.post { onDone(fallback, msg) }
            } finally {
                loading.set(false)
            }
        }.start()
    }

    private fun parseKudaGo(rawJson: String): List<LiveEvent> {
        val root = JSONObject(rawJson)
        val results = root.optJSONArray("results") ?: return emptyList()
        val today = LocalDate.now(MSK)
        val todayStartSec = today.atStartOfDay(MSK).toEpochSecond()
        val maxEndSec = today.plusDays(7).atStartOfDay(MSK).toEpochSecond()
        val nowMs = System.currentTimeMillis()
        val out = ArrayList<LiveEvent>(results.length())
        val seenKeys = HashSet<String>()

        for (i in 0 until results.length()) {
            val item = results.optJSONObject(i) ?: continue
            val id = item.optInt("id", i).toString()
            val rawTitle = item.optString("title", "").trim()
            if (rawTitle.isBlank()) continue
            val title = rawTitle.replaceFirstChar { it.uppercase() }
            val siteUrl = item.optString("site_url", "")

            val place = item.optJSONObject("place")
            val venue = place?.optString("title", "")?.trim().orEmpty()
                .replaceFirstChar { if (it.isLowerCase()) it.uppercase() else it.toString() }
            val rawAddr = place?.optString("address", "")?.trim().orEmpty()
            val address = formatMoscowAddress(rawAddr, venue)
            if (venue.isBlank() && address.isBlank()) continue

            val catsArr = item.optJSONArray("categories")
            val (catKey, catIcon, accentColor) = resolveCategory(catsArr)

            val datesArr = item.optJSONArray("dates") ?: continue
            val slot = pickUpcomingSlot(datesArr, todayStartSec, maxEndSec, nowMs / 1000L) ?: continue
            val startSec = slot.first
            val exact = slot.second

            val zdt = ZonedDateTime.ofInstant(Instant.ofEpochSecond(startSec), MSK)
            val dateIso = zdt.toLocalDate().toString()
            val timeLabel = if (exact) {
                String.format(java.util.Locale.US, "%02d:%02d", zdt.hour, zdt.minute)
            } else {
                "уточн."
            }

            val dedupKey = "$dateIso|$timeLabel|${title.lowercase()}"
            if (!seenKeys.add(dedupKey)) continue

            out.add(
                LiveEvent(
                    id = id,
                    title = title,
                    venue = venue.ifBlank { "Площадка в Москве" },
                    address = address,
                    startMs = startSec * 1000L,
                    dateIso = dateIso,
                    timeLabel = timeLabel,
                    hasExactTime = exact,
                    catKey = catKey,
                    catIcon = catIcon,
                    accentColor = accentColor,
                    siteUrl = siteUrl
                )
            )
        }

        return out.sortedWith(
            compareBy<LiveEvent> { it.dateIso }
                .thenBy { if (it.hasExactTime) 0 else 1 }
                .thenBy { it.startMs }
                .thenBy { categoryPriority(it.catKey) }
        )
    }

    private fun pickUpcomingSlot(
        dates: JSONArray,
        todayStartSec: Long,
        maxEndSec: Long,
        nowSec: Long
    ): Pair<Long, Boolean>? {
        var bestExact: Long? = null
        var ongoingToday = false

        for (i in 0 until dates.length()) {
            val d = dates.optJSONObject(i) ?: continue
            val start = d.optLong("start", -1L)
            val end = d.optLong("end", -1L)
            if (start in todayStartSec until maxEndSec) {
                // Игнорируем уже давно завершившиеся сегодня события
                if (end in 1 until (nowSec - 3600L)) continue
                val z = ZonedDateTime.ofInstant(Instant.ofEpochSecond(start), MSK)
                val isMidnight = (z.hour == 0 && z.minute == 0)
                if (!isMidnight) {
                    if (bestExact == null || start < bestExact) bestExact = start
                } else if (bestExact == null) {
                    return start to false
                }
            } else if (start in 1 until todayStartSec && (end >= nowSec || end <= 0L)) {
                ongoingToday = true
            }
        }
        if (bestExact != null) return bestExact to true
        if (ongoingToday) return todayStartSec to false
        return null
    }

    private fun formatMoscowAddress(rawAddr: String, venue: String): String {
        val cleaned = rawAddr.trim().trim(',')
        if (cleaned.isBlank()) return if (venue.isBlank()) "" else "Москва, $venue"
        return if (cleaned.contains("москва", true) || cleaned.contains("область", true)) {
            cleaned
        } else {
            "Москва, $cleaned"
        }
    }

    private fun resolveCategory(arr: JSONArray?): Triple<String, String, Int> {
        val set = HashSet<String>()
        if (arr != null) {
            for (i in 0 until arr.length()) set.add(arr.optString(i, "").lowercase())
        }
        return when {
            "sport" in set -> Triple("sport", "⚽", 0xFF5C9CE6.toInt())
            "concert" in set -> Triple("concert", "🎵", 0xFF9B8AFB.toInt())
            "stand-up" in set || "comedy" in set -> Triple("stand-up", "🎤", 0xFF4DB6AC.toInt())
            "festival" in set || "holiday" in set -> Triple("festival", "🎪", 0xFFEB986C.toInt())
            "theater" in set -> Triple("theater", "🎭", 0xFFE5A95C.toInt())
            "show" in set || "circus" in set || "party" in set -> Triple("show", "✨", 0xFF4DB6AC.toInt())
            "exhibition" in set -> Triple("exhibition", "🖼", 0xFF78909C.toInt())
            else -> Triple("show", "⚡", 0xFF4DB6AC.toInt())
        }
    }

    private fun categoryPriority(catKey: String): Int = when (catKey) {
        "sport" -> 0
        "concert" -> 1
        "festival" -> 2
        "stand-up" -> 3
        "show" -> 4
        "theater" -> 5
        else -> 6
    }
}
