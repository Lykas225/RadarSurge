package com.surge.radar

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build

class Palette(val dark: Boolean) {
    val bg = if (dark) 0xFF0B1620.toInt() else 0xFFF1F4F7.toInt()
    val card = if (dark) 0xFF0F2230.toInt() else 0xFFFFFFFF.toInt()
    val text = if (dark) Color.WHITE else 0xFF14212B.toInt()
    val sub = if (dark) 0xFF8FA3B0.toInt() else 0xFF5F7280.toInt()
    val accent = 0xFF1FD1C0.toInt()
    val blue = 0xFF1E6BFF.toInt()
    val stroke = if (dark) 0xFF21404F.toInt() else 0xFFDCE3E8.toInt()
}

fun Context.dpi(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

fun withAlpha(color: Int, a: Float): Int =
    Color.argb((255f * a).toInt().coerceIn(0, 255), Color.red(color), Color.green(color), Color.blue(color))

fun rounded(color: Int, radiusPx: Float, strokeColor: Int = 0, strokePx: Int = 0): GradientDrawable =
    GradientDrawable().apply {
        setColor(color)
        cornerRadius = radiusPx
        if (strokePx > 0) setStroke(strokePx, strokeColor)
    }

/** Шрифт нужной жирности (100–900). До Android 9 доступны только обычный и жирный. */
fun weightTypeface(weight: Int): Typeface =
    if (Build.VERSION.SDK_INT >= 28) {
        Typeface.create(Typeface.DEFAULT, weight.coerceIn(100, 900), false)
    } else {
        Typeface.create(Typeface.DEFAULT, if (weight >= 600) Typeface.BOLD else Typeface.NORMAL)
    }
