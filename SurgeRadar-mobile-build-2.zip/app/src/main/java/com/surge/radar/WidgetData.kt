package com.surge.radar

import android.graphics.Color
import kotlin.math.PI
import kotlin.math.sin
import kotlin.random.Random

data class Blip(val angle: Double, val dist: Float, val color: Int)

data class TariffRow(val name: String, val pct: Int, val waitMin: Int)

data class WidgetData(
    val zoneName: String,
    val rows: List<TariffRow>,
    val label: String,
    val history: List<Double>,
    val blips: List<Blip>,
    val orderLine: String,
    val destLine: String,
    val decision: String,
    val decisionColor: Int
) {
    companion object {
        fun empty() = WidgetData(
            "", emptyList(), "Загрузка…", emptyList(), emptyList(), "", "", "", Color.LTGRAY
        )

        fun sample(tariffs: List<Tariff>): WidgetData {
            val rnd = Random(7)
            val pcts = intArrayOf(45, 38, 30)
            val waits = intArrayOf(4, 5, 6)
            val colors = listOf(0xFFFF5252.toInt(), 0xFFFFA726.toInt(), 0xFF4CAF50.toInt())
            return WidgetData(
                zoneName = "Центр / Кремль",
                rows = tariffs.map { TariffRow(it.title, pcts[it.ordinal], waits[it.ordinal]) },
                label = "Пиковая активность ↗",
                history = List(13) { 1.3 + 0.3 * sin(it / 2.0) },
                blips = List(12) {
                    Blip(rnd.nextDouble() * 2 * PI, 0.2f + rnd.nextFloat() * 0.75f, colors.random(rnd))
                },
                orderLine = "Цена: 450 ₽ • Время: 12 мин",
                destLine = "Финиш: Жулебино • там +60%",
                decision = "МОЖНО БРАТЬ • 62/100",
                decisionColor = 0xFFFFD740.toInt()
            )
        }
    }
}
