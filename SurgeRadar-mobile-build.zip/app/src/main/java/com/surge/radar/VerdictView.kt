package com.surge.radar

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.OvershootInterpolator
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.roundToInt

/** Значок вердикта: галочка, крестик или «!». Рисуется постепенно, вокруг расходится кольцо. */
class VerdictIconView(context: Context) : View(context) {

    var verdict: Verdict = Verdict.GOOD
    private var progress = 1f
    private var ring = 1f
    private var anim: ValueAnimator? = null

    private val density = resources.displayMetrics.density
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f * density
    }
    private val symbol = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        strokeWidth = 3.2f * density
    }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }

    fun play() {
        anim?.cancel()
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 900L
            addUpdateListener {
                val t = it.animatedValue as Float
                progress = min(1f, t / 0.55f)
                ring = t
                invalidate()
            }
            start()
        }
    }

    fun showStatic() {
        anim?.cancel()
        progress = 1f
        ring = 1f
        invalidate()
    }

    override fun onDetachedFromWindow() {
        anim?.cancel()
        super.onDetachedFromWindow()
    }

    private fun drawPoly(canvas: Canvas, p: FloatArray, prog: Float) {
        val n = p.size / 2 - 1
        val seg = FloatArray(n)
        var total = 0f
        for (i in 0 until n) {
            seg[i] = hypot(p[2 * i + 2] - p[2 * i], p[2 * i + 3] - p[2 * i + 1])
            total += seg[i]
        }
        var remain = total * prog.coerceIn(0f, 1f)
        for (i in 0 until n) {
            if (remain <= 0f) break
            val len = min(remain, seg[i])
            val k = if (seg[i] == 0f) 0f else len / seg[i]
            canvas.drawLine(
                p[2 * i], p[2 * i + 1],
                p[2 * i] + (p[2 * i + 2] - p[2 * i]) * k,
                p[2 * i + 1] + (p[2 * i + 3] - p[2 * i + 1]) * k,
                symbol
            )
            remain -= len
        }
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(cx, cy) * 0.7f
        if (r <= 0f) return
        val c = OrderEconomics.color(verdict)

        fill.color = withAlpha(c, 0.18f)
        canvas.drawCircle(cx, cy, r, fill)
        stroke.color = withAlpha(c, 0.85f)
        canvas.drawCircle(cx, cy, r, stroke)
        if (ring < 1f) {
            stroke.color = withAlpha(c, (1f - ring) * 0.6f)
            canvas.drawCircle(cx, cy, r * (1f + 0.45f * ring), stroke)
        }

        symbol.color = c
        when (verdict) {
            Verdict.GOOD -> drawPoly(
                canvas,
                floatArrayOf(cx - 0.42f * r, cy + 0.02f * r, cx - 0.1f * r, cy + 0.34f * r, cx + 0.46f * r, cy - 0.32f * r),
                progress
            )
            Verdict.BAD -> {
                drawPoly(canvas, floatArrayOf(cx - 0.34f * r, cy - 0.34f * r, cx + 0.34f * r, cy + 0.34f * r), min(1f, progress * 2f))
                drawPoly(canvas, floatArrayOf(cx + 0.34f * r, cy - 0.34f * r, cx - 0.34f * r, cy + 0.34f * r), (progress * 2f - 1f).coerceAtLeast(0f))
            }
            Verdict.OK -> {
                drawPoly(canvas, floatArrayOf(cx, cy - 0.42f * r, cx, cy + 0.1f * r), progress)
                if (progress > 0.8f) {
                    dot.color = c
                    canvas.drawCircle(cx, cy + 0.4f * r, 2.2f * density, dot)
                }
            }
        }
    }
}

/** Небольшая плашка с вердиктом по заказу: значок, заголовок, чистый доход и ₽/км, ₽/час. */
class VerdictView(context: Context, private val cfg: WidgetSettings.Values) : LinearLayout(context) {

    private val f = cfg.scale / 100f
    private val fk = cfg.fontPct / 100f
    private val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

    private fun px(v: Float): Int = (v * resources.displayMetrics.density * f).roundToInt()

    private fun tv(size: Float, color: Int, strong: Boolean): TextView =
        TextView(context).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_SP, size * f * fk)
            setTextColor(color)
            typeface = weightTypeface(if (strong) min(900, cfg.fontWeight + 300) else cfg.fontWeight)
            includeFontPadding = false
            setPadding(0, px(1f), 0, px(1f))
        }

    private val icon = VerdictIconView(context)
    private val title = tv(15f, Color.WHITE, true)
    private val line1 = tv(11f, Color.WHITE, false)
    private val line2 = tv(10.5f, 0xFFB7C6CF.toInt(), false)
    private val frame = GradientDrawable().apply { cornerRadius = px(16f).toFloat() }
    private var current: Verdict? = null

    init {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        background = frame
        setPadding(px(8f), px(6f), px(12f), px(6f))
        minimumWidth = px(140f)

        addView(icon, LinearLayout.LayoutParams(px(38f), px(38f)))
        val col = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        col.addView(title)
        col.addView(line1)
        col.addView(line2)
        addView(col, LinearLayout.LayoutParams(wrap, wrap).apply { leftMargin = px(6f) })
    }

    private fun apply(r: VerdictResult) {
        val c = OrderEconomics.color(r.verdict)
        val a = (cfg.bgAlpha * 255 / 100).coerceIn(150, 255)
        frame.setColor(Color.argb(a, 8, 18, 28))
        frame.setStroke(px(2f).coerceAtLeast(2), withAlpha(c, 0.95f))
        icon.verdict = r.verdict
        title.text = OrderEconomics.title(r.verdict)
        title.setTextColor(c)
        line1.text = "чистыми ≈${r.net.roundToInt()} ₽"
        line2.text = "${r.perKm.roundToInt()} ₽/км · ${r.perHour.roundToInt()} ₽/ч" + if (r.estimated) " *" else ""
    }

    /** Обновить цифры без повторной анимации (например, когда уточнился адрес). */
    fun update(r: VerdictResult) {
        current = r.verdict
        apply(r)
        icon.showStatic()
    }

    fun show(r: VerdictResult) {
        current = r.verdict
        apply(r)
        animate().cancel()
        scaleX = 0.6f
        scaleY = 0.6f
        alpha = 0f
        translationX = 0f
        animate()
            .scaleX(1f).scaleY(1f).alpha(1f)
            .setDuration(320L)
            .setInterpolator(OvershootInterpolator(1.6f))
            .withEndAction {
                if (r.verdict == Verdict.BAD) {
                    val d = resources.displayMetrics.density
                    ObjectAnimator.ofFloat(
                        this, View.TRANSLATION_X,
                        0f, -9f * d, 9f * d, -7f * d, 7f * d, -3f * d, 3f * d, 0f
                    ).setDuration(420L).start()
                }
            }
            .start()
        icon.play()
    }
}
