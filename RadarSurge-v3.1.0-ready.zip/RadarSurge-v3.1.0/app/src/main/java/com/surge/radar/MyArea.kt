package com.surge.radar

import android.content.Context
import android.content.SharedPreferences
import java.util.Calendar
import java.util.TimeZone
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Помощник для режима Яндекс Про «Мой район».
 *
 * Важно: приложение НЕ управляет режимом внутри Яндекс Про (у Яндекса нет для этого API).
 * Оно ведёт собственную «сессию» (радиус, таймер, дневной лимит), считает по модели спроса,
 * окупается ли повышенная комиссия в выбранном районе, подсказывает лучшее время и место
 * включения, рисует район на карте и учитывает повышенную комиссию в оценке заказов.
 * Значения комиссии и лимита времени можно поправить в приложении: Яндекс может их менять.
 */
object MyArea {
    private const val PREFS = "my_area"
    const val MIN_KM = 1.0f
    const val MAX_KM = 15.0f

    enum class Verdict(val title: String, val color: Int) {
        GOOD("ВЫГОДНО ВКЛЮЧИТЬ", 0xFF55D68B.toInt()),
        OK("МОЖНО ВКЛЮЧИТЬ", 0xFFFFD34E.toInt()),
        WAIT("ЛУЧШЕ ПОДОЖДАТЬ", 0xFFFF8A4D.toInt()),
        NO_DATA("НЕТ ДАННЫХ", 0xFF93A1B0.toInt())
    }

    class Session(
        val lat: Double,
        val lon: Double,
        val name: String,
        val radiusKm: Double,
        val startAt: Long,
        val endAt: Long
    )

    class ZoneRow(val zone: SurgeZone, val pct: Int, val distKm: Double)
    class SlotRow(val timeMs: Long, val pct: Int)
    class Alt(val zone: SurgeZone, val avgPct: Int, val distFromMeKm: Double, val direction: String)

    class Analysis(
        val zones: List<ZoneRow>,
        val avgPct: Int,
        val maxPct: Int,
        val cityPct: Int,
        val breakEvenPct: Int,
        val verdict: Verdict,
        val verdictText: String,
        val airportWarning: String?,
        val spots: List<HotSpot>,
        val slots: List<SlotRow>,
        val bestSlot: SlotRow?,
        val alternatives: List<Alt>
    )

    // ----- Хранилище -----

    private fun prefs(c: Context): SharedPreferences =
        c.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun radiusKm(c: Context): Float = prefs(c).getFloat("radius", 3.0f).coerceIn(MIN_KM, MAX_KM)
    fun setRadiusKm(c: Context, v: Float) {
        prefs(c).edit().putFloat("radius", v.coerceIn(MIN_KM, MAX_KM)).apply()
    }

    fun durationMin(c: Context): Int = prefs(c).getInt("dur", 60).coerceIn(10, 600)
    fun setDurationMin(c: Context, v: Int) {
        prefs(c).edit().putInt("dur", v.coerceIn(10, 600)).apply()
    }

    /** На сколько процентных пунктов комиссия в режиме выше обычной. */
    fun extraComm(c: Context): Int = prefs(c).getInt("extra", 9).coerceIn(0, 40)
    fun setExtraComm(c: Context, v: Int) {
        prefs(c).edit().putInt("extra", v.coerceIn(0, 40)).apply()
    }

    /** Сколько минут в сутки можно работать в режиме (в разных городах по-разному). */
    fun dailyLimitMin(c: Context): Int = prefs(c).getInt("limit", 120).coerceIn(15, 1440)
    fun setDailyLimitMin(c: Context, v: Int) {
        prefs(c).edit().putInt("limit", v.coerceIn(15, 1440)).apply()
    }

    /** 0 — где я (GPS), 1 — закреплённая зона, 2 — выбранная зона. */
    fun centerMode(c: Context): Int = prefs(c).getInt("cmode", 0).coerceIn(0, 2)
    fun setCenterMode(c: Context, v: Int) {
        prefs(c).edit().putInt("cmode", v.coerceIn(0, 2)).apply()
    }

    fun customZone(c: Context): String? = prefs(c).getString("czone", null)
    fun setCustomZone(c: Context, name: String?) {
        prefs(c).edit().putString("czone", name).apply()
    }

    // ----- Сессия -----

    fun session(c: Context): Session? {
        val p = prefs(c)
        if (!p.getBoolean("active", false)) return null
        val end = p.getLong("endAt", 0L)
        if (System.currentTimeMillis() >= end) {
            finish(c, end)
            return null
        }
        return Session(
            lat = p.getString("sLat", "0")?.toDoubleOrNull() ?: 0.0,
            lon = p.getString("sLon", "0")?.toDoubleOrNull() ?: 0.0,
            name = p.getString("sName", "") ?: "",
            radiusKm = (p.getString("sRadius", "3")?.toDoubleOrNull() ?: 3.0),
            startAt = p.getLong("startAt", 0L),
            endAt = end
        )
    }

    fun isActive(c: Context): Boolean = session(c) != null

    fun remainingMs(c: Context): Long {
        val s = session(c) ?: return 0L
        return max(0L, s.endAt - System.currentTimeMillis())
    }

    fun start(c: Context, lat: Double, lon: Double, name: String, radiusKm: Double, minutes: Int) {
        val now = System.currentTimeMillis()
        prefs(c).edit()
            .putBoolean("active", true)
            .putLong("startAt", now)
            .putLong("endAt", now + minutes * 60_000L)
            .putString("sLat", lat.toString())
            .putString("sLon", lon.toString())
            .putString("sName", name)
            .putString("sRadius", radiusKm.toString())
            .putLong("previewUntil", 0L)
            .apply()
    }

    fun stop(c: Context) {
        if (prefs(c).getBoolean("active", false)) {
            finish(c, minOf(System.currentTimeMillis(), prefs(c).getLong("endAt", Long.MAX_VALUE)))
        }
    }

    private fun finish(c: Context, at: Long) {
        val p = prefs(c)
        val start = p.getLong("startAt", at)
        addUsed(c, max(0L, at - start))
        p.edit().putBoolean("active", false).apply()
    }

    private fun dayStamp(now: Long): Int {
        val cal = Calendar.getInstance(TimeZone.getTimeZone("Europe/Moscow"))
        cal.timeInMillis = now
        return cal.get(Calendar.YEAR) * 1000 + cal.get(Calendar.DAY_OF_YEAR)
    }

    private fun storedUsed(c: Context): Long {
        val p = prefs(c)
        return if (p.getInt("day", 0) == dayStamp(System.currentTimeMillis())) p.getLong("usedMs", 0L) else 0L
    }

    private fun addUsed(c: Context, ms: Long) {
        val base = storedUsed(c)
        prefs(c).edit()
            .putInt("day", dayStamp(System.currentTimeMillis()))
            .putLong("usedMs", base + ms)
            .apply()
    }

    /** Сколько миллисекунд режима использовано сегодня (по МСК), с учётом идущей сессии. */
    fun usedTodayMs(c: Context): Long {
        val s = session(c)
        val running = if (s != null) System.currentTimeMillis() - s.startAt else 0L
        return storedUsed(c) + max(0L, running)
    }

    fun remainingTodayMs(c: Context): Long =
        max(0L, dailyLimitMin(c) * 60_000L - usedTodayMs(c))

    // ----- Предпросмотр и карта -----

    fun setPreview(c: Context, lat: Double, lon: Double, name: String, radiusKm: Double) {
        prefs(c).edit()
            .putString("pLat", lat.toString())
            .putString("pLon", lon.toString())
            .putString("pName", name)
            .putString("pRadius", radiusKm.toString())
            .putLong("previewUntil", System.currentTimeMillis() + 5 * 60_000L)
            .apply()
    }

    /** Круг района для карты: идущая сессия или предпросмотр на 5 минут. */
    fun overlay(c: Context): AreaCircle? {
        val s = session(c)
        if (s != null) {
            val left = ((s.endAt - System.currentTimeMillis()) / 60_000L).toInt().coerceAtLeast(0)
            return AreaCircle(s.lat, s.lon, s.radiusKm, true, "МОЙ РАЙОН · ${fmtKm(s.radiusKm)} км · $left мин")
        }
        val p = prefs(c)
        if (System.currentTimeMillis() < p.getLong("previewUntil", 0L)) {
            val lat = p.getString("pLat", null)?.toDoubleOrNull() ?: return null
            val lon = p.getString("pLon", null)?.toDoubleOrNull() ?: return null
            val r = p.getString("pRadius", null)?.toDoubleOrNull() ?: return null
            return AreaCircle(lat, lon, r, false, "РАЙОН · ${fmtKm(r)} км")
        }
        return null
    }

    // ----- Комиссия и заказы -----

    /** Комиссия для расчёта заказа: в активном режиме «Мой район» она выше. */
    fun effectiveCommission(c: Context, base: Int): Int =
        if (isActive(c)) (base + extraComm(c)).coerceAtMost(60) else base

    fun contains(c: Context, lat: Double, lon: Double): Boolean {
        val s = session(c) ?: return true
        return MoscowRegionGrid.distanceKm(s.lat, s.lon, lat, lon) <= s.radiusKm + 0.2
    }

    // ----- Анализ района -----

    fun fmtKm(v: Double): String = String.format(java.util.Locale.US, "%.1f", v)

    fun directionText(lat1: Double, lon1: Double, lat2: Double, lon2: Double): String {
        val dLon = Math.toRadians(lon2 - lon1)
        val la1 = Math.toRadians(lat1)
        val la2 = Math.toRadians(lat2)
        val y = sin(dLon) * cos(la2)
        val x = cos(la1) * sin(la2) - sin(la1) * cos(la2) * cos(dLon)
        val deg = (Math.toDegrees(atan2(y, x)) + 360.0) % 360.0
        val names = arrayOf(
            "север", "северо-восток", "восток", "юго-восток", "юг", "юго-запад", "запад", "северо-запад"
        )
        return names[((deg + 22.5) / 45.0).toInt() % 8]
    }

    /**
     * Оценка района по модели спроса приложения (это не официальные данные Яндекса).
     * [meLat]/[meLon] — где водитель сейчас: нужно для подсказки «где лучше включить режим».
     */
    fun analyze(
        c: Context,
        lat: Double,
        lon: Double,
        radiusKm: Double,
        meLat: Double,
        meLon: Double,
        now: Long = System.currentTimeMillis()
    ): Analysis {
        val cfg = WidgetSettings.load(c)
        val tariffs = cfg.enabledTariffs()

        val ground = MoscowRegionGrid.zones.filter { DemandModel.kindOf(it) != DemandModel.Kind.AIRPORT }

        fun pctNow(z: SurgeZone): Int =
            if (tariffs.isEmpty()) 0 else DemandModel.maxPct(DemandModel.baseCoeff(z, now), tariffs)

        // спрос по всем наземным зонам считаем один раз
        val pctMap = HashMap<String, Int>(ground.size * 2)
        for (z in ground) pctMap[z.name] = pctNow(z)

        var inside = ground
            .map { ZoneRow(it, pctMap[it.name] ?: 0, MoscowRegionGrid.distanceKm(lat, lon, it.lat, it.lon)) }
            .filter { it.distKm <= radiusKm }
        if (inside.isEmpty()) {
            val near = ground.minByOrNull { MoscowRegionGrid.distanceKm(lat, lon, it.lat, it.lon) }
            if (near != null) {
                inside = listOf(
                    ZoneRow(near, pctMap[near.name] ?: 0, MoscowRegionGrid.distanceKm(lat, lon, near.lat, near.lon))
                )
            }
        }
        inside = inside.sortedByDescending { it.pct }

        val avg = if (inside.isEmpty()) 0 else inside.map { it.pct }.average().roundToInt()
        val mx = inside.maxOfOrNull { it.pct } ?: 0

        // средний уровень по Москве: медиана по наземным зонам
        val sorted = pctMap.values.sorted()
        val city = if (sorted.isEmpty()) 0 else sorted[sorted.size / 2]

        // порог окупаемости: во сколько раз должен вырасти валовый доход, чтобы после
        // повышенной комиссии на руки осталось столько же
        val base = cfg.commissionPct
        val extra = extraComm(c)
        val ratio = (100.0 - base) / max(1.0, 100.0 - base - extra)
        val breakEven = ((ratio - 1.0) * 100.0).roundToInt().coerceAtLeast(0)

        val verdict: Verdict
        val verdictText: String
        when {
            tariffs.isEmpty() -> {
                verdict = Verdict.NO_DATA
                verdictText = "Включите хотя бы один тариф в настройках — без него спрос не посчитать."
            }
            avg >= breakEven + 10 -> {
                verdict = Verdict.GOOD
                verdictText = "Спрос ${DemandModel.coefText(avg)} выше порога окупаемости " +
                    "${DemandModel.coefText(breakEven)}: повышенная комиссия компенсируется."
            }
            avg >= breakEven -> {
                verdict = Verdict.OK
                verdictText = "Спрос ${DemandModel.coefText(avg)} около порога ${DemandModel.coefText(breakEven)}: " +
                    "выигрыш в основном в удобстве и коротких поездках."
            }
            else -> {
                verdict = Verdict.WAIT
                verdictText = "Спрос ${DemandModel.coefText(avg)} ниже порога ${DemandModel.coefText(breakEven)}: " +
                    "по деньгам хуже, чем по всему городу. Включайте, если важно остаться рядом (дом, конец смены)."
            }
        }

        // аэропорты рядом: Яндекс не даёт работать в режиме около аэропортов
        val airport = PoiCatalog.fixed
            .filter { it.kind == PoiKind.AIRPORT }
            .map { it to MoscowRegionGrid.distanceKm(lat, lon, it.lat, it.lon) }
            .filter { it.second <= radiusKm + 3.0 }
            .minByOrNull { it.second }
        val airportWarning = airport?.let {
            "Рядом аэропорт ${it.first.name} (${fmtKm(it.second)} км): вблизи аэропортов «Мой район» не работает."
        }

        // вокзалы и больницы внутри района (без аэропортов)
        val spots = HotSpots.compute(c, cfg.copy(hotMin = 0, hotCats = 14), now)
            .filter { MoscowRegionGrid.distanceKm(lat, lon, it.poi.lat, it.poi.lon) <= radiusKm }
            .take(5)

        // лучшее время включения: модель спроса на ближайшие 3 часа, шаг 30 минут
        val slots = ArrayList<SlotRow>()
        if (tariffs.isNotEmpty() && inside.isNotEmpty()) {
            for (i in 0..6) {
                val t = now + i * 30 * 60_000L
                val pcts = inside.map { DemandModel.maxPct(DemandModel.baseCoeff(it.zone, t, false), tariffs) }
                slots.add(SlotRow(t, pcts.average().roundToInt()))
            }
        }
        val best = slots.maxByOrNull { it.pct }

        // где ещё рядом с вами район получится выгоднее
        val alts = ArrayList<Alt>()
        if (tariffs.isNotEmpty()) {
            for (z in ground) {
                val dMe = MoscowRegionGrid.distanceKm(meLat, meLon, z.lat, z.lon)
                if (dMe > 12.0) continue
                if (MoscowRegionGrid.distanceKm(lat, lon, z.lat, z.lon) < 1.5) continue
                val around = ground.filter { MoscowRegionGrid.distanceKm(z.lat, z.lon, it.lat, it.lon) <= radiusKm }
                val ps = if (around.isEmpty()) listOf(pctMap[z.name] ?: 0) else around.map { pctMap[it.name] ?: 0 }
                val a = ps.average().roundToInt()
                if (a >= avg + 8) {
                    alts.add(Alt(z, a, dMe, directionText(meLat, meLon, z.lat, z.lon)))
                }
            }
        }

        return Analysis(
            zones = inside,
            avgPct = avg,
            maxPct = mx,
            cityPct = city,
            breakEvenPct = breakEven,
            verdict = verdict,
            verdictText = verdictText,
            airportWarning = airportWarning,
            spots = spots,
            slots = slots,
            bestSlot = best,
            alternatives = alts.sortedByDescending { it.avgPct }.take(3)
        )
    }
}
