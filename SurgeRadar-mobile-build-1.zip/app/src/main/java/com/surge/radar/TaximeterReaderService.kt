package com.surge.radar

import android.accessibilityservice.AccessibilityService
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.content.Intent
import android.location.Geocoder
import kotlinx.coroutines.*
import java.util.Locale
import java.util.regex.Pattern

class TaximeterReaderService : AccessibilityService() {

    private val coeffRegex = Pattern.compile(
        "(?:×|x|х)\\s*([1-4](?:[.,][0-9]{1,2})?)",
        Pattern.CASE_INSENSITIVE
    )
    private val rubRegex = Pattern.compile(
        "(\\d{1,3}(?:[\\s\\u00A0]\\d{3}){0,2}|\\d{3,5})\\s*[₽рР]"
    )
    private val minRegex = Pattern.compile("(\\d{1,3})\\s*(?:мин|min)", Pattern.CASE_INSENSITIVE)
    private val kmRegex = Pattern.compile("(\\d{1,3}(?:[.,]\\d{1,2})?)\\s*км(?!/)", Pattern.CASE_INSENSITIVE)
    // Фразы экранов активного заказа и поездки: пока они на экране, виджет прячется
    // Фразы главного экрана Яндекс Про после входа в аккаунт: по ним вход подтверждается автоматически
    private val loginWords = listOf("выйти на линию", "уйти с линии", "на линии", "баланс", "заказы")
    private val tripWords = listOf("начать поездку", "завершить поездку", "завершить заказ", "я на месте", "в пути")
    private val addressRegex = Pattern.compile(
        "(?i).*(ул\\.|улица|пр-т|проспект|ш\\.|шоссе|б-р|бульвар|пер\\.|переулок|наб\\.|мкр|проезд|площадь|Москва|Люберцы|Жулебино|Химки|Мытищи|Балашиха|Одинцово|Подольск|Видное|Красногорск|Котельники|Реутов|Домодедово|Шереметьево|Внуково).*"
    )

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val spaceRegex = Regex("[\\s\\u00A0]")
    private val handler = Handler(Looper.getMainLooper())
    private var scanPending = false
    private var lastScanAt = 0L
    private var idleScan = true
    private var lastAddress = ""
    private var lastHash = 0
    private var lastOfferSeenAt = 0L
    private var shownKey = ""
    private var lastNewOrderAt = 0L
    private var lastTrip = false
    private var lastHashAt = 0L
    private val pm by lazy { getSystemService(POWER_SERVICE) as PowerManager }

    override fun onServiceConnected() {
        super.onServiceConnected()
        RadarEngine.init(this)
    }

    private val scanRunnable = Runnable {
        scanPending = false
        scanNow()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val type = event?.eventType ?: return
        val now = SystemClock.uptimeMillis()
        // Новое окно или экран проверяем сразу. Остальные изменения: не чаще чем раз в 250 мс,
        // а когда на экране ничего похожего на заказ нет, раз в 500 мс. Последнее событие не теряется:
        // если оно пришло слишком рано, проверка откладывается на оставшееся время.
        val minGap = when {
            type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> 0L
            idleScan -> 500L
            else -> 250L
        }
        val since = now - lastScanAt
        if (since >= minGap) {
            handler.removeCallbacks(scanRunnable)
            scanPending = false
            scanNow()
        } else if (!scanPending) {
            scanPending = true
            handler.postDelayed(scanRunnable, minGap - since)
        }
    }

    private fun scanNow() {
        lastScanAt = SystemClock.uptimeMillis()
        if (!pm.isInteractive) return
        val now = System.currentTimeMillis()

        // На Android 13+ дерево экрана подгружается заранее одним запросом, это заметно быстрее
        val root = (if (Build.VERSION.SDK_INT >= 33) {
            getRootInActiveWindow(
                AccessibilityNodeInfo.FLAG_PREFETCH_DESCENDANTS_HYBRID or
                    AccessibilityNodeInfo.FLAG_PREFETCH_UNINTERRUPTIBLE
            )
        } else rootInActiveWindow) ?: return
        YandexLink.markSeen(this)
        val texts = ArrayList<String>(128)
        collectNodes(root, texts, intArrayOf(300))
        val h = texts.hashCode()
        if (h == lastHash && now - lastHashAt < 15_000L) return
        lastHash = h
        lastHashAt = now

        var coeff = 0.0
        var price: String? = null
        var priceVal = 0.0
        var accept = false
        var duration: String? = null
        val kms = ArrayList<Double>(4)
        val mins = ArrayList<Int>(4)
        var tariff: String? = null
        var trip = false
        var loggedIn = false

        for (raw in texts) {
            val text = raw.trim()
            if (text.isEmpty()) continue

            // тяжёлые регулярки запускаем, только если в строке есть нужные символы
            if (text.indexOf('×') >= 0 || text.indexOf('x') >= 0 || text.indexOf('х') >= 0) {
                val cm = coeffRegex.matcher(text.replace(',', '.'))
                while (cm.find()) {
                    cm.group(1)?.toDoubleOrNull()?.let {
                        if (it in 1.0..5.0) coeff = maxOf(coeff, it)
                    }
                }
            }

            val rm = rubRegex.matcher(text)
            if (rm.find()) {
                val n = rm.group(1).replace(spaceRegex, "")
                // цена заказа: берём наибольшую из обычных сумм, чтобы не зависеть от порядка элементов
                n.toDoubleOrNull()?.let { v ->
                    if (v in 100.0..9999.0 && v > priceVal) {
                        priceVal = v
                        price = "$n ₽"
                    }
                }
            }

            val mm = minRegex.matcher(text)
            while (mm.find()) {
                duration = "${mm.group(1)} мин"
                mm.group(1)?.toIntOrNull()?.let { mins.add(it) }
            }

            val km = kmRegex.matcher(text)
            while (km.find()) {
                km.group(1)?.replace(',', '.')?.toDoubleOrNull()?.let { if (it in 0.1..400.0) kms.add(it) }
            }

            val low = text.lowercase()
            if (!accept && low.startsWith("принять") && low.length <= 24) accept = true
            if (!trip && tripWords.any { low.contains(it) }) trip = true
            if (!loggedIn && loginWords.any { low.contains(it) }) loggedIn = true
            if (tariff == null) {
                tariff = when {
                    low.contains("комфорт+") || low.contains("комфорт плюс") -> "COMFORT_PLUS"
                    low.contains("комфорт") -> "COMFORT"
                    low.contains("эконом") -> "ECONOM"
                    else -> null
                }
            }
        }
        idleScan = priceVal <= 0.0 && !accept && coeff <= 0.0
        if (loggedIn && !YandexLink.isLoginConfirmed(this)) YandexLink.setLoginConfirmed(this, true)

        val overlayOn = WidgetSettings.load(this).overlayOn
        if (overlayOn && (trip || lastTrip)) {
            // пока на экране заказ/поездка, окошко прячется; после неё возвращается
            runCatching { startService(Intent(this, OverlayWidgetService::class.java).putExtra("TRIP", trip)) }
        }
        lastTrip = trip

        if (coeff <= 0.0 && price == null && duration == null) return
        if (coeff > 0.0 || price != null) YandexLink.markData(this)

        val priceNum = if (priceVal > 0.0) priceVal else null
        val hasOrderData = priceNum != null && kms.isNotEmpty()
        if (accept && hasOrderData && !trip) YandexLink.setAcceptLearned(this)

        // Предложение заказа: вердикт показываем ОДИН раз и только до принятия.
        // Когда кнопка «Принять» уже встречалась, предложением считается лишь экран, где она есть:
        // после принятия она пропадает, и цифры дороги и времени на экране больше ничего не запускают.
        val learned = YandexLink.acceptLearned(this)
        val offerLike = !trip && hasOrderData && (accept || !learned)
        var isNewOrder = false
        if (offerLike && priceNum != null) {
            val key = priceNum.toInt().toString()
            val gap = now - lastOfferSeenAt
            lastOfferSeenAt = now
            val absentBefore = gap > (if (learned) 2500L else 4000L)
            // заказ на экране сменился сразу на другой (без паузы) бывает только при кнопке «Принять»
            val swapped = learned && key != shownKey && now - lastNewOrderAt > 8000L
            if (absentBefore || swapped) {
                isNewOrder = true
                shownKey = key
                lastNewOrderAt = now
            }
        }

        if (coeff > 0.0 || isNewOrder) {
            val update = Intent(this, OverlayWidgetService::class.java).apply {
                if (coeff > 0) putExtra("COEFF", coeff)
                if (isNewOrder && priceNum != null) {
                    putExtra("PRICE_NUM", priceNum)
                    putExtra("KMS", kms.toDoubleArray())
                    putExtra("MINS", mins.toIntArray())
                    tariff?.let { putExtra("TARIFF", it) }
                    putExtra("NEW_ORDER", true)
                }
            }
            if (overlayOn) {
                // новый заказ: один вызов сразу запускает службу (если нужно) и передаёт данные
                if (isNewOrder) runCatching { OverlayWidgetService.startWith(this, update) }
                else runCatching { startService(update) }
            } else if (coeff > 0) {
                // Виджет выключен: просто запоминаем реальный коэффициент, он уточняет расчёт спроса
                RadarEngine.record(this, coeff, null, null, WidgetSettings.load(this).zone)
            }
        }

        if (priceNum != null) {
            var address: String? = null
            for (raw in texts) {
                val t = raw.trim()
                if (t.length in 6..120 && addressRegex.matcher(t).matches()) address = t
            }
            if (address != null && address != lastAddress) {
                lastAddress = address
                resolveDestination(address)
            }
        }
    }

    private fun resolveDestination(address: String) {
        scope.launch {
            var zone = MoscowRegionGrid.byText(address)

            if (zone == null) {
                runCatching {
                    @Suppress("DEPRECATION")
                    val result = Geocoder(this@TaximeterReaderService, Locale("ru", "RU"))
                        .getFromLocationName("Москва и Московская область, $address", 1)

                    if (!result.isNullOrEmpty()) {
                        val p = result[0]
                        zone = MoscowRegionGrid.nearest(p.latitude, p.longitude)
                    }
                }
            }

            zone?.let {
                val intent = Intent(this@TaximeterReaderService, OverlayWidgetService::class.java).apply {
                    putExtra("DEST_NAME", it.name)
                }
                if (WidgetSettings.load(this@TaximeterReaderService).overlayOn) {
                    runCatching { startService(intent) }
                }
            }
        }
    }

    private fun collectNodes(node: AccessibilityNodeInfo?, out: MutableList<String>, budget: IntArray) {
        if (node == null || budget[0] <= 0) return
        budget[0]--
        node.text?.toString()?.takeIf { it.isNotBlank() }?.let(out::add)
        node.contentDescription?.toString()?.takeIf { it.isNotBlank() }?.let(out::add)
        for (i in 0 until node.childCount) {
            collectNodes(node.getChild(i), out, budget)
        }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        scope.cancel()
        super.onDestroy()
    }
}
