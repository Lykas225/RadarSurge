package com.surge.radar

import android.content.Context
import java.util.Locale
import kotlin.math.max
import kotlin.math.roundToInt

enum class OrderVerdict(val title: String, val color: Int) {
    PROFITABLE("ВЫГОДНО", 0xFF55D68B.toInt()),
    NEUTRAL("МОЖНО БРАТЬ", 0xFFFFD34E.toInt()),
    UNPROFITABLE("НЕВЫГОДНО", 0xFFFF5964.toInt()),
    INSUFFICIENT("НЕТ ТОЧКИ Б", 0xFF93A1B0.toInt())
}

data class OrderEvaluation(
    val offer: OrderOffer,
    val tariff: OrderTariff,
    val pickupMin: Int,
    val pickupKm: Double,
    val tripMin: Int,
    val tripKm: Double,
    val totalMin: Int,
    val totalKm: Double,
    val grossRub: Int,
    val priceEstimated: Boolean,
    val commissionRub: Int,
    val fuelRub: Int,
    val wearRub: Int,
    val netRub: Int,
    val rubPerHour: Int,
    val rubPerKm: Int,
    val destZoneName: String,
    val destZonePct: Int,
    val score: Int,
    val verdict: OrderVerdict,
    val reason: String,
    val routeSource: String
)

/**
 * Расчёт стоимости по тарифу, чистой прибыли (минус комиссия, бензин, износ),
 * ставки в час / за км и итогового вердикта выгодности поездки.
 */
object OrderEvaluator {

    fun evaluate(context: Context, offer: OrderOffer, route: RouteEstimate? = null): OrderEvaluation {
        val cfg = WidgetSettings.load(context)
        val now = System.currentTimeMillis()
        val avgSpeed = RouteEstimator.avgCitySpeedKmh(now)

        // 1. Подача
        val pickupMin = offer.pickupMin
            ?: offer.pickupKm?.let { max(2, (it / avgSpeed * 60.0).roundToInt()) }
            ?: 5
        val pickupKm = offer.pickupKm
            ?: ((pickupMin / 60.0 * avgSpeed * 10.0).roundToInt() / 10.0).coerceAtLeast(0.6)

        // 2. Поездка А → Б
        val routeSource: String
        val tripMin: Int
        val tripKm: Double
        var tripInferred = false
        when {
            route != null -> {
                tripMin = offer.tripMin ?: route.durationMin
                tripKm = offer.tripKm ?: route.distanceKm
                routeSource = if (offer.tripMin != null && offer.tripKm != null) "с карточки" else route.source
            }
            offer.tripMin != null && offer.tripKm != null -> {
                tripMin = offer.tripMin
                tripKm = offer.tripKm
                routeSource = "с карточки"
            }
            offer.tripKm != null -> {
                tripKm = offer.tripKm
                tripMin = max(4, (tripKm / avgSpeed * 60.0).roundToInt())
                routeSource = "оценка по км"
            }
            offer.tripMin != null -> {
                tripMin = offer.tripMin
                tripKm = max(1.0, (tripMin / 60.0 * avgSpeed * 10.0).roundToInt() / 10.0)
                routeSource = "оценка по мин"
            }
            else -> {
                // Б скрыта: если есть цена с карточки, восстанавливаем длину поездки по тарифу
                val inf = offer.priceRub?.let {
                    OrderTariffRates.inferTrip(
                        offer.tariff, it.toDouble(), offer.surgeCoeff ?: 1.0, offer.surgeBonusRub, avgSpeed
                    )
                }
                if (inf != null) {
                    tripKm = inf.first
                    tripMin = inf.second
                    routeSource = "оценка по цене"
                    tripInferred = true
                } else {
                    tripMin = 15
                    tripKm = 7.0
                    routeSource = "средняя оценка"
                }
            }
        }

        // 3. Коэффициент и стоимость по поступившему тарифу
        val zone = MoscowRegionGrid.zones.firstOrNull { it.name == cfg.zone } ?: MoscowRegionGrid.zones.first()
        val modelCoeff = 1.0 + (DemandModel.baseCoeff(zone, now) - 1.0) * offer.tariff.surgeK
        val effCoeff = (offer.surgeCoeff ?: modelCoeff).coerceIn(1.0, 4.0)

        val priceEstimated = offer.priceRub == null
        val grossRub = offer.priceRub ?: OrderTariffRates.estimatePriceRub(
            tariff = offer.tariff,
            tripMin = tripMin.toDouble(),
            tripKm = tripKm,
            surgeCoeff = effCoeff,
            surgeBonusRub = offer.surgeBonusRub
        )

        // 4. Экономика поездки
        val totalKm = max(0.5, pickupKm + tripKm)
        val totalMin = max(5, pickupMin + tripMin + 3) // +3 мин посадка/высадка
        // В активном режиме «Мой район» комиссия выше обычной
        val areaOn = MyArea.isActive(context)
        val commissionPct = MyArea.effectiveCommission(context, cfg.commissionPct)
        val commissionRub = (grossRub * commissionPct / 100.0).roundToInt()
        val fuelPrice = FuelPrice.current(context, cfg)
        val litersPer100 = cfg.consumption / 10.0
        val fuelRub = (totalKm * (litersPer100 / 100.0) * fuelPrice).roundToInt()
        val wearRub = (totalKm * (cfg.wear / 10.0)).roundToInt()
        val netRub = (grossRub - commissionRub - fuelRub - wearRub)

        val evalMoney = if (cfg.netMode) netRub else grossRub
        val rubPerHour = (evalMoney * 60.0 / totalMin).roundToInt()
        val rubPerKm = (evalMoney / totalKm).roundToInt()

        // 5. Спрос в точке Б (если известны координаты маршрута)
        var destZoneName = ""
        var destZonePct = 0
        var destBonus = 0
        if (route != null) {
            val dz = MoscowRegionGrid.nearest(route.toLat, route.toLon)
            val distToCenter = MoscowRegionGrid.distanceKm(55.7558, 37.6173, route.toLat, route.toLon)
            destZoneName = dz.name.removePrefix("МО: ").substringBefore(" / ")
            val dBase = DemandModel.baseCoeff(dz, now + totalMin * 60_000L, false)
            destZonePct = DemandModel.pct(1.0 + (dBase - 1.0) * offer.tariff.surgeK)
            destBonus = when {
                destZonePct >= 45 -> 10
                destZonePct >= 20 -> 4
                distToCenter > 28.0 && destZonePct < 10 -> -10
                else -> 0
            }
        }

        // 6. Балл выгодности (0..100) относительно целей водителя
        val hourRatio = rubPerHour.toDouble() / max(100, cfg.targetHour).toDouble()
        val kmRatio = rubPerKm.toDouble() / max(5, cfg.targetKm).toDouble()
        val pickupRatio = pickupMin.toDouble() / totalMin.toDouble()
        val pickupPenalty = when {
            pickupMin >= 12 || pickupRatio > 0.42 -> -16
            pickupMin >= 9 || pickupRatio > 0.34 -> -8
            else -> 0
        }
        val rawScore = (hourRatio * 48.0 + kmRatio * 24.0 + destBonus + pickupPenalty).roundToInt()
        val score = if (netRub <= 0) 0 else rawScore.coerceIn(0, 100)

        val unknownTrip = route == null && offer.tripMin == null && offer.tripKm == null && !tripInferred
        val verdict = when {
            unknownTrip -> OrderVerdict.INSUFFICIENT
            netRub <= 0 || score < 45 -> OrderVerdict.UNPROFITABLE
            score >= 68 -> OrderVerdict.PROFITABLE
            else -> OrderVerdict.NEUTRAL
        }

        val reason = buildString {
            when (verdict) {
                OrderVerdict.PROFITABLE -> {
                    append(if (cfg.netMode) "Чистыми " else "Грязными ")
                    append("$rubPerHour ₽/ч · $rubPerKm ₽/км")
                }
                OrderVerdict.NEUTRAL -> {
                    append(if (pickupPenalty < 0) "Подача ${pickupMin} мин · " else "Средняя ставка · ")
                    append("$rubPerHour ₽/ч")
                }
                OrderVerdict.INSUFFICIENT -> {
                    append("Точка Б и цена скрыты — оценка примерная")
                }
                OrderVerdict.UNPROFITABLE -> {
                    when {
                        netRub <= 0 -> append("Поездка в минус после расходов")
                        pickupPenalty <= -16 -> append("Слишком долгая подача ${pickupMin} мин")
                        hourRatio < 0.75 -> append("Низкий доход: $rubPerHour ₽/ч (цель ${cfg.targetHour})")
                        else -> append("Мало за км: $rubPerKm ₽/км (цель ${cfg.targetKm})")
                    }
                }
            }
            if (destZoneName.isNotBlank()) {
                append(" · Б: $destZoneName ${DemandModel.coefText(destZonePct)}")
            }
            if (tripInferred) append(" · Б скрыта, считаю по цене")
            if (areaOn) {
                if (route != null && !MyArea.contains(context, route.toLat, route.toLon)) {
                    append(" · 🎯 Б вне района")
                } else {
                    append(" · 🎯 ком. $commissionPct%")
                }
            }
        }

        return OrderEvaluation(
            offer = offer,
            tariff = offer.tariff,
            pickupMin = pickupMin,
            pickupKm = pickupKm,
            tripMin = tripMin,
            tripKm = tripKm,
            totalMin = totalMin,
            totalKm = totalKm,
            grossRub = grossRub,
            priceEstimated = priceEstimated,
            commissionRub = commissionRub,
            fuelRub = fuelRub,
            wearRub = wearRub,
            netRub = netRub,
            rubPerHour = rubPerHour,
            rubPerKm = rubPerKm,
            destZoneName = destZoneName,
            destZonePct = destZonePct,
            score = score,
            verdict = verdict,
            reason = reason,
            routeSource = routeSource
        )
    }

    fun detailedSummary(ev: OrderEvaluation): String = buildString {
        val approx = if (ev.priceEstimated) "~" else ""
        append("${ev.verdict.title} (${ev.score}/100) · ${ev.tariff.title}\n")
        if (ev.offer.from.isNotBlank()) append("А: ${ev.offer.from}\n")
        if (ev.offer.to.isNotBlank()) append("Б: ${ev.offer.to}\n")
        append(
            String.format(
                Locale.US,
                "Цена: %s%d ₽ · В пути: %d мин (%.1f км) · Подача: %d мин\n",
                approx, ev.grossRub, ev.tripMin, ev.tripKm, ev.pickupMin
            )
        )
        append("Чистыми: ${ev.netRub} ₽ · ${ev.rubPerHour} ₽/ч · ${ev.rubPerKm} ₽/км\n")
        append("Расходы: ком -${ev.commissionRub} ₽, бенз -${ev.fuelRub} ₽, износ -${ev.wearRub} ₽ (${ev.routeSource})")
        val calib = RouteCalibration.status()
        if (calib.isNotBlank()) append("\nТочность маршрута: $calib")
    }

    fun sampleOffer(): OrderOffer = OrderOffer(
        from = "Москва, Рязанский проспект, 2/1к2В",
        to = "Москва, Пресненская набережная, 12",
        priceRub = null,
        tariff = OrderTariff.COMFORT_PLUS,
        surgeCoeff = 1.4,
        surgeBonusRub = 0,
        pickupMin = 5,
        pickupKm = 1.6,
        tripMin = 24,
        tripKm = 12.8,
        raw = "Тестовая карточка заказа",
        capturedAt = System.currentTimeMillis()
    )
}
