package com.surge.radar

import android.Manifest
import android.animation.ValueAnimator
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.TilesOverlay
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private class TariffRowViews(val tariff: Tariff, val sw: Switch, val pct: TextView, val wait: TextView)

    private val ctx: Context get() = this
    private val matchP = ViewGroup.LayoutParams.MATCH_PARENT
    private val wrapP = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var map: MapView
    private lateinit var heat: HeatOverlay
    private lateinit var p: Palette
    private lateinit var search: EditText
    private lateinit var zoneTitle: TextView
    private lateinit var weatherText: TextView
    private lateinit var labelText: TextView
    private lateinit var hotText: TextView
    private lateinit var overlayBtn: TextView
    private val rowViews = mutableListOf<TariffRowViews>()

    private var values = WidgetSettings.Values()
    private var builtDark = true
    private var updating = false
    private var myLocation: GeoPoint? = null
    private var hotZone: SurgeZone? = null
    private var pulseAnim: ValueAnimator? = null
    private val handler = Handler(Looper.getMainLooper())

    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, values.refreshMin * 60_000L)
        }
    }

    private val locationListener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            onLocation(location)
        }

        @Deprecated("Deprecated in Java")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Configuration.getInstance().apply {
            load(this@MainActivity, getSharedPreferences("osmdroid", MODE_PRIVATE))
            userAgentValue = packageName
            osmdroidBasePath = File(cacheDir, "osmdroid")
            osmdroidTileCache = File(cacheDir, "osmdroid/tiles")
        }
        RadarEngine.init(this)
        values = WidgetSettings.load(this)
        builtDark = values.dark
        p = Palette(values.dark)
        buildUi()
    }

    private fun dp(v: Int): Int = dpi(v)

    private fun tv(t: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(ctx).apply {
            text = t
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

    private fun button(t: String, filled: Boolean, onClick: () -> Unit): TextView =
        TextView(ctx).apply {
            text = t
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(if (filled) 0xFFFFFFFF.toInt() else p.text)
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = if (filled) rounded(p.blue, dp(14).toFloat())
            else rounded(0, dp(14).toFloat(), p.stroke, dp(1))
            setOnClickListener { onClick() }
        }

    private fun buildUi() {
        val root = FrameLayout(ctx)

        map = MapView(ctx).apply {
            setTileSource(TileSourceFactory.MAPNIK)
            setMultiTouchControls(true)
            isTilesScaledToDpi = true
            controller.setZoom(11.0)
            val z = pinnedZone()
            controller.setCenter(GeoPoint(z.lat, z.lon))
            overlayManager.tilesOverlay.setColorFilter(if (p.dark) TilesOverlay.INVERT_COLORS else null)
        }
        heat = HeatOverlay { zone -> pin(zone, false) }
        map.overlays.add(heat)
        root.addView(map, FrameLayout.LayoutParams(matchP, matchP))

        // Верхняя строка поиска
        val top = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(p.card, dp(16).toFloat(), p.stroke, dp(1))
            setPadding(dp(14), dp(2), dp(6), dp(2))
            elevation = dp(6).toFloat()
        }
        search = EditText(ctx).apply {
            hint = "Поиск по адресу или району"
            setSingleLine()
            setTextColor(p.text)
            setHintTextColor(p.sub)
            textSize = 15f
            background = null
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                    doSearch(text.toString())
                    true
                } else false
            }
        }
        val searchBtn = tv("🔍", 20f, p.text).apply {
            setPadding(dp(10), dp(8), dp(10), dp(8))
            setOnClickListener { doSearch(search.text.toString()) }
        }
        val locBtn = tv("◎", 24f, p.accent, true).apply {
            setPadding(dp(10), dp(4), dp(10), dp(4))
            setOnClickListener { locate() }
        }
        top.addView(search, LinearLayout.LayoutParams(0, wrapP, 1f))
        top.addView(searchBtn)
        top.addView(locBtn)
        root.addView(
            top,
            FrameLayout.LayoutParams(matchP, wrapP, Gravity.TOP).apply {
                setMargins(dp(12), dp(12), dp(12), 0)
            }
        )

        val credit = tv("© OpenStreetMap", 10f, p.sub).apply {
            setPadding(dp(6), dp(2), dp(6), dp(2))
            background = rounded(p.card, dp(6).toFloat())
            alpha = 0.85f
        }
        root.addView(
            credit,
            FrameLayout.LayoutParams(wrapP, wrapP, Gravity.TOP or Gravity.END).apply {
                setMargins(0, dp(72), dp(12), 0)
            }
        )

        // Нижняя панель
        val panel = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            val r = dp(22).toFloat()
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(p.card)
                cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
                setStroke(dp(1), p.stroke)
            }
            setPadding(dp(16), dp(8), dp(16), dp(14))
            elevation = dp(10).toFloat()
        }

        val handle = View(ctx).apply { background = rounded(p.stroke, dp(2).toFloat()) }
        panel.addView(handle, LinearLayout.LayoutParams(dp(40), dp(4)).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            bottomMargin = dp(8)
        })

        val header = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        zoneTitle = tv("", 17f, p.text, true)
        weatherText = tv("", 12f, p.sub)
        header.addView(zoneTitle, LinearLayout.LayoutParams(0, wrapP, 1f))
        header.addView(weatherText)
        panel.addView(header)

        for (t in Tariff.values()) {
            val row = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(2), 0, dp(2))
            }
            val sw = Switch(ctx).apply {
                text = t.title
                textSize = 15f
                setTextColor(p.text)
                isChecked = values.isOn(t)
            }
            val pct = tv("", 16f, p.sub, true).apply { gravity = Gravity.END }
            val wait = tv("", 13f, p.sub).apply { gravity = Gravity.END }
            sw.setOnCheckedChangeListener { _, on -> if (!updating) onTariffToggle(t, on) }
            row.addView(sw, LinearLayout.LayoutParams(0, wrapP, 1f))
            row.addView(pct, LinearLayout.LayoutParams(dp(62), wrapP))
            row.addView(wait, LinearLayout.LayoutParams(dp(78), wrapP))
            panel.addView(row)
            rowViews.add(TariffRowViews(t, sw, pct, wait))
        }

        labelText = tv("", 13f, p.sub).apply { setPadding(0, dp(6), 0, dp(2)) }
        panel.addView(labelText)

        hotText = tv("", 13f, p.accent, true).apply {
            setPadding(0, dp(2), 0, dp(8))
            setOnClickListener { hotZone?.let { z -> pin(z, true) } }
        }
        panel.addView(hotText)

        panel.addView(
            button("Обновить радар", true) { forceRefresh() },
            LinearLayout.LayoutParams(matchP, wrapP)
        )

        val bottomRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        overlayBtn = button("", false) { toggleOverlay() }
        val settingsBtn = button("⚙ Настройки", false) {
            startActivity(Intent(ctx, SettingsActivity::class.java))
        }
        bottomRow.addView(overlayBtn, LinearLayout.LayoutParams(0, wrapP, 1f).apply { rightMargin = dp(8) })
        bottomRow.addView(settingsBtn, LinearLayout.LayoutParams(0, wrapP, 1f))
        panel.addView(bottomRow, LinearLayout.LayoutParams(matchP, wrapP).apply { topMargin = dp(8) })

        root.addView(panel, FrameLayout.LayoutParams(matchP, wrapP, Gravity.BOTTOM))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        val v = WidgetSettings.load(this)
        if (v.dark != builtDark) {
            recreate()
            return
        }
        values = v
        map.onResume()
        updateOverlayButton()
        WeatherProvider.refreshAsync { refresh() }
        handler.removeCallbacks(ticker)
        handler.post(ticker)
        startPulse()
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        pulseAnim?.cancel()
        pulseAnim = null
        if (::map.isInitialized) map.onPause()
        runCatching {
            (getSystemService(LOCATION_SERVICE) as LocationManager).removeUpdates(locationListener)
        }
        super.onPause()
    }

    private fun startPulse() {
        pulseAnim?.cancel()
        pulseAnim = null
        if (!values.mapAnim) {
            heat.pulse = 1f
            return
        }
        pulseAnim = ValueAnimator.ofFloat(0.9f, 1.06f).apply {
            duration = 1700L
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            addUpdateListener {
                heat.pulse = it.animatedValue as Float
                map.invalidate()
            }
            start()
        }
    }

    private fun pinnedZone(): SurgeZone =
        MoscowRegionGrid.zones.firstOrNull { it.name == values.zone } ?: MoscowRegionGrid.zones.first()

    private fun refresh() {
        values = WidgetSettings.load(this)
        val tariffs = values.enabledTariffs()
        val zone = pinnedZone()
        val now = System.currentTimeMillis()

        val items = MoscowRegionGrid.zones.map { z ->
            HeatItem(z, DemandModel.maxPct(DemandModel.baseCoeff(z, now), tariffs))
        }
        heat.items = items
        heat.pinned = zone
        heat.glow = values.glow / 100f
        heat.myLocation = myLocation
        map.invalidate()

        zoneTitle.text = "📍 ${zone.name}"
        weatherText.text = WeatherProvider.summary()

        val base = DemandModel.baseCoeff(zone, now)
        updating = true
        for (r in rowViews) {
            val on = values.isOn(r.tariff)
            r.sw.isChecked = on
            val c = DemandModel.scale(base, r.tariff)
            val pct = DemandModel.pct(c)
            r.pct.text = if (on) "+$pct%" else "—"
            r.pct.setTextColor(if (on) DemandModel.textColor(pct) else p.sub)
            r.wait.text = if (on) "~${DemandModel.waitMinutes(c)} мин" else ""
        }
        updating = false

        val zonePct = DemandModel.maxPct(base, tariffs)
        val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(now))
        if (tariffs.isEmpty()) {
            labelText.text = "Включите хотя бы один тариф"
        } else {
            val next = DemandModel.maxPct(DemandModel.baseCoeff(zone, now + 30 * 60_000L, false), tariffs)
            val arrow = if (next - zonePct >= 8) " ↗" else if (zonePct - next >= 8) " ↘" else ""
            labelText.text = "${DemandModel.label(zonePct)}$arrow • через 30 мин +$next% • обновлено $time"
        }

        val top = items.maxByOrNull { it.pct }
        hotZone = top?.zone
        hotText.text = if (top != null && top.pct >= 10)
            "🔥 Горячее всего сейчас: ${top.zone.name} +${top.pct}%"
        else "Сейчас везде спокойно"
    }

    private fun forceRefresh() {
        WeatherProvider.refreshAsync(true) { refresh() }
        refresh()
        SurgeWidgetProvider.refreshAll(this)
        Toast.makeText(this, "Радар обновлён", Toast.LENGTH_SHORT).show()
    }

    private fun onTariffToggle(t: Tariff, on: Boolean) {
        val mask = if (on) values.tariffMask or t.bit else values.tariffMask and t.bit.inv()
        WidgetSettings.setMask(this, mask)
        refresh()
        SurgeWidgetProvider.refreshAll(this)
    }

    private fun pin(z: SurgeZone, animate: Boolean) {
        WidgetSettings.setZone(this, z.name)
        refresh()
        SurgeWidgetProvider.refreshAll(this)
        if (animate) map.controller.animateTo(GeoPoint(z.lat, z.lon))
    }

    // ----- Поиск -----

    private fun doSearch(q: String) {
        val query = q.trim()
        if (query.isEmpty()) return
        val local = MoscowRegionGrid.byText(query)
        if (local != null) {
            pin(local, true)
            map.controller.setZoom(12.0)
            return
        }
        Thread {
            var lat = 0.0
            var lon = 0.0
            var ok = false
            try {
                if (Geocoder.isPresent()) {
                    @Suppress("DEPRECATION")
                    val res = Geocoder(this, Locale("ru", "RU")).getFromLocationName("Москва, $query", 1)
                    if (!res.isNullOrEmpty()) {
                        lat = res[0].latitude
                        lon = res[0].longitude
                        ok = true
                    }
                }
            } catch (e: Exception) {
                ok = false
            }
            val found = ok
            val fLat = lat
            val fLon = lon
            runOnUiThread {
                if (found) {
                    pin(MoscowRegionGrid.nearest(fLat, fLon), false)
                    map.controller.animateTo(GeoPoint(fLat, fLon))
                    map.controller.setZoom(13.0)
                } else {
                    Toast.makeText(this, "Адрес не найден. Попробуйте название района.", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    // ----- Местоположение -----

    private fun hasLocationPermission(): Boolean =
        checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun locate() {
        if (!hasLocationPermission()) {
            requestPermissions(
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION),
                21
            )
            return
        }
        startLocation()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 21 && grantResults.any { it == PackageManager.PERMISSION_GRANTED }) startLocation()
    }

    private fun startLocation() {
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        val providers = runCatching { lm.getProviders(true) }.getOrDefault(emptyList())
        if (providers.isEmpty()) {
            Toast.makeText(this, "Включите геолокацию в настройках телефона", Toast.LENGTH_LONG).show()
            return
        }
        var best: Location? = null
        for (name in providers) {
            val l = runCatching { lm.getLastKnownLocation(name) }.getOrNull()
            if (l != null && (best == null || l.time > best.time)) best = l
        }
        best?.let { onLocation(it) }
        for (name in providers) {
            runCatching {
                @Suppress("DEPRECATION")
                lm.requestSingleUpdate(name, locationListener, Looper.getMainLooper())
            }
        }
    }

    private fun onLocation(loc: Location) {
        val gp = GeoPoint(loc.latitude, loc.longitude)
        myLocation = gp
        pin(MoscowRegionGrid.nearest(loc.latitude, loc.longitude), false)
        map.controller.animateTo(gp)
        map.controller.setZoom(12.0)
    }

    // ----- Виджет поверх экрана -----

    private fun updateOverlayButton() {
        val on = WidgetSettings.load(this).overlayOn
        overlayBtn.text = if (on) "Виджет: ВКЛ" else "Виджет: ВЫКЛ"
        overlayBtn.setTextColor(if (on) p.accent else p.text)
    }

    private fun toggleOverlay() {
        val on = WidgetSettings.load(this).overlayOn
        if (on) {
            stopService(Intent(this, OverlayWidgetService::class.java))
            WidgetSettings.setOverlayOn(this, false)
        } else {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Разрешите показ поверх других приложений", Toast.LENGTH_LONG).show()
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
                return
            }
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 22)
            }
            WidgetSettings.setOverlayOn(this, true)
            OverlayWidgetService.start(this)
        }
        updateOverlayButton()
    }
}
