package com.surge.radar

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Мероприятия, которые вы добавили сами: площадка, время начала и длительность. Устаревшие удаляются. */
object ManualEvents {
    class Item(val id: Long, val venue: String, val startMs: Long, val endMs: Long)

    private const val PREFS = "manual_events"
    private const val DAY = 86_400_000L
    private const val MSK = 3 * 3_600_000L

    private fun prefs(c: Context) = c.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun save(c: Context, items: List<Item>) {
        val arr = JSONArray()
        for (i in items) {
            arr.put(JSONObject().put("id", i.id).put("v", i.venue).put("s", i.startMs).put("e", i.endMs))
        }
        prefs(c).edit().putString("items", arr.toString()).apply()
    }

    fun list(c: Context): List<Item> {
        val now = System.currentTimeMillis()
        val out = ArrayList<Item>()
        val arr = runCatching { JSONArray(prefs(c).getString("items", "[]")) }.getOrNull() ?: return out
        for (k in 0 until arr.length()) {
            val o = arr.optJSONObject(k) ?: continue
            val item = Item(o.optLong("id"), o.optString("v"), o.optLong("s"), o.optLong("e"))
            if (item.endMs + 3_600_000L > now) out.add(item)
        }
        if (out.size != arr.length()) save(c, out)
        return out.sortedBy { it.startMs }
    }

    /** Время вводится по Москве. Если оно уже прошло больше чем на 3 часа, берём завтра. */
    fun add(c: Context, venue: String, hour: Int, minute: Int, durationMin: Int) {
        val now = System.currentTimeMillis()
        val dayStart = Math.floorDiv(now + MSK, DAY) * DAY - MSK
        var start = dayStart + (hour * 60L + minute) * 60_000L
        if (start < now - 3 * 3_600_000L) start += DAY
        val items = list(c).toMutableList()
        items.add(Item(now, venue, start, start + durationMin * 60_000L))
        save(c, items)
    }

    fun remove(c: Context, id: Long) {
        save(c, list(c).filter { it.id != id })
    }

    /** В виде событий афиши, чтобы считать их так же. */
    fun infos(c: Context): List<EventInfo> = list(c).mapNotNull { i ->
        val poi = PoiCatalog.fixed.firstOrNull { it.name == i.venue } ?: return@mapNotNull null
        EventInfo("Мероприятие", i.startMs, i.endMs, poi.name, poi.lat, poi.lon)
    }
}
