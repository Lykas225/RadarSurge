package com.surge.radar

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.annotation.SuppressLint
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.net.URLEncoder
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

/** Афиша в визуальном стиле расписания: карточки, выбор даты и временного окна. */
class EventsActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private lateinit var progressBar: ProgressBar
    private lateinit var status: TextView
    private lateinit var dateButton: TextView
    private lateinit var startButton: TextView
    private lateinit var endButton: TextView
    private lateinit var sourceRow: LinearLayout
    private lateinit var categoryRow: LinearLayout
    private var source = 0
    private var category = "Все события"
    private var selectedDate = LocalDate.now()
    private var startTime = "00:00"
    private var endTime = "23:59"
    private val sources = listOf(
        "Яндекс Афиша" to "https://afisha.yandex.ru/moscow/events",
        "Timepad" to "https://afisha.timepad.ru/moscow",
        "Afisha.ru" to "https://www.afisha.ru/msk/events/"
    )
    private val categories = listOf("Все события", "Концерты", "Театр", "Выставки", "Фестивали", "Спорт", "Стендап", "Детям", "Экскурсии", "Бесплатно")
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun text(s: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD)
    }
    private fun rounded(color: Int, stroke: Int = Color.TRANSPARENT) = GradientDrawable().apply {
        cornerRadius = dp(15).toFloat(); setColor(color); if (stroke != Color.TRANSPARENT) setStroke(dp(1), stroke)
    }
    private fun pill(label: String, selected: Boolean, onClick: () -> Unit): TextView = text(label, 12.5f, if (selected) Color.WHITE else Color.rgb(205,218,228), selected).apply {
        gravity = Gravity.CENTER; setPadding(dp(12), dp(9), dp(12), dp(9))
        background = rounded(if (selected) Color.rgb(25,135,115) else Color.rgb(35,48,61), if (selected) Color.rgb(50,180,150) else Color.rgb(54,70,82))
        setOnClickListener { onClick() }
    }
    private fun addButtonRow(parent: LinearLayout, labels: List<String>, selected: String, action: (String) -> Unit) {
        parent.removeAllViews()
        labels.forEach { label -> parent.addView(pill(label, label == selected) { action(label) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(6) }) }
    }
    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; background = rounded(Color.rgb(25,36,47), Color.rgb(45,62,74)); setPadding(dp(12), dp(12), dp(12), dp(12))
    }
    private fun fieldButton(label: String): TextView = text(label, 14f, Color.WHITE, true).apply {
        gravity = Gravity.CENTER; setPadding(dp(12), dp(12), dp(12), dp(12)); background = rounded(Color.rgb(35,48,61), Color.rgb(54,70,82))
    }
    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(15,23,31)); setPadding(dp(16), dp(14), dp(16), dp(12)) }
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; orientation = LinearLayout.HORIZONTAL }
        top.addView(text("‹ Назад", 15f, Color.rgb(80,210,175), true).apply { setPadding(0, dp(8), dp(14), dp(8)); setOnClickListener { finish() } })
        top.addView(text("Афиша мероприятий", 21f, Color.WHITE, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        top.addView(text("↻", 20f, Color.rgb(80,210,175), true).apply { setPadding(dp(12), dp(4), dp(4), dp(4)); setOnClickListener { loadSearch() } })
        root.addView(top)
        status = text("Мероприятия Москвы · выберите дату и время", 12f, Color.rgb(160,180,194)).apply { setPadding(0, dp(4), 0, dp(10)) }
        root.addView(status)
        sourceRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val srcScroll = horizontal(sourceRow)
        root.addView(srcScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(8) })
        categoryRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        root.addView(horizontal(categoryRow), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(8) })
        val filter = card()
        filter.addView(text("Дата мероприятия", 14f, Color.rgb(220,232,240), true))
        dateButton = fieldButton("")
        dateButton.setOnClickListener { DatePickerDialog(this, { _, y, m, d -> selectedDate = LocalDate.of(y, m + 1, d); updateDateLabel(); loadSearch() }, selectedDate.year, selectedDate.monthValue - 1, selectedDate.dayOfMonth).show() }
        filter.addView(dateButton, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(7) })
        val times = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        startButton = fieldButton("Начало: $startTime")
        endButton = fieldButton("Конец: $endTime")
        startButton.setOnClickListener { pickTime(true) }; endButton.setOnClickListener { pickTime(false) }
        times.addView(startButton, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(6) })
        times.addView(endButton, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        filter.addView(times, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(7) })
        val search = fieldButton("Найти мероприятия")
        search.background = rounded(Color.rgb(25,135,115), Color.rgb(50,180,150)); search.setOnClickListener { loadSearch() }
        filter.addView(search, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) })
        root.addView(filter, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(8) })
        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { visibility = View.GONE; max = 100 }
        root.addView(progressBar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3)))
        web = WebView(this).apply {
            settings.javaScriptEnabled = true; settings.domStorageEnabled = true; settings.loadsImagesAutomatically = true
            settings.userAgentString = "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/122 Mobile Safari/537.36"
            webViewClient = object : WebViewClient() { override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                val uri = runCatching { Uri.parse(url ?: "") }.getOrNull() ?: return true
                return uri.scheme != "https" && uri.scheme != "http"
            } }
            webChromeClient = object : WebChromeClient() { override fun onProgressChanged(view: WebView?, newProgress: Int) { progressBar.progress = newProgress; progressBar.visibility = if (newProgress >= 100) View.GONE else View.VISIBLE } }
        }
        root.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        updateDateLabel(); renderFilters(); loadSearch()
    }
    private fun horizontal(child: LinearLayout): android.widget.HorizontalScrollView = android.widget.HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(child) }
    private fun updateDateLabel() { dateButton.text = selectedDate.format(DateTimeFormatter.ofPattern("EEEE, dd MMMM yyyy", Locale("ru"))).replaceFirstChar { it.uppercase() } }
    private fun pickTime(isStart: Boolean) {
        val current = if (isStart) startTime else endTime
        val parts = current.split(":"); val h = parts.getOrNull(0)?.toIntOrNull() ?: 0; val m = parts.getOrNull(1)?.toIntOrNull() ?: 0
        TimePickerDialog(this, { _, hour, minute ->
            val value = String.format(Locale.getDefault(), "%02d:%02d", hour, minute)
            if (isStart) startTime = value else endTime = value
            startButton.text = "Начало: $startTime"; endButton.text = "Конец: $endTime"
            loadSearch()
        }, h, m, true).show()
    }
    private fun renderFilters() {
        addButtonRow(sourceRow, sources.map { it.first }, sources[source].first) { label -> source = sources.indexOfFirst { it.first == label }.coerceAtLeast(0); renderFilters(); loadSearch() }
        addButtonRow(categoryRow, categories, category) { category = it; renderFilters(); loadSearch() }
    }
    private fun loadSearch() {
        val date = selectedDate.format(DateTimeFormatter.ofPattern("dd.MM.yyyy"))
        status.text = "${sources[source].first} · $category · $date · $startTime–$endTime"
        val query = listOf(category.takeIf { it != "Все события" }, date, "мероприятия Москва", "начало $startTime", "до $endTime", sources[source].first).filterNotNull().joinToString(" ")
        val url = "https://www.google.com/search?q=" + URLEncoder.encode(query, "UTF-8")
        web.loadUrl(if (category == "Все события" && selectedDate == LocalDate.now() && startTime == "00:00" && endTime == "23:59") sources[source].second else url)
    }
    @Suppress("DEPRECATION")
    override fun onBackPressed() { if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed() }
}
