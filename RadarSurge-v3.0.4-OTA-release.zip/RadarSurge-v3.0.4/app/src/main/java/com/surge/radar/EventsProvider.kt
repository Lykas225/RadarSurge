package com.surge.radar

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.OffsetDateTime
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

data class LiveEvent(
    val id: String,
    val title: String,
    val venue: String,
    val address: String,
    val startMs: Long,
    val dateIso: String,
    val timeLabel: String,
    val hasExactTime: Boolean,
    val catKey: String,
    val catIcon: String,
    val accentColor: Int,
    val siteUrl: String
)

/**
 * Живые мероприятия Москвы из нескольких независимых источников без ключей:
 * 1) ESPN Public Scoreboard API (матчи РПЛ на стадионах Москвы — работает всегда, даже при VPN),
 * 2) Публичные страницы афиш с микроразметкой Schema.org JSON-LD (Timepad / Afisha.ru / KudaGo),
 * 3) KudaGo Public JSON API,
 * 4) Прямой импорт из реального движка Chromium WebView (обходит TLS/WAF 403).
 */
object EventsProvider {
    private const val PREFS = "events_cache_v3"
    private const val CACHE_TTL_MS = 30 * 60_000L
    private const val BROWSER_UA =
        "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"
    private val MSK = ZoneId.of("Europe/Moscow")
    private val mainHandler = Handler(Looper.getMainLooper())
    private val loading = AtomicBoolean(false)

    private val ldJsonScriptRegex = Regex(
        "<script[^>]*type=[\"']application/ld\\+json[\"'][^>]*>([\\s\\S]*?)</script>",
        RegexOption.IGNORE_CASE
    )

    val categories: List<Pair<String, String>> = listOf(
        "all" to "Все",
        "concert" to "🎵 Концерты",
        "sport" to "⚽ Спорт",
        "theater" to "🎭 Театр",
        "stand-up" to "🎤 Стендап",
        "festival" to "🎪 Фестивали",
        "show" to "✨ Шоу",
        "exhibition" to "🖼 Выставки"
    )

    private val moscowFootballVenues = mapOf(
        "cska" to Pair("ВЭБ Арена (ЦСКА)", "Москва, 3-я Песчаная ул., 2А"),
        "spartak" to Pair("Лукойл Арена (Спартак)", "Москва, Волоколамское ш., 69"),
        "dynamo moscow" to Pair("ВТБ Арена (Динамо)", "Москва, Ленинградский пр-т, 36"),
        "dinamo moscow" to Pair("ВТБ Арена (Динамо)", "Москва, Ленинградский пр-т, 36"),
        "lokomotiv" to Pair("РЖД Арена (Локомотив)", "Москва, Большая Черкизовская ул., 125"),
        "torpedo" to Pair("Стадион Лужники", "Москва, ул. Лужники, 24"),
        "khimki" to Pair("Арена Химки", "МО, Химки, ул. Кирова, 24")
    )

    private val rplRuNames = listOf(
        "cska" to "ЦСКА",
        "spartak" to "Спартак",
        "dynamo moscow" to "Динамо Москва",
        "dinamo moscow" to "Динамо Москва",
        "lokomotiv" to "Локомотив",
        "zenit" to "Зенит",
        "krasnodar" to "Краснодар",
        "rostov" to "Ростов",
        "rubin" to "Рубин",
        "akhmat" to "Ахмат",
        "krylya" to "Крылья Советов",
        "fakel" to "Факел",
        "khimki" to "Химки",
        "orenburg" to "Оренбург",
        "pari nn" to "Пари НН",
        "nizhny" to "Пари НН",
        "akron" to "Акрон",
        "makhachkala" to "Динамо Мх",
        "torpedo" to "Торпедо",
        "baltika" to "Балтика",
        "sochi" to "Сочи",
        "ural" to "Урал"
    )

    private fun prefs(c: Context) = c.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun isVpnActive(c: Context): Boolean = runCatching {
        val cm = c.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val net = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(net) ?: return false
        caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)
    }.getOrDefault(false)

    fun kudaGoUrl(): String {
        val nowSec = System.currentTimeMillis() / 1000L
        val startOfToday = LocalDate.now(MSK).atStartOfDay(MSK).toEpochSecond()
        val endWindow = LocalDate.now(MSK).plusDays(7).atStartOfDay(MSK).toEpochSecond()
        val since = maxOf(startOfToday, nowSec - 3 * 3600L)
        return "https://kudago.com/public-api/v1.4/events/" +
            "?location=msk&actual_since=$since&actual_until=$endWindow" +
            "&expand=place,dates&fields=id,title,dates,place,categories,site_url" +
            "&page_size=80&order_by=dates"
    }

    fun cached(c: Context): List<LiveEvent> {
        val raw = prefs(c).getString("events_json", null) ?: return emptyList()
        return runCatching { deserialize(raw) }.getOrDefault(emptyList())
    }

    fun statusLine(c: Context): String {
        val p = prefs(c)
        val at = p.getLong("at", 0L)
        val src = p.getString("src", "") ?: ""
        val err = p.getString("err", "") ?: ""
        if (at <= 0L) return if (err.isBlank()) "Загрузка афиши Москвы…" else err
        val time = DemandModel.mskTime(at)
        val count = cached(c).size
        val srcSuffix = if (src.isNotBlank()) " · $src" else ""
        return if (count > 0) "Афиша Москвы$srcSuffix · $time ($count)" else (if (err.isNotBlank()) err else "Обновлено в $time")
    }

    fun refreshAsync(
        c: Context,
        force: Boolean = false,
        onDone: (List<LiveEvent>, String?, Boolean) -> Unit
    ) {
        val app = c.applicationContext
        val p = prefs(app)
        val cachedList = cached(app)
        val age = System.currentTimeMillis() - p.getLong("at", 0L)
        if (!force && cachedList.isNotEmpty() && age < CACHE_TTL_MS) {
            mainHandler.post { onDone(cachedList, null, false) }
            return
        }
        if (!loading.compareAndSet(false, true)) return

        Thread {
            try {
                val merged = ArrayList<LiveEvent>(120)
                val sources = ArrayList<String>(4)
                val errors = ArrayList<String>(4)
                var gotGeneralEvents = false

                // 1. KudaGo Public API
                runCatching { parseKudaGo(httpGet(kudaGoUrl(), "https://kudago.com/msk/events/")) }
                    .onSuccess { list ->
                        if (list.isNotEmpty()) {
                            merged.addAll(list)
                            sources.add("KudaGo")
                            gotGeneralEvents = true
                        }
                    }
                    .onFailure { e -> errors.add("KudaGo: ${e.message ?: "ошибка"}") }

                // 2. Публичная веб-страница Timepad (JSON-LD микроразметка, без токена)
                if (!gotGeneralEvents) {
                    runCatching {
                        val html = httpGet("https://afisha.timepad.ru/moscow", "https://afisha.timepad.ru/")
                        parseJsonLdEvents(html, "tpw")
                    }.onSuccess { list ->
                        if (list.isNotEmpty()) {
                            merged.addAll(list)
                            sources.add("Timepad")
                            gotGeneralEvents = true
                        }
                    }.onFailure { e -> errors.add("Timepad: ${e.message ?: "ошибка"}") }
                }

                // 3. Публичная веб-страница Afisha.ru (JSON-LD микроразметка)
                if (!gotGeneralEvents) {
                    runCatching {
                        val html = httpGet("https://www.afisha.ru/msk/events/", "https://www.afisha.ru/")
                        parseJsonLdEvents(html, "afr")
                    }.onSuccess { list ->
                        if (list.isNotEmpty()) {
                            merged.addAll(list)
                            sources.add("Afisha.ru")
                            gotGeneralEvents = true
                        }
                    }.onFailure { e -> errors.add("Afisha: ${e.message ?: "ошибка"}") }
                }

                // 4. ESPN Public API — матчи РПЛ на стадионах Москвы (работает даже при VPN)
                runCatching { fetchMoscowRplMatches() }
                    .onSuccess { list ->
                        if (list.isNotEmpty()) {
                            merged.addAll(list)
                            sources.add("РПЛ")
                        }
                    }
                    .onFailure { /* необязательный источник */ }

                val finalEvents = dedupAndSort(merged)
                if (finalEvents.isNotEmpty()) {
                    val srcLabel = sources.joinToString(" + ")
                    saveEvents(app, finalEvents, srcLabel, "")
                    mainHandler.post { onDone(finalEvents, null, !gotGeneralEvents) }
                } else {
                    val vpnNote = if (isVpnActive(app)) {
                        " Включён VPN — российские афиши часто блокируют зарубежные IP (403)."
                    } else ""
                    val errMsg = "Прямой запрос заблокирован (${errors.joinToString("; ")}).$vpnNote"
                    p.edit().putString("err", errMsg).apply()
                    val fallback = cached(app)
                    mainHandler.post { onDone(fallback, errMsg, true) }
                }
            } catch (e: Exception) {
                val msg = e.message ?: "Не удалось загрузить афишу"
                p.edit().putString("err", msg).apply()
                mainHandler.post { onDone(cached(app), msg, true) }
            } finally {
                loading.set(false)
            }
        }.start()
    }

    /** Принимает JSON (KudaGo API) или массив JSON-LD блоков, извлечённых из реального WebView. */
    fun ingestFromWebView(
        c: Context,
        sourceName: String,
        kudaGoJson: String?,
        jsonLdArrayJson: String?,
        domCardsJson: String?
    ): List<LiveEvent> {
        val parsed = ArrayList<LiveEvent>(80)
        if (!kudaGoJson.isNullOrBlank() && kudaGoJson.trim().startsWith("{")) {
            runCatching { parsed.addAll(parseKudaGo(kudaGoJson)) }
        }
        if (!jsonLdArrayJson.isNullOrBlank() && jsonLdArrayJson.trim().startsWith("[")) {
            runCatching {
                val arr = JSONArray(jsonLdArrayJson)
                for (i in 0 until arr.length()) {
                    val block = arr.optString(i, "")
                    if (block.isNotBlank()) collectJsonLdBlock(block, "wv", parsed)
                }
            }
        }
        if (parsed.isEmpty() && !domCardsJson.isNullOrBlank() && domCardsJson.trim().startsWith("[")) {
            runCatching { parsed.addAll(parseDomCards(domCardsJson)) }
        }
        if (parsed.isEmpty()) return emptyList()

        val combined = dedupAndSort(cached(c) + parsed)
        saveEvents(c, combined, sourceName, "")
        return combined
    }

    private fun saveEvents(c: Context, list: List<LiveEvent>, src: String, err: String) {
        prefs(c).edit()
            .putString("events_json", serialize(list))
            .putString("src", src)
            .putLong("at", System.currentTimeMillis())
            .putString("err", err)
            .apply()
    }

    private fun httpGet(urlStr: String, referer: String? = null): String {
        var current = urlStr
        for (hop in 0 until 5) {
            val conn = (URL(current).openConnection() as HttpURLConnection).apply {
                instanceFollowRedirects = false
                connectTimeout = 7_000
                readTimeout = 8_000
                setRequestProperty("User-Agent", BROWSER_UA)
                setRequestProperty("Accept", "application/json, text/html;q=0.9, */*;q=0.8")
                setRequestProperty("Accept-Language", "ru-RU,ru;q=0.9,en-US;q=0.5")
                if (!referer.isNullOrBlank()) setRequestProperty("Referer", referer)
            }
            val code = conn.responseCode
            if (code == 301 || code == 302 || code == 303 || code == 307 || code == 308) {
                val loc = conn.getHeaderField("Location")
                conn.disconnect()
                if (loc.isNullOrBlank()) throw IllegalStateException("HTTP $code")
                current = URL(URL(current), loc).toString()
                continue
            }
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            conn.disconnect()
            if (code !in 200..299) throw IllegalStateException("HTTP $code")
            return body
        }
        throw IllegalStateException("редирект")
    }

    private fun fetchMoscowRplMatches(): List<LiveEvent> {
        val today = LocalDate.now(MSK)
        val fmt = DateTimeFormatter.BASIC_ISO_DATE
        val datesParam = "${today.format(fmt)}-${today.plusDays(14).format(fmt)}"
        val url = "https://site.api.espn.com/apis/site/v2/sports/soccer/rus.1/scoreboard?dates=$datesParam"
        val body = httpGet(url)
        val events = JSONObject(body).optJSONArray("events") ?: return emptyList()
        val nowMs = System.currentTimeMillis()
        val out = ArrayList<LiveEvent>()

        for (i in 0 until events.length()) {
            val ev = events.optJSONObject(i) ?: continue
            val comps = ev.optJSONArray("competitions") ?: continue
            val comp = comps.optJSONObject(0) ?: continue
            val competitors = comp.optJSONArray("competitors") ?: continue

            var homeEn = ""
            var awayEn = ""
            for (cIdx in 0 until competitors.length()) {
                val c = competitors.optJSONObject(cIdx) ?: continue
                val tName = c.optJSONObject("team")?.optString("displayName", "")?.trim().orEmpty()
                if (c.optString("homeAway") == "home") homeEn = tName else awayEn = tName
            }
            if (homeEn.isBlank() || awayEn.isBlank()) continue

            val homeLow = homeEn.lowercase()
            val venueEntry = moscowFootballVenues.entries.firstOrNull { homeLow.contains(it.key) } ?: continue

            val dateStr = ev.optString("date", "")
            val zdt = parseAnyDateToMsk(dateStr) ?: continue
            val startMs = zdt.toInstant().toEpochMilli()
            if (startMs < nowMs - 3 * 3_600_000L) continue

            val homeRu = toRussianClub(homeEn)
            val awayRu = toRussianClub(awayEn)
            val exact = !(zdt.hour == 0 && zdt.minute == 0)
            val timeLabel = if (exact) String.format(Locale.US, "%02d:%02d", zdt.hour, zdt.minute) else "уточн."

            out.add(
                LiveEvent(
                    id = "rpl_" + ev.optString("id", i.toString()),
                    title = "$homeRu — $awayRu",
                    venue = venueEntry.value.first,
                    address = venueEntry.value.second,
                    startMs = startMs,
                    dateIso = zdt.toLocalDate().toString(),
                    timeLabel = timeLabel,
                    hasExactTime = exact,
                    catKey = "sport",
                    catIcon = "⚽",
                    accentColor = 0xFF5C9CE6.toInt(),
                    siteUrl = "https://premierliga.ru/"
                )
            )
        }
        return out
    }

    private fun toRussianClub(enName: String): String {
        val low = enName.lowercase()
        return rplRuNames.firstOrNull { low.contains(it.first) }?.second ?: enName
    }

    private fun parseJsonLdEvents(html: String, prefix: String): List<LiveEvent> {
        val out = ArrayList<LiveEvent>()
        for (m in ldJsonScriptRegex.findAll(html)) {
            val raw = m.groupValues[1].trim()
            if (raw.isNotBlank()) collectJsonLdBlock(raw, prefix, out)
        }
        return out
    }

    private fun collectJsonLdBlock(raw: String, prefix: String, out: MutableList<LiveEvent>) {
        val trimmed = raw.trim()
        runCatching {
            when {
                trimmed.startsWith("[") -> {
                    val arr = JSONArray(trimmed)
                    for (i in 0 until arr.length()) {
                        arr.optJSONObject(i)?.let { extractLdObject(it, prefix, out) }
                    }
                }
                trimmed.startsWith("{") -> {
                    extractLdObject(JSONObject(trimmed), prefix, out)
                }
            }
        }
    }

    private fun extractLdObject(obj: JSONObject, prefix: String, out: MutableList<LiveEvent>) {
        val graph = obj.optJSONArray("@graph")
        if (graph != null) {
            for (i in 0 until graph.length()) {
                graph.optJSONObject(i)?.let { extractLdObject(it, prefix, out) }
            }
        }
        val itemList = obj.optJSONArray("itemListElement")
        if (itemList != null) {
            for (i in 0 until itemList.length()) {
                val el = itemList.optJSONObject(i) ?: continue
                val inner = el.optJSONObject("item") ?: el
                extractLdObject(inner, prefix, out)
            }
        }
        val typeStr = obj.optString("@type", "").lowercase()
        if (!typeStr.contains("event")) return

        val title = decodeHtml(obj.optString("name", "")).trim()
            .replaceFirstChar { if (it.isLowerCase()) it.uppercase() else it.toString() }
        if (title.length < 3) return

        val zdt = parseAnyDateToMsk(obj.optString("startDate", "")) ?: return
        val today = LocalDate.now(MSK)
        val ld = zdt.toLocalDate()
        if (ld.isBefore(today) || ld.isAfter(today.plusDays(14))) return

        var venue = ""
        var rawAddr = ""
        val locObj = obj.optJSONObject("location")
        if (locObj != null) {
            venue = decodeHtml(locObj.optString("name", "")).trim()
            val addrObj = locObj.optJSONObject("address")
            rawAddr = if (addrObj != null) {
                decodeHtml(addrObj.optString("streetAddress", "")).trim()
                    .ifBlank { decodeHtml(addrObj.optString("addressLocality", "")).trim() }
            } else {
                decodeHtml(locObj.optString("address", "")).trim()
            }
        }
        if (isOnlineAddress(rawAddr) || isOnlineAddress(venue)) return
        val address = formatMoscowAddress(rawAddr, venue)
        if (venue.isBlank() && address.isBlank()) return

        val (catKey, catIcon, accentColor) = classifyEvent(title, venue, listOf(typeStr))
        val exact = !(zdt.hour == 0 && zdt.minute == 0)
        val timeLabel = if (exact) String.format(Locale.US, "%02d:%02d", zdt.hour, zdt.minute) else "уточн."

        out.add(
            LiveEvent(
                id = "${prefix}_${title.hashCode()}_${ld}",
                title = title,
                venue = venue.ifBlank { "Площадка в Москве" },
                address = address,
                startMs = zdt.toInstant().toEpochMilli(),
                dateIso = ld.toString(),
                timeLabel = timeLabel,
                hasExactTime = exact,
                catKey = catKey,
                catIcon = catIcon,
                accentColor = accentColor,
                siteUrl = obj.optString("url", "")
            )
        )
    }

    private fun parseDomCards(rawJson: String): List<LiveEvent> {
        val arr = JSONArray(rawJson)
        val today = LocalDate.now(MSK)
        val out = ArrayList<LiveEvent>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val title = decodeHtml(o.optString("title", "")).trim()
            if (title.length < 3) continue
            val venue = decodeHtml(o.optString("venue", "")).trim()
            val addr = decodeHtml(o.optString("address", "")).trim()
            val url = o.optString("url", "")
            val timeRaw = o.optString("time", "").trim()
            val timeMatch = Regex("(\\d{1,2}:\\d{2})").find(timeRaw)
            val exact = timeMatch != null
            val timeLabel = timeMatch?.groupValues?.get(1) ?: "уточн."
            val (catKey, catIcon, accentColor) = classifyEvent(title, venue, emptyList())
            out.add(
                LiveEvent(
                    id = "dom_${i}_${title.hashCode()}",
                    title = title,
                    venue = venue.ifBlank { "Площадка в Москве" },
                    address = formatMoscowAddress(addr, venue),
                    startMs = System.currentTimeMillis() + i * 1000L,
                    dateIso = today.toString(),
                    timeLabel = timeLabel,
                    hasExactTime = exact,
                    catKey = catKey,
                    catIcon = catIcon,
                    accentColor = accentColor,
                    siteUrl = url
                )
            )
        }
        return out
    }

    private fun parseKudaGo(rawJson: String): List<LiveEvent> {
        val root = JSONObject(rawJson)
        val results = root.optJSONArray("results") ?: return emptyList()
        val today = LocalDate.now(MSK)
        val todayStartSec = today.atStartOfDay(MSK).toEpochSecond()
        val maxEndSec = today.plusDays(7).atStartOfDay(MSK).toEpochSecond()
        val nowSec = System.currentTimeMillis() / 1000L
        val out = ArrayList<LiveEvent>(results.length())

        for (i in 0 until results.length()) {
            val item = results.optJSONObject(i) ?: continue
            val id = "kg_" + item.optInt("id", i)
            val title = decodeHtml(item.optString("title", "")).trim()
                .replaceFirstChar { if (it.isLowerCase()) it.uppercase() else it.toString() }
            if (title.isBlank()) continue
            val siteUrl = item.optString("site_url", "")

            val place = item.optJSONObject("place")
            val venue = decodeHtml(place?.optString("title", "").orEmpty()).trim()
                .replaceFirstChar { if (it.isLowerCase()) it.uppercase() else it.toString() }
            val rawAddr = decodeHtml(place?.optString("address", "").orEmpty()).trim()
            val address = formatMoscowAddress(rawAddr, venue)
            if (venue.isBlank() && address.isBlank()) continue

            val catNames = ArrayList<String>()
            val catsArr = item.optJSONArray("categories")
            if (catsArr != null) {
                for (cIdx in 0 until catsArr.length()) catNames.add(catsArr.optString(cIdx, ""))
            }
            val (catKey, catIcon, accentColor) = classifyEvent(title, venue, catNames)

            val datesArr = item.optJSONArray("dates") ?: continue
            val slot = pickUpcomingSlot(datesArr, todayStartSec, maxEndSec, nowSec) ?: continue
            val startSec = slot.first
            val exact = slot.second

            val zdt = ZonedDateTime.ofInstant(Instant.ofEpochSecond(startSec), MSK)
            val dateIso = zdt.toLocalDate().toString()
            val timeLabel = if (exact) String.format(Locale.US, "%02d:%02d", zdt.hour, zdt.minute) else "уточн."

            out.add(
                LiveEvent(
                    id = id,
                    title = title,
                    venue = venue.ifBlank { "Площадка в Москве" },
                    address = address,
                    startMs = startSec * 1000L,
                    dateIso = dateIso,
                    timeLabel = timeLabel,
                    hasExactTime = exact,
                    catKey = catKey,
                    catIcon = catIcon,
                    accentColor = accentColor,
                    siteUrl = siteUrl
                )
            )
        }
        return out
    }

    private fun parseAnyDateToMsk(raw: String): ZonedDateTime? {
        val s = raw.trim()
        if (s.isBlank()) return null
        val norm = s.replace(Regex("([+-]\\d{2})(\\d{2})$"), "$1:$2")
        return runCatching { OffsetDateTime.parse(norm).atZoneSameInstant(MSK) }.getOrNull()
            ?: runCatching { Instant.parse(norm).atZone(MSK) }.getOrNull()
            ?: runCatching { LocalDateTime.parse(norm).atZone(MSK) }.getOrNull()
            ?: runCatching { LocalDate.parse(norm.take(10)).atStartOfDay(MSK) }.getOrNull()
    }

    private fun isOnlineAddress(addr: String): Boolean {
        val low = addr.lowercase()
        return low.contains("онлайн") || low.contains("online") ||
            low.contains("zoom") || low.contains("вебинар") ||
            low.startsWith("http://") || low.startsWith("https://")
    }

    private fun decodeHtml(s: String): String =
        s.replace("&quot;", "\"")
            .replace("&laquo;", "«")
            .replace("&raquo;", "»")
            .replace("&nbsp;", " ")
            .replace("&amp;", "&")
            .replace("&#39;", "'")
            .replace("&mdash;", "—")
            .replace("&ndash;", "–")
            .replace(Regex("\\s+"), " ")

    private fun pickUpcomingSlot(
        dates: JSONArray,
        todayStartSec: Long,
        maxEndSec: Long,
        nowSec: Long
    ): Pair<Long, Boolean>? {
        var bestExact: Long? = null
        var ongoingToday = false

        for (i in 0 until dates.length()) {
            val d = dates.optJSONObject(i) ?: continue
            val start = d.optLong("start", -1L)
            val end = d.optLong("end", -1L)
            if (start in todayStartSec until maxEndSec) {
                if (end in 1 until (nowSec - 3600L)) continue
                val z = ZonedDateTime.ofInstant(Instant.ofEpochSecond(start), MSK)
                val isMidnight = (z.hour == 0 && z.minute == 0)
                if (!isMidnight) {
                    if (bestExact == null || start < bestExact) bestExact = start
                } else if (bestExact == null) {
                    return start to false
                }
            } else if (start in 1 until todayStartSec && (end >= nowSec || end <= 0L)) {
                ongoingToday = true
            }
        }
        if (bestExact != null) return bestExact to true
        if (ongoingToday) return todayStartSec to false
        return null
    }

    private fun formatMoscowAddress(rawAddr: String, venue: String): String {
        val cleaned = rawAddr.trim().trim(',')
        if (cleaned.isBlank()) return if (venue.isBlank()) "" else "Москва, $venue"
        return if (cleaned.contains("москва", true) || cleaned.contains("область", true)) {
            cleaned
        } else {
            "Москва, $cleaned"
        }
    }

    private fun classifyEvent(
        title: String,
        venue: String,
        rawCats: List<String>
    ): Triple<String, String, Int> {
        val catBlob = rawCats.joinToString(" ").lowercase()
        val fullBlob = "$catBlob ${title.lowercase()} ${venue.lowercase()}"
        return when {
            catBlob.contains("sport") || catBlob.contains("спорт") ||
                fullBlob.contains("футбол") || fullBlob.contains("хоккей") ||
                fullBlob.contains("баскетбол") || fullBlob.contains("матч") ||
                fullBlob.contains("арена") || fullBlob.contains("стадион") ->
                Triple("sport", "⚽", 0xFF5C9CE6.toInt())

            catBlob.contains("stand-up") || catBlob.contains("comedy") ||
                fullBlob.contains("стендап") || fullBlob.contains("stand-up") ||
                fullBlob.contains("standup") || fullBlob.contains("импровиз") ->
                Triple("stand-up", "🎤", 0xFF4DB6AC.toInt())

            catBlob.contains("concert") || catBlob.contains("music") ||
                catBlob.contains("концерт") || catBlob.contains("музык") ||
                fullBlob.contains("концерт") || fullBlob.contains("оркестр") ||
                fullBlob.contains("джаз") || fullBlob.contains("трибьют") ->
                Triple("concert", "🎵", 0xFF9B8AFB.toInt())

            catBlob.contains("theater") || catBlob.contains("theatre") ||
                catBlob.contains("театр") || fullBlob.contains("спектакл") ||
                fullBlob.contains("опера") || fullBlob.contains("балет") ||
                fullBlob.contains("мюзикл") ->
                Triple("theater", "🎭", 0xFFE5A95C.toInt())

            catBlob.contains("festival") || catBlob.contains("holiday") ||
                fullBlob.contains("фестивал") || fullBlob.contains("ярмарк") ||
                fullBlob.contains("маркет") ->
                Triple("festival", "🎪", 0xFFEB986C.toInt())

            catBlob.contains("exhibition") || catBlob.contains("выставк") ||
                catBlob.contains("искусств") || fullBlob.contains("выставк") ||
                fullBlob.contains("экскурс") || fullBlob.contains("музей") ->
                Triple("exhibition", "🖼", 0xFF78909C.toInt())

            else -> Triple("show", "✨", 0xFF4DB6AC.toInt())
        }
    }

    private fun dedupAndSort(list: List<LiveEvent>): List<LiveEvent> {
        val seen = HashSet<String>()
        val unique = ArrayList<LiveEvent>(list.size)
        for (ev in list) {
            val key = "${ev.dateIso}|${ev.timeLabel}|${ev.title.lowercase().take(40)}"
            if (seen.add(key)) unique.add(ev)
        }
        return unique.sortedWith(
            compareBy<LiveEvent> { it.dateIso }
                .thenBy { if (it.hasExactTime) 0 else 1 }
                .thenBy { it.startMs }
                .thenBy { categoryPriority(it.catKey) }
        )
    }

    private fun categoryPriority(catKey: String): Int = when (catKey) {
        "sport" -> 0
        "concert" -> 1
        "festival" -> 2
        "stand-up" -> 3
        "show" -> 4
        "theater" -> 5
        else -> 6
    }

    private fun serialize(list: List<LiveEvent>): String {
        val arr = JSONArray()
        for (ev in list) {
            arr.put(
                JSONObject()
                    .put("id", ev.id)
                    .put("title", ev.title)
                    .put("venue", ev.venue)
                    .put("address", ev.address)
                    .put("startMs", ev.startMs)
                    .put("dateIso", ev.dateIso)
                    .put("timeLabel", ev.timeLabel)
                    .put("exact", ev.hasExactTime)
                    .put("catKey", ev.catKey)
                    .put("catIcon", ev.catIcon)
                    .put("accent", ev.accentColor)
                    .put("url", ev.siteUrl)
            )
        }
        return arr.toString()
    }

    private fun deserialize(raw: String): List<LiveEvent> {
        val arr = JSONArray(raw)
        val today = LocalDate.now(MSK).toString()
        val out = ArrayList<LiveEvent>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val dateIso = o.optString("dateIso", "")
            if (dateIso.isBlank() || dateIso < today) continue
            out.add(
                LiveEvent(
                    id = o.optString("id", i.toString()),
                    title = o.optString("title", ""),
                    venue = o.optString("venue", ""),
                    address = o.optString("address", ""),
                    startMs = o.optLong("startMs", 0L),
                    dateIso = dateIso,
                    timeLabel = o.optString("timeLabel", "уточн."),
                    hasExactTime = o.optBoolean("exact", false),
                    catKey = o.optString("catKey", "show"),
                    catIcon = o.optString("catIcon", "✨"),
                    accentColor = o.optInt("accent", 0xFF4DB6AC.toInt()),
                    siteUrl = o.optString("url", "")
                )
            )
        }
        return out
    }
}
