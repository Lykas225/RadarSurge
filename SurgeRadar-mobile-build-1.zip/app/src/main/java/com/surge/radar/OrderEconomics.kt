package com.surge.radar

import android.content.Context
import kotlin.math.max
import kotlin.math.roundToInt

enum class Verdict { GOOD, OK, BAD }

/** Данные заказа с экрана Яндекс Про. Подача: до клиента, поездка: с клиентом. */
data class OrderInfo(
    val price: Double,
    val pickupKm: Double,
    val tripKm: Double,
    val pickupMin: Int,
    val tripMin: Int,
    val tariff: Tariff?,
    val destZone: SurgeZone?
)

data class VerdictResult(
    val verdict: Verdict,
    val net: Double,
    val perKm: Double,
    val perHour: Double,
    val totalKm: Double,
    val totalMin: Int,
    val fuelPrice: Double,
    val estimated: Boolean
)

/**
 * Чистый доход с заказа: цена, минус комиссия сервиса и налог, минус бензин и износ на весь пробег
 * (подача тоже едет за ваш счёт). Сравнивается с вашими целями в ₽/км и ₽/час.
 *
 * Комиссия сервиса в Москве: Эконом 22,37%, Комфорт и Комфорт+ 25,42%; налог самозанятого 4%.
 */
object OrderEconomics {
    private const val AVG_SPEED_KMH = 25.0
    private const val COMMISSION_ECONOM = 0.2237
    private const val COMMISSION_COMFORT = 0.2542
    private const val TAX = 0.04

    fun title(v: Verdict): String = when (v) {
        Verdict.GOOD -> "ВЫГОДНО"
        Verdict.OK -> "НА ГРАНИ"
        Verdict.BAD -> "НЕ ВЫГОДНО"
    }

    fun color(v: Verdict): Int = when (v) {
        Verdict.GOOD -> 0xFF00E676.toInt()
        Verdict.OK -> 0xFFFFC107.toInt()
        Verdict.BAD -> 0xFFFF5252.toInt()
    }

    fun evaluate(ctx: Context, o: OrderInfo, cfg: WidgetSettings.Values): VerdictResult {
        val tariff = o.tariff ?: Tariff.ECONOM

        var km = o.pickupKm + o.tripKm
        var min = o.pickupMin + o.tripMin
        var estimated = false
        if (km <= 0.0 && min > 0) {
            km = min / 60.0 * AVG_SPEED_KMH
            estimated = true
        }
        if (min <= 0 && km > 0.0) {
            min = (km / AVG_SPEED_KMH * 60.0).roundToInt()
            estimated = true
        }
        val totalKm = max(1.0, km)
        val totalMin = max(1, min)

        val fees = if (cfg.netMode) {
            (if (tariff == Tariff.ECONOM) COMMISSION_ECONOM else COMMISSION_COMFORT) + TAX
        } else 0.0
        val fuelPrice = FuelPrice.current(ctx, cfg)
        val fuel = totalKm * (cfg.consumption / 10.0) / 100.0 * fuelPrice
        val wear = totalKm * (cfg.wear / 10.0)
        val net = o.price * (1.0 - fees) - fuel - wear

        val perKm = net / totalKm
        val perHour = net / (totalMin / 60.0)

        // Куда едем: в горячую зону можно брать дешевле, в пустую дальнюю лучше дороже
        var targetKm = cfg.targetKm.toDouble()
        var targetHour = cfg.targetHour.toDouble()
        o.destZone?.let { dz ->
            val pct = DemandModel.maxPct(DemandModel.baseCoeff(dz), cfg.enabledTariffs())
            val far = MoscowRegionGrid.distanceKm(55.7558, 37.6173, dz.lat, dz.lon) > 25.0
            if (pct >= 40) {
                targetKm *= 0.95
                targetHour *= 0.9
            } else if (pct < 10 && far) {
                targetKm *= 1.1
                targetHour *= 1.15
            }
        }

        val verdict = when {
            perKm >= targetKm && perHour >= targetHour -> Verdict.GOOD
            perKm < targetKm * 0.6 || perHour < targetHour * 0.6 -> Verdict.BAD
            else -> Verdict.OK
        }
        return VerdictResult(verdict, net, perKm, perHour, totalKm, totalMin, fuelPrice, estimated)
    }
}
