package com.surge.radar

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale

class TaximeterReaderService : AccessibilityService() {

    companion object {
        private const val TAXIMETER_PKG = "ru.yandex.taximeter"
    }

    private val loginWords = listOf("выйти на линию", "уйти с линии", "на линии", "баланс", "заказы")
    private val tripWords = listOf("начать поездку", "завершить поездку", "завершить заказ", "я на месте", "на месте", "в пути")

    private val handler = Handler(Looper.getMainLooper())
    private var scanPending = false
    private var lastScanAt = 0L
    private var idleScan = true
    private var lastHash = 0
    private var lastTrip = false
    private var lastHashAt = 0L
    private var lastRecordedBase = -1.0
    private var lastRecordedAt = 0L
    private val pm by lazy { getSystemService(POWER_SERVICE) as PowerManager }

    override fun onServiceConnected() {
        super.onServiceConnected()
        RadarEngine.init(this)
        FuelPrice.refreshAsync(this)
    }

    private val scanRunnable = Runnable {
        scanPending = false
        scanNow()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val ev = event ?: return
        val pkg = ev.packageName?.toString()
        if (pkg != null && pkg != TAXIMETER_PKG) return

        val type = ev.eventType
        ReaderDiag.events++
        ReaderDiag.lastEventAt = System.currentTimeMillis()

        // Чтение push-уведомлений Яндекс Про о повышенном спросе / кэфе в фоне
        if (type == AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED) {
            val notifLines = ev.text?.mapNotNull { it?.toString()?.trim() }?.filter { it.isNotEmpty() }.orEmpty()
            if (notifLines.isNotEmpty()) {
                val reading = SurgeSignalReader.extractFromScreen(this, notifLines, offer = null, fromNotification = true)
                if (reading != null) {
                    applySurgeReading(reading, trip = false)
                }
            }
            return
        }

        val now = SystemClock.uptimeMillis()
        val minGap = when {
            type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> 0L
            idleScan -> 450L
            else -> 220L
        }
        val since = now - lastScanAt
        if (since >= minGap) {
            handler.removeCallbacks(scanRunnable)
            scanPending = false
            scanNow()
        } else if (!scanPending) {
            scanPending = true
            handler.postDelayed(scanRunnable, minGap - since)
        }
    }

    private fun scanNow() {
        lastScanAt = SystemClock.uptimeMillis()
        if (!pm.isInteractive) return
        val now = System.currentTimeMillis()

        val activeRoot = if (Build.VERSION.SDK_INT >= 33) {
            getRootInActiveWindow(
                AccessibilityNodeInfo.FLAG_PREFETCH_DESCENDANTS_HYBRID or
                    AccessibilityNodeInfo.FLAG_PREFETCH_UNINTERRUPTIBLE
            )
        } else {
            rootInActiveWindow
        }

        // Строго проверяем, что на переднем плане именно Яндекс Про
        val activePkg = activeRoot?.packageName?.toString()
        if (activeRoot == null) {
            ReaderDiag.nullRoots++
            return
        }
        if (activePkg != TAXIMETER_PKG) {
            ReaderDiag.lastOrderCheck = "пропуск: активное окно не Яндекс Про ($activePkg)"
            return
        }

        val texts = ArrayList<String>(192)
        val clickableTexts = ArrayList<String>(48)
        val budget = intArrayOf(600)
        collectNodes(activeRoot, texts, clickableTexts, budget, false)

        // Проверяем модальное окно Яндекс Про (если карточка входящего заказа в отдельном слое)
        val hasOfferButtonsInActive = clickableTexts.any {
            val low = it.trim().lowercase()
            low == "принять" || low.contains("принять") || low == "пропустить" || low.startsWith("пропустить ")
        }
        if (!hasOfferButtonsInActive) {
            runCatching {
                for (win in windows) {
                    val r = win.root ?: continue
                    if (r.packageName?.toString() != TAXIMETER_PKG) continue
                    if (r == activeRoot) continue
                    val modalTexts = ArrayList<String>(96)
                    val modalClick = ArrayList<String>(24)
                    collectNodes(r, modalTexts, modalClick, intArrayOf(250), false)
                    val isModalOffer = modalClick.any {
                        val low = it.trim().lowercase()
                        low == "принять" || low.contains("принять") || low == "пропустить" || low.startsWith("пропустить ")
                    }
                    if (isModalOffer) {
                        texts.clear()
                        clickableTexts.clear()
                        texts.addAll(modalTexts)
                        clickableTexts.addAll(modalClick)
                        break
                    }
                }
            }
        }

        ReaderDiag.scans++
        YandexLink.markSeen(this)

        val h = texts.hashCode()
        if (h == lastHash && now - lastHashAt < 15_000L) return
        lastHash = h
        lastHashAt = now
        ReaderDiag.texts = texts.take(80)

        var trip = false
        var loggedIn = false
        for (raw in texts) {
            val low = raw.trim().lowercase()
            if (low.isEmpty()) continue
            if (!trip && tripWords.any { low.contains(it) }) trip = true
            if (!loggedIn && loginWords.any { low.contains(it) }) loggedIn = true
        }
        if (loggedIn && !YandexLink.isLoginConfirmed(this)) YandexLink.setLoginConfirmed(this, true)

        val cfg = WidgetSettings.load(this)
        val overlayOn = cfg.overlayOn
        if (overlayOn && (trip || lastTrip)) {
            runCatching { startService(Intent(this, OverlayWidgetService::class.java).putExtra("TRIP", trip)) }
        }
        lastTrip = trip

        // 1. Сначала пробуем распознать входящую карточку заказа
        var offer: OrderOffer? = null
        if (!trip) {
            offer = OrderOfferReader.parse(this, texts, clickableTexts, null)
            if (offer != null) {
                ReaderDiag.sentOrders++
                val instantEval = OrderEvaluator.evaluate(this, offer, null)
                ReaderDiag.lastOrderSummary = OrderEvaluator.detailedSummary(instantEval)
                if (overlayOn && cfg.showOrderCard) {
                    val orderIntent = Intent(this, OverlayWidgetService::class.java)
                        .setAction(OverlayWidgetService.ACTION_ORDER_OFFER)
                    runCatching { startService(orderIntent) }
                } else if (offer.from.isNotBlank() && offer.to.isNotBlank()) {
                    RouteEstimator.estimateAsync(offer.from, offer.to) { route ->
                        if (route != null) {
                            val fullEval = OrderEvaluator.evaluate(this, offer, route)
                            ReaderDiag.lastOrderSummary = OrderEvaluator.detailedSummary(fullEval)
                        }
                    }
                }
            }
        }

        // 2. Извлекаем реальный коэффициент спроса (с учётом тарифа и рублёвых доплат +₽)
        val reading = SurgeSignalReader.extractFromScreen(this, texts, offer = offer, fromNotification = false)
        idleScan = reading == null || reading.baseEconomCoeff <= 1.01
        if (reading == null) {
            ReaderDiag.summary = "кэф на текущем экране не показан (карта Яндекс Про рисует его графикой)"
            return
        }
        applySurgeReading(reading, trip)
    }

    private fun applySurgeReading(reading: SurgeReading, trip: Boolean) {
        val now = System.currentTimeMillis()
        val cfg = WidgetSettings.load(this)
        val zoneName = cfg.zone ?: MoscowRegionGrid.zones.first().name

        YandexLink.markData(this)
        ReaderDiag.summary = String.format(
            Locale.US,
            "%s → база Эко ×%.2f; поездка=%s",
            reading.source,
            reading.baseEconomCoeff,
            if (trip) "да" else "нет"
        )

        val changedEnough = kotlin.math.abs(reading.baseEconomCoeff - lastRecordedBase) >= 0.02 ||
            now - lastRecordedAt >= 8_000L
        if (changedEnough) {
            lastRecordedBase = reading.baseEconomCoeff
            lastRecordedAt = now
            RadarEngine.record(
                context = this,
                coeff = reading.baseEconomCoeff,
                price = null,
                durationMin = null,
                zoneName = zoneName,
                rawCoeff = reading.rawCoeff,
                source = reading.source
            )
            SurgeWidgetProvider.refreshAll(this)
            if (cfg.overlayOn) {
                val refreshIntent = Intent(this, OverlayWidgetService::class.java)
                    .setAction(OverlayWidgetService.ACTION_SURGE_UPDATED)
                runCatching { startService(refreshIntent) }
            }
        }
    }

    private fun collectNodes(
        node: AccessibilityNodeInfo?,
        out: MutableList<String>,
        clickableOut: MutableList<String>,
        budget: IntArray,
        parentClickable: Boolean
    ) {
        if (node == null || budget[0] <= 0) return
        budget[0]--
        val isBtn = parentClickable || node.isClickable
        node.text?.toString()?.takeIf { it.isNotBlank() }?.let { t ->
            for (line in t.split('\n', '\r')) {
                val c = line.trim()
                if (c.isNotEmpty()) {
                    out.add(c)
                    if (isBtn) clickableOut.add(c)
                }
            }
        }
        node.contentDescription?.toString()?.takeIf { it.isNotBlank() }?.let { d ->
            for (line in d.split('\n', '\r')) {
                val c = line.trim()
                if (c.isNotEmpty()) {
                    out.add(c)
                    if (isBtn) clickableOut.add(c)
                }
            }
        }
        for (i in 0 until node.childCount) {
            collectNodes(node.getChild(i), out, clickableOut, budget, isBtn)
        }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
