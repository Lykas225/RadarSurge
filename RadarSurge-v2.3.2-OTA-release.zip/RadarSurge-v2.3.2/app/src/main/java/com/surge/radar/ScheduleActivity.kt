package com.surge.radar

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/**
 * Меню «Расписание прибытия»:
 * 1) Список всех аэропортов, ж/д вокзалов и автовокзалов с фильтром по вкладкам.
 * 2) При нажатии («проваливании») в конкретный узел (например, Шереметьево, Казанский вокзал
 *    или Автовокзал Саларьево) открывается детальное табло этого узла:
 *    - Выделенным крупным текстом и яркой рамкой: рейсы в ближайшие 30 минут.
 *    - Ниже спокойным списком: все остальные рейсы прибытия до конца дня.
 */
class ScheduleActivity : AppCompatActivity() {

    private val ctx: Context get() = this
    private val matchP = ViewGroup.LayoutParams.MATCH_PARENT
    private val wrapP = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var p: Palette
    private lateinit var backBtn: TextView
    private lateinit var titleView: TextView
    private lateinit var statusView: TextView
    private lateinit var tabsRow: LinearLayout
    private lateinit var listBox: LinearLayout
    private lateinit var scroll: ScrollView
    private val tabViews = mutableListOf<Pair<Int, TextView>>()

    private var selectedMask = PoiKind.AIRPORT.bit or PoiKind.STATION.bit or PoiKind.BUS_STATION.bit
    private var openedPoi: Poi? = null

    private fun dp(v: Int): Int = dpi(v)

    private fun tv(t: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(ctx).apply {
            text = t
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        p = Palette(WidgetSettings.load(this).dark)
        buildUi()

        // Если передали конкретный вокзал/аэропорт через Intent — сразу открываем его
        intent.getStringExtra("POI_NAME")?.let { name ->
            PoiCatalog.fixed.firstOrNull { it.name == name }?.let { openedPoi = it }
        }
        refreshSchedules(false)
    }

    private fun buildUi() {
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(p.bg)
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }

        // Верхняя навигация
        val topBar = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        backBtn = tv("‹ Назад", 15f, p.accent, true).apply {
            setPadding(0, dp(4), dp(16), dp(4))
            setOnClickListener {
                if (openedPoi != null) {
                    openedPoi = null
                    render()
                } else {
                    finish()
                }
            }
        }
        val refreshBtn = tv("↻ Обновить", 14f, p.accent, true).apply {
            setPadding(dp(12), dp(6), dp(12), dp(6))
            background = rounded(withAlpha(p.accent, 0.14f), dp(12).toFloat(), withAlpha(p.accent, 0.45f), dp(1))
            setOnClickListener { refreshSchedules(true) }
        }
        topBar.addView(backBtn, LinearLayout.LayoutParams(0, wrapP, 1f))
        topBar.addView(refreshBtn)
        root.addView(topBar)

        titleView = tv("Расписание прибытия", 23f, p.text, true).apply {
            setPadding(0, dp(8), 0, dp(2))
        }
        root.addView(titleView)

        statusView = tv(ScheduleProvider.status(this), 12f, p.sub).apply {
            setPadding(0, 0, 0, dp(10))
        }
        root.addView(statusView)

        // Вкладки фильтра по виду транспорта
        tabsRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        val allMask = PoiKind.AIRPORT.bit or PoiKind.STATION.bit or PoiKind.BUS_STATION.bit
        val tabs = listOf(
            "Все" to allMask,
            "✈ Аэропорты" to PoiKind.AIRPORT.bit,
            "🚆 Вокзалы" to PoiKind.STATION.bit,
            "🚌 Автовокзалы" to PoiKind.BUS_STATION.bit
        )
        tabViews.clear()
        tabs.forEachIndexed { idx, (label, mask) ->
            val chip = tv(label, 12.5f, p.text, true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(8), dp(8), dp(8), dp(8))
                setOnClickListener {
                    selectedMask = mask
                    openedPoi = null
                    updateTabs()
                    render()
                }
            }
            tabViews.add(mask to chip)
            tabsRow.addView(
                chip,
                LinearLayout.LayoutParams(0, wrapP, 1f).apply {
                    if (idx < tabs.size - 1) rightMargin = dp(6)
                }
            )
        }
        root.addView(tabsRow, LinearLayout.LayoutParams(matchP, wrapP).apply { bottomMargin = dp(12) })
        updateTabs()

        scroll = ScrollView(ctx)
        listBox = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(listBox, ViewGroup.LayoutParams(matchP, wrapP))
        root.addView(scroll, LinearLayout.LayoutParams(matchP, 0, 1f))

        setContentView(root)
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (openedPoi != null) {
            openedPoi = null
            render()
        } else {
            super.onBackPressed()
        }
    }

    private fun updateTabs() {
        for ((mask, view) in tabViews) {
            val active = mask == selectedMask
            view.setTextColor(if (active) Color.WHITE else p.text)
            view.background = if (active) {
                GradientDrawable().apply {
                    setColor(p.accent)
                    cornerRadius = dp(12).toFloat()
                }
            } else {
                rounded(p.card, dp(12).toFloat(), p.stroke, dp(1))
            }
        }
    }

    private fun refreshSchedules(force: Boolean) {
        val transportPois = PoiCatalog.byKinds(PoiKind.AIRPORT.bit or PoiKind.STATION.bit or PoiKind.BUS_STATION.bit)
        if (force) Toast.makeText(this, "Обновляем расписание прибытия…", Toast.LENGTH_SHORT).show()
        ScheduleProvider.refreshAsync(this, transportPois, force) {
            statusView.text = ScheduleProvider.status(this)
            render()
        }
        render()
    }

    private fun render() {
        val poi = openedPoi
        if (poi == null) {
            renderHubsList()
        } else {
            renderPoiDetail(poi)
        }
        scroll.post { scroll.scrollTo(0, 0) }
    }

    private fun arrivalWordGenitive(kind: PoiKind): String = when (kind) {
        PoiKind.AIRPORT -> "прилётов самолётов"
        PoiKind.STATION -> "прибытий поездов"
        else -> "прибытий автобусов"
    }

    private fun arrivalWordTitle(kind: PoiKind): String = when (kind) {
        PoiKind.AIRPORT -> "Прилёты самолётов"
        PoiKind.STATION -> "Прибытие поездов"
        else -> "Прибытие автобусов"
    }

    /** Экран 1: Список аэропортов, ж/д вокзалов и автовокзалов (нажатие открывает расписание узла). */
    private fun renderHubsList() {
        backBtn.text = "‹ Назад"
        titleView.text = "Расписание прибытия"
        statusView.text = ScheduleProvider.status(this)
        tabsRow.visibility = View.VISIBLE
        listBox.removeAllViews()

        val now = System.currentTimeMillis()
        val endDay = ScheduleProvider.endOfDayMs(now)
        val tariffs = WidgetSettings.load(this).enabledTariffs()

        val groups = listOf(
            PoiKind.AIRPORT to "✈ Аэропорты",
            PoiKind.STATION to "🚆 Железнодорожные вокзалы",
            PoiKind.BUS_STATION to "🚌 Автовокзалы и автостанции"
        ).filter { (k, _) -> (k.bit and selectedMask) != 0 }

        listBox.addView(
            tv("Нажмите на аэропорт или вокзал, чтобы открыть его табло прилётов/прибытий:", 12.5f, p.sub).apply {
                setPadding(0, 0, 0, dp(8))
            }
        )

        for ((kind, groupTitle) in groups) {
            val hubs = PoiCatalog.byKinds(kind.bit)
            if (hubs.isEmpty()) continue

            listBox.addView(tv(groupTitle, 15f, p.accent, true).apply {
                setPadding(0, dp(8), 0, dp(6))
            })

            for (poi in hubs) {
                val count30 = ScheduleProvider.arrivalsBetween(poi, now - 5 * 60_000L, now + 30 * 60_000L)
                val allToday = ScheduleProvider.arrivalsForPoi(poi, now - 5 * 60_000L, endDay)
                val zone = MoscowRegionGrid.nearest(poi.lat, poi.lon)
                val dKind = if (poi.kind == PoiKind.AIRPORT) DemandModel.Kind.AIRPORT else DemandModel.Kind.STATION
                var base = maxOf(DemandModel.baseCoeff(zone, now), DemandModel.kindCoeff(dKind, now))
                if (count30 != null) {
                    val per = when (poi.kind) {
                        PoiKind.AIRPORT -> 0.05
                        PoiKind.STATION -> 0.08
                        else -> 0.07
                    }
                    base += minOf(0.8, count30 * per)
                }
                val pct = DemandModel.maxPct(minOf(3.0, base), tariffs)
                val color = DemandModel.textColor(pct)
                val hasSoon = count30 != null && count30 > 0

                val card = LinearLayout(ctx).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    background = rounded(
                        if (hasSoon) p.cardAlt else p.card,
                        dp(15).toFloat(),
                        if (hasSoon) withAlpha(p.accent, 0.7f) else p.stroke,
                        dp(1)
                    )
                    setPadding(dp(14), dp(12), dp(14), dp(12))
                    setOnClickListener {
                        openedPoi = poi
                        render()
                    }
                }

                val info = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
                info.addView(tv("${poi.kind.emoji} ${poi.name}", 16f, p.text, true))

                val line30 = if (count30 != null) {
                    "⚡ В ближайшие 30 мин: $count30 • до конца дня: ${allToday.size}"
                } else {
                    "Нажмите для просмотра расписания ›"
                }
                info.addView(
                    tv(line30, 12.5f, if (hasSoon) p.accent else p.sub, hasSoon).apply {
                        setPadding(0, dp(3), 0, 0)
                    }
                )
                card.addView(info, LinearLayout.LayoutParams(0, wrapP, 1f))

                val pill = tv(DemandModel.coefText(pct), 14f, color, true).apply {
                    gravity = Gravity.CENTER
                    minWidth = dp(52)
                    setPadding(dp(8), dp(4), dp(8), dp(4))
                    background = rounded(withAlpha(color, 0.15f), dp(10).toFloat(), withAlpha(color, 0.5f), dp(1))
                }
                card.addView(pill, LinearLayout.LayoutParams(wrapP, wrapP).apply { leftMargin = dp(8) })
                card.addView(
                    tv("›", 20f, p.sub, true).apply { setPadding(dp(8), 0, dp(2), 0) }
                )

                listBox.addView(card, LinearLayout.LayoutParams(matchP, wrapP).apply { bottomMargin = dp(7) })
            }
        }
    }

    /**
     * Экран 2: Детальное расписание выбранного аэропорта / ж/д вокзала / автовокзала:
     * - Блок 1 (Выделенный): рейсы в течение ближайших 30 минут.
     * - Блок 2: остальные рейсы до конца дня.
     */
    private fun renderPoiDetail(poi: Poi) {
        backBtn.text = "‹ Ко всем вокзалам и аэропортам"
        titleView.text = "${poi.kind.emoji} ${poi.name}"
        tabsRow.visibility = View.GONE
        listBox.removeAllViews()

        val now = System.currentTimeMillis()
        val window30End = now + 30 * 60_000L
        val endDay = ScheduleProvider.endOfDayMs(now)

        val allEntries = ScheduleProvider.arrivalsForPoi(poi, now - 5 * 60_000L, endDay)
        val soon30 = allEntries.filter { it.timeMs <= window30End }
        val laterToday = allEntries.filter { it.timeMs > window30End }

        statusView.text =
            "${arrivalWordTitle(poi.kind)} • сейчас ${DemandModel.mskTime(now)} • в 30 мин: ${soon30.size} • далее за день: ${laterToday.size}"

        if (ScheduleProvider.key(this).isBlank()) {
            val warnCard = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                background = rounded(p.cardAlt, dp(15).toFloat(), p.warn, dp(1))
                setPadding(dp(14), dp(12), dp(14), dp(12))
            }
            warnCard.addView(tv("Ключ API Яндекс Расписаний не указан", 15f, p.warn, true))
            warnCard.addView(
                tv(
                    "Чтобы видеть точное табло ${arrivalWordGenitive(poi.kind)} по «${poi.name}» на 30 минут и до конца дня, " +
                        "введите бесплатный ключ API Яндекс Расписаний в меню «Настройки».",
                    13f, p.text
                ).apply { setPadding(0, dp(4), 0, 0) }
            )
            listBox.addView(warnCard, LinearLayout.LayoutParams(matchP, wrapP).apply { bottomMargin = dp(12) })
        }

        // ===== БЛОК 1: ВЫДЕЛЕННЫЙ БЛОК — В ТЕЧЕНИЕ 30 МИНУТ =====
        val soonBanner = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(withAlpha(p.accent, 0.24f), withAlpha(p.cardAlt, 0.96f))
            ).apply {
                cornerRadius = dp(16).toFloat()
                setStroke(dp(2), p.accent)
            }
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }

        val bannerHeader = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        bannerHeader.addView(
            tv(
                "🔥 ${arrivalWordTitle(poi.kind).uppercase()} В БЛИЖАЙШИЕ 30 МИНУТ",
                14.5f,
                p.accent,
                true
            ),
            LinearLayout.LayoutParams(0, wrapP, 1f)
        )
        val countBadge = tv("${soon30.size}", 14f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(3), dp(10), dp(3))
            background = rounded(p.accent, dp(10).toFloat())
        }
        bannerHeader.addView(countBadge)
        soonBanner.addView(bannerHeader)

        soonBanner.addView(
            tv(
                "Интервал ${DemandModel.mskTime(now)} – ${DemandModel.mskTime(window30End)} (максимальный спрос на подачу)",
                11.5f,
                p.sub
            ).apply { setPadding(0, dp(2), 0, dp(8)) }
        )

        if (soon30.isEmpty()) {
            soonBanner.addView(
                tv(
                    "В ближайшие 30 минут ${arrivalWordGenitive(poi.kind)} по расписанию нет.",
                    13.5f,
                    p.text,
                    true
                ).apply { setPadding(0, dp(4), 0, dp(2)) }
            )
        } else {
            for (item in soon30) {
                soonBanner.addView(
                    makeArrivalRow(item, now, highlighted = true),
                    LinearLayout.LayoutParams(matchP, wrapP).apply { topMargin = dp(6) }
                )
            }
        }
        listBox.addView(soonBanner, LinearLayout.LayoutParams(matchP, wrapP).apply { bottomMargin = dp(16) })

        // ===== БЛОК 2: ДАЛЬШЕ ДО КОНЦА ДНЯ =====
        val laterTitle = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(2), dp(4), dp(2), dp(8))
        }
        laterTitle.addView(
            tv("📅 Далее до конца дня (после ${DemandModel.mskTime(window30End)})", 15f, p.text, true),
            LinearLayout.LayoutParams(0, wrapP, 1f)
        )
        laterTitle.addView(
            tv("рейсов: ${laterToday.size}", 12.5f, p.sub, true)
        )
        listBox.addView(laterTitle)

        if (laterToday.isEmpty()) {
            val emptyLater = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                background = rounded(p.card, dp(14).toFloat(), p.stroke, dp(1))
                setPadding(dp(14), dp(12), dp(14), dp(12))
            }
            emptyLater.addView(
                tv(
                    if (ScheduleProvider.key(this).isBlank())
                        "Список рейсов до конца дня появится после ввода ключа API Яндекс Расписаний в Настройках."
                    else
                        "До конца текущих суток других рейсов прибытия не найдено.",
                    13f,
                    p.sub
                )
            )
            listBox.addView(emptyLater, LinearLayout.LayoutParams(matchP, wrapP))
        } else {
            for (item in laterToday) {
                listBox.addView(
                    makeArrivalRow(item, now, highlighted = false),
                    LinearLayout.LayoutParams(matchP, wrapP).apply { bottomMargin = dp(6) }
                )
            }
        }
    }

    /** Строка конкретного рейса: при highlighted=true выводится крупным выделенным шрифтом и яркой плашкой. */
    private fun makeArrivalRow(item: ArrivalEntry, now: Long, highlighted: Boolean): View {
        val diffMin = ((item.timeMs - now) / 60_000L).toInt()
        val badgeText = when {
            diffMin < 0 -> "прибыл ${-diffMin} м назад"
            diffMin == 0 -> "ПРИБЫВАЕТ СЕЙЧАС"
            diffMin <= 30 -> "ЧЕРЕЗ $diffMin МИН"
            diffMin < 60 -> "через $diffMin мин"
            else -> "через ${diffMin / 60} ч ${diffMin % 60} м"
        }

        val rowBg = if (highlighted) p.card else p.card
        val strokeColor = if (highlighted) p.accent else p.stroke
        val strokeWidth = if (highlighted) dp(2) else dp(1)

        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(rowBg, dp(13).toFloat(), strokeColor, strokeWidth)
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }

        // Время прибытия слева
        val timeCol = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        val timeColor = if (highlighted) p.warn else p.accent
        timeCol.addView(
            tv(DemandModel.mskTime(item.timeMs), if (highlighted) 18f else 15.5f, timeColor, true)
        )
        val badgeView = tv(
            badgeText,
            if (highlighted) 10.5f else 10f,
            if (highlighted) Color.WHITE else p.sub,
            highlighted
        ).apply {
            gravity = Gravity.CENTER
            if (highlighted) {
                setPadding(dp(6), dp(2), dp(6), dp(2))
                background = rounded(withAlpha(p.accent, 0.85f), dp(6).toFloat())
            }
        }
        timeCol.addView(badgeView, LinearLayout.LayoutParams(wrapP, wrapP).apply { topMargin = dp(3) })
        row.addView(timeCol, LinearLayout.LayoutParams(dp(96), wrapP))

        // Маршрут и номер рейса
        val midCol = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        val routeLabel = if (item.number.isNotEmpty()) "${item.number} · ${item.title}" else item.title
        midCol.addView(
            tv(
                routeLabel,
                if (highlighted) 15.5f else 14f,
                p.text,
                highlighted
            ).apply {
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
            }
        )
        val kindHint = when (item.poi.kind) {
            PoiKind.AIRPORT -> if (highlighted) "✈ ВЫДЕЛЕННЫЙ ПРИЛЁТ (≤ 30 мин)" else "✈ Прилёт по расписанию"
            PoiKind.STATION -> if (highlighted) "🚆 ВЫДЕЛЕННОЕ ПРИБЫТИЕ ПОЕЗДА (≤ 30 мин)" else "🚆 Прибытие поезда"
            else -> if (highlighted) "🚌 ВЫДЕЛЕННОЕ ПРИБЫТИЕ АВТОБУСА (≤ 30 мин)" else "🚌 Прибытие автобуса"
        }
        midCol.addView(
            tv(kindHint, 11.5f, if (highlighted) p.accent else p.sub, highlighted).apply {
                setPadding(0, dp(3), 0, 0)
            }
        )
        row.addView(midCol, LinearLayout.LayoutParams(0, wrapP, 1f).apply { leftMargin = dp(10) })

        return row
    }
}
