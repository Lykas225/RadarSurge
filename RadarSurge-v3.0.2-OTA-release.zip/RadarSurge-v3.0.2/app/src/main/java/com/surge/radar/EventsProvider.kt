package com.surge.radar

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.time.Instant
import java.time.LocalDate
import java.time.OffsetDateTime
import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

data class LiveEvent(
    val id: String,
    val title: String,
    val venue: String,
    val address: String,
    val startMs: Long,
    val dateIso: String,
    val timeLabel: String,
    val hasExactTime: Boolean,
    val catKey: String,
    val catIcon: String,
    val accentColor: Int,
    val siteUrl: String
)

/**
 * Живые мероприятия Москвы из нескольких открытых источников без API-ключа:
 * 1) Timepad Public API (основной — стабильно работает в РФ и через VPN без блокировки 403),
 * 2) KudaGo Public API (дополнительный — крупные концерты, стадионы, шоу; с браузерными заголовками).
 * Выдуманных событий нет; результаты объединяются, дедуплицируются и кэшируются на 30 минут.
 */
object EventsProvider {
    private const val PREFS = "events_cache_v2"
    private const val CACHE_TTL_MS = 30 * 60_000L
    private const val BROWSER_UA =
        "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"
    private val MSK = ZoneId.of("Europe/Moscow")
    private val mainHandler = Handler(Looper.getMainLooper())
    private val loading = AtomicBoolean(false)

    val categories: List<Pair<String, String>> = listOf(
        "all" to "Все",
        "concert" to "🎵 Концерты",
        "sport" to "⚽ Спорт",
        "theater" to "🎭 Театр",
        "stand-up" to "🎤 Стендап",
        "festival" to "🎪 Фестивали",
        "show" to "✨ Шоу",
        "exhibition" to "🖼 Выставки"
    )

    private fun prefs(c: Context) = c.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun cached(c: Context): List<LiveEvent> {
        val raw = prefs(c).getString("events_json", null) ?: return emptyList()
        return runCatching { deserialize(raw) }.getOrDefault(emptyList())
    }

    fun statusLine(c: Context): String {
        val p = prefs(c)
        val at = p.getLong("at", 0L)
        val src = p.getString("src", "") ?: ""
        val err = p.getString("err", "") ?: ""
        if (at <= 0L) return if (err.isBlank()) "Загрузка афиши Москвы…" else err
        val time = DemandModel.mskTime(at)
        val count = cached(c).size
        val srcSuffix = if (src.isNotBlank()) " · $src" else ""
        return if (count > 0) "Афиша Москвы$srcSuffix · $time ($count)" else "Обновлено в $time"
    }

    fun refreshAsync(
        c: Context,
        force: Boolean = false,
        onDone: (List<LiveEvent>, String?) -> Unit
    ) {
        val app = c.applicationContext
        val p = prefs(app)
        val cachedList = cached(app)
        val age = System.currentTimeMillis() - p.getLong("at", 0L)
        if (!force && cachedList.isNotEmpty() && age < CACHE_TTL_MS) {
            mainHandler.post { onDone(cachedList, null) }
            return
        }
        if (!loading.compareAndSet(false, true)) return

        Thread {
            try {
                val merged = ArrayList<LiveEvent>(120)
                val activeSources = ArrayList<String>(2)
                val errors = ArrayList<String>(2)

                // Источник 1: Timepad Public API (открытый JSON API по Москве)
                val tpRes = runCatching { fetchTimepad() }
                tpRes.onSuccess { list ->
                    if (list.isNotEmpty()) {
                        merged.addAll(list)
                        activeSources.add("Timepad")
                    }
                }.onFailure { e ->
                    errors.add("Timepad: ${e.message ?: "ошибка"}")
                }

                // Источник 2: KudaGo Public API (с мобильными браузерными заголовками)
                val kgRes = runCatching { fetchKudaGo() }
                kgRes.onSuccess { list ->
                    if (list.isNotEmpty()) {
                        merged.addAll(list)
                        activeSources.add("KudaGo")
                    }
                }.onFailure { e ->
                    errors.add("KudaGo: ${e.message ?: "ошибка"}")
                }

                val finalEvents = dedupAndSort(merged)
                if (finalEvents.isNotEmpty()) {
                    val srcLabel = activeSources.joinToString(" + ")
                    p.edit()
                        .putString("events_json", serialize(finalEvents))
                        .putString("src", srcLabel)
                        .putLong("at", System.currentTimeMillis())
                        .putString("err", "")
                        .apply()
                    mainHandler.post { onDone(finalEvents, null) }
                } else {
                    val errMsg = if (errors.isNotEmpty()) {
                        "Источники недоступны (${errors.joinToString("; ")})"
                    } else {
                        "Не найдено ближайших мероприятий"
                    }
                    p.edit().putString("err", errMsg).apply()
                    val fallback = cached(app)
                    mainHandler.post { onDone(fallback, errMsg) }
                }
            } catch (e: Exception) {
                val msg = e.message ?: "Не удалось загрузить афишу"
                p.edit().putString("err", msg).apply()
                val fallback = cached(app)
                mainHandler.post { onDone(fallback, msg) }
            } finally {
                loading.set(false)
            }
        }.start()
    }

    private fun httpGet(urlStr: String, referer: String? = null): String {
        var current = urlStr
        for (hop in 0 until 5) {
            val conn = (URL(current).openConnection() as HttpURLConnection).apply {
                instanceFollowRedirects = false
                connectTimeout = 9_000
                readTimeout = 10_000
                setRequestProperty("User-Agent", BROWSER_UA)
                setRequestProperty("Accept", "application/json, text/plain, */*")
                setRequestProperty("Accept-Language", "ru-RU,ru;q=0.9,en-US;q=0.5")
                if (!referer.isNullOrBlank()) setRequestProperty("Referer", referer)
            }
            val code = conn.responseCode
            if (code == 301 || code == 302 || code == 303 || code == 307 || code == 308) {
                val loc = conn.getHeaderField("Location")
                conn.disconnect()
                if (loc.isNullOrBlank()) throw IllegalStateException("HTTP $code")
                current = URL(URL(current), loc).toString()
                continue
            }
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            conn.disconnect()
            if (code !in 200..299) {
                throw IllegalStateException("HTTP $code")
            }
            return body
        }
        throw IllegalStateException("слишком много редиректов")
    }

    private fun fetchTimepad(): List<LiveEvent> {
        val today = LocalDate.now(MSK)
        val startStr = today.toString()
        val endStr = today.plusDays(7).toString()
        val cityEnc = URLEncoder.encode("Москва", "UTF-8")
        val urlStr = "https://api.timepad.ru/v1/events.json" +
            "?limit=90&skip=0&cities=$cityEnc" +
            "&fields=location,organization" +
            "&starts_at_min=$startStr&starts_at_max=$endStr" +
            "&sort=%2Bstarts_at"
        val body = httpGet(urlStr, "https://afisha.timepad.ru/moscow")
        return parseTimepad(body)
    }

    private fun parseTimepad(rawJson: String): List<LiveEvent> {
        val root = JSONObject(rawJson)
        val values = root.optJSONArray("values") ?: return emptyList()
        val nowMs = System.currentTimeMillis()
        val today = LocalDate.now(MSK)
        val maxDate = today.plusDays(7)
        val out = ArrayList<LiveEvent>(values.length())

        for (i in 0 until values.length()) {
            val item = values.optJSONObject(i) ?: continue
            val id = "tp_" + item.optInt("id", i)
            val title = decodeHtml(item.optString("name", "")).trim()
                .replaceFirstChar { if (it.isLowerCase()) it.uppercase() else it.toString() }
            if (title.isBlank()) continue

            val startsRaw = item.optString("starts_at", "").trim()
            val zdt = parseIsoToMsk(startsRaw) ?: continue
            val startMs = zdt.toInstant().toEpochMilli()
            if (startMs < nowMs - 3 * 3_600_000L) continue
            val ld = zdt.toLocalDate()
            if (ld.isBefore(today) || ld.isAfter(maxDate)) continue

            val loc = item.optJSONObject("location")
            val rawAddr = decodeHtml(loc?.optString("address", "").orEmpty()).trim()
            val city = decodeHtml(loc?.optString("city", "").orEmpty()).trim()
            // Отсекаем чисто онлайн-вебинары без физического адреса в Москве
            if (rawAddr.isBlank() || isOnlineAddress(rawAddr)) continue

            val org = item.optJSONObject("organization")
            val venue = decodeHtml(org?.optString("name", "").orEmpty()).trim()
                .ifBlank { "Площадка в Москве" }
            val address = formatMoscowAddress(rawAddr, city.ifBlank { venue })

            val catNames = ArrayList<String>()
            val catsArr = item.optJSONArray("categories")
            if (catsArr != null) {
                for (cIdx in 0 until catsArr.length()) {
                    val cObj = catsArr.optJSONObject(cIdx)
                    val cName = cObj?.optString("name", "")?.trim().orEmpty()
                    if (cName.isNotBlank()) catNames.add(cName)
                }
            }
            val (catKey, catIcon, accentColor) = classifyEvent(title, venue, catNames)

            val exact = !(zdt.hour == 0 && zdt.minute == 0)
            val timeLabel = if (exact) {
                String.format(Locale.US, "%02d:%02d", zdt.hour, zdt.minute)
            } else {
                "уточн."
            }

            out.add(
                LiveEvent(
                    id = id,
                    title = title,
                    venue = venue,
                    address = address,
                    startMs = startMs,
                    dateIso = ld.toString(),
                    timeLabel = timeLabel,
                    hasExactTime = exact,
                    catKey = catKey,
                    catIcon = catIcon,
                    accentColor = accentColor,
                    siteUrl = item.optString("url", "")
                )
            )
        }
        return out
    }

    private fun fetchKudaGo(): List<LiveEvent> {
        val nowSec = System.currentTimeMillis() / 1000L
        val startOfToday = LocalDate.now(MSK).atStartOfDay(MSK).toEpochSecond()
        val endWindow = LocalDate.now(MSK).plusDays(7).atStartOfDay(MSK).toEpochSecond()
        val since = maxOf(startOfToday, nowSec - 3 * 3600L)
        val urlStr = "https://kudago.com/public-api/v1.4/events/" +
            "?location=msk&actual_since=$since&actual_until=$endWindow" +
            "&expand=place,dates&fields=id,title,dates,place,categories,site_url" +
            "&page_size=80&order_by=dates"
        val body = httpGet(urlStr, "https://kudago.com/msk/events/")
        return parseKudaGo(body)
    }

    private fun parseKudaGo(rawJson: String): List<LiveEvent> {
        val root = JSONObject(rawJson)
        val results = root.optJSONArray("results") ?: return emptyList()
        val today = LocalDate.now(MSK)
        val todayStartSec = today.atStartOfDay(MSK).toEpochSecond()
        val maxEndSec = today.plusDays(7).atStartOfDay(MSK).toEpochSecond()
        val nowSec = System.currentTimeMillis() / 1000L
        val out = ArrayList<LiveEvent>(results.length())

        for (i in 0 until results.length()) {
            val item = results.optJSONObject(i) ?: continue
            val id = "kg_" + item.optInt("id", i)
            val title = decodeHtml(item.optString("title", "")).trim()
                .replaceFirstChar { if (it.isLowerCase()) it.uppercase() else it.toString() }
            if (title.isBlank()) continue
            val siteUrl = item.optString("site_url", "")

            val place = item.optJSONObject("place")
            val venue = decodeHtml(place?.optString("title", "").orEmpty()).trim()
                .replaceFirstChar { if (it.isLowerCase()) it.uppercase() else it.toString() }
            val rawAddr = decodeHtml(place?.optString("address", "").orEmpty()).trim()
            val address = formatMoscowAddress(rawAddr, venue)
            if (venue.isBlank() && address.isBlank()) continue

            val catNames = ArrayList<String>()
            val catsArr = item.optJSONArray("categories")
            if (catsArr != null) {
                for (cIdx in 0 until catsArr.length()) {
                    catNames.add(catsArr.optString(cIdx, ""))
                }
            }
            val (catKey, catIcon, accentColor) = classifyEvent(title, venue, catNames)

            val datesArr = item.optJSONArray("dates") ?: continue
            val slot = pickUpcomingSlot(datesArr, todayStartSec, maxEndSec, nowSec) ?: continue
            val startSec = slot.first
            val exact = slot.second

            val zdt = ZonedDateTime.ofInstant(Instant.ofEpochSecond(startSec), MSK)
            val dateIso = zdt.toLocalDate().toString()
            val timeLabel = if (exact) {
                String.format(Locale.US, "%02d:%02d", zdt.hour, zdt.minute)
            } else {
                "уточн."
            }

            out.add(
                LiveEvent(
                    id = id,
                    title = title,
                    venue = venue.ifBlank { "Площадка в Москве" },
                    address = address,
                    startMs = startSec * 1000L,
                    dateIso = dateIso,
                    timeLabel = timeLabel,
                    hasExactTime = exact,
                    catKey = catKey,
                    catIcon = catIcon,
                    accentColor = accentColor,
                    siteUrl = siteUrl
                )
            )
        }
        return out
    }

    private fun parseIsoToMsk(raw: String): ZonedDateTime? {
        if (raw.isBlank()) return null
        val normalized = raw.replace(Regex("([+-]\\d{2})(\\d{2})$"), "$1:$2")
        return runCatching {
            OffsetDateTime.parse(normalized).atZoneSameInstant(MSK)
        }.getOrElse {
            runCatching {
                Instant.parse(normalized).atZone(MSK)
            }.getOrNull()
        }
    }

    private fun isOnlineAddress(addr: String): Boolean {
        val low = addr.lowercase()
        return low.contains("онлайн") || low.contains("online") ||
            low.contains("zoom") || low.contains("вебинар") ||
            low.startsWith("http://") || low.startsWith("https://")
    }

    private fun decodeHtml(s: String): String =
        s.replace("&quot;", "\"")
            .replace("&laquo;", "«")
            .replace("&raquo;", "»")
            .replace("&nbsp;", " ")
            .replace("&amp;", "&")
            .replace("&#39;", "'")
            .replace("&mdash;", "—")
            .replace("&ndash;", "–")
            .replace(Regex("\\s+"), " ")

    private fun pickUpcomingSlot(
        dates: JSONArray,
        todayStartSec: Long,
        maxEndSec: Long,
        nowSec: Long
    ): Pair<Long, Boolean>? {
        var bestExact: Long? = null
        var ongoingToday = false

        for (i in 0 until dates.length()) {
            val d = dates.optJSONObject(i) ?: continue
            val start = d.optLong("start", -1L)
            val end = d.optLong("end", -1L)
            if (start in todayStartSec until maxEndSec) {
                if (end in 1 until (nowSec - 3600L)) continue
                val z = ZonedDateTime.ofInstant(Instant.ofEpochSecond(start), MSK)
                val isMidnight = (z.hour == 0 && z.minute == 0)
                if (!isMidnight) {
                    if (bestExact == null || start < bestExact) bestExact = start
                } else if (bestExact == null) {
                    return start to false
                }
            } else if (start in 1 until todayStartSec && (end >= nowSec || end <= 0L)) {
                ongoingToday = true
            }
        }
        if (bestExact != null) return bestExact to true
        if (ongoingToday) return todayStartSec to false
        return null
    }

    private fun formatMoscowAddress(rawAddr: String, venue: String): String {
        val cleaned = rawAddr.trim().trim(',')
        if (cleaned.isBlank()) return if (venue.isBlank()) "" else "Москва, $venue"
        return if (cleaned.contains("москва", true) || cleaned.contains("область", true)) {
            cleaned
        } else {
            "Москва, $cleaned"
        }
    }

    private fun classifyEvent(
        title: String,
        venue: String,
        rawCats: List<String>
    ): Triple<String, String, Int> {
        val catBlob = rawCats.joinToString(" ").lowercase()
        val fullBlob = "$catBlob ${title.lowercase()} ${venue.lowercase()}"
        return when {
            catBlob.contains("sport") || catBlob.contains("спорт") ||
                fullBlob.contains("футбол") || fullBlob.contains("хоккей") ||
                fullBlob.contains("баскетбол") || fullBlob.contains("матч") ||
                fullBlob.contains("арена") || fullBlob.contains("стадион") ->
                Triple("sport", "⚽", 0xFF5C9CE6.toInt())

            catBlob.contains("stand-up") || catBlob.contains("comedy") ||
                fullBlob.contains("стендап") || fullBlob.contains("stand-up") ||
                fullBlob.contains("standup") || fullBlob.contains("импровиз") ->
                Triple("stand-up", "🎤", 0xFF4DB6AC.toInt())

            catBlob.contains("concert") || catBlob.contains("концерт") ||
                catBlob.contains("музык") || fullBlob.contains("концерт") ||
                fullBlob.contains("оркестр") || fullBlob.contains("джаз") ||
                fullBlob.contains("трибьют") ->
                Triple("concert", "🎵", 0xFF9B8AFB.toInt())

            catBlob.contains("theater") || catBlob.contains("театр") ||
                fullBlob.contains("спектакл") || fullBlob.contains("опера") ||
                fullBlob.contains("балет") || fullBlob.contains("мюзикл") ->
                Triple("theater", "🎭", 0xFFE5A95C.toInt())

            catBlob.contains("festival") || catBlob.contains("holiday") ||
                fullBlob.contains("фестивал") || fullBlob.contains("ярмарк") ||
                fullBlob.contains("маркет") ->
                Triple("festival", "🎪", 0xFFEB986C.toInt())

            catBlob.contains("exhibition") || catBlob.contains("выставк") ||
                catBlob.contains("искусств") || fullBlob.contains("выставк") ||
                fullBlob.contains("экскурс") || fullBlob.contains("музей") ->
                Triple("exhibition", "🖼", 0xFF78909C.toInt())

            else -> Triple("show", "✨", 0xFF4DB6AC.toInt())
        }
    }

    private fun dedupAndSort(list: List<LiveEvent>): List<LiveEvent> {
        val seen = HashSet<String>()
        val unique = ArrayList<LiveEvent>(list.size)
        for (ev in list) {
            val key = "${ev.dateIso}|${ev.timeLabel}|${ev.title.lowercase().take(40)}"
            if (seen.add(key)) unique.add(ev)
        }
        return unique.sortedWith(
            compareBy<LiveEvent> { it.dateIso }
                .thenBy { if (it.hasExactTime) 0 else 1 }
                .thenBy { it.startMs }
                .thenBy { categoryPriority(it.catKey) }
        )
    }

    private fun categoryPriority(catKey: String): Int = when (catKey) {
        "sport" -> 0
        "concert" -> 1
        "festival" -> 2
        "stand-up" -> 3
        "show" -> 4
        "theater" -> 5
        else -> 6
    }

    private fun serialize(list: List<LiveEvent>): String {
        val arr = JSONArray()
        for (ev in list) {
            arr.put(
                JSONObject()
                    .put("id", ev.id)
                    .put("title", ev.title)
                    .put("venue", ev.venue)
                    .put("address", ev.address)
                    .put("startMs", ev.startMs)
                    .put("dateIso", ev.dateIso)
                    .put("timeLabel", ev.timeLabel)
                    .put("exact", ev.hasExactTime)
                    .put("catKey", ev.catKey)
                    .put("catIcon", ev.catIcon)
                    .put("accent", ev.accentColor)
                    .put("url", ev.siteUrl)
            )
        }
        return arr.toString()
    }

    private fun deserialize(raw: String): List<LiveEvent> {
        val arr = JSONArray(raw)
        val today = LocalDate.now(MSK).toString()
        val out = ArrayList<LiveEvent>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val dateIso = o.optString("dateIso", "")
            if (dateIso.isBlank() || dateIso < today) continue
            out.add(
                LiveEvent(
                    id = o.optString("id", i.toString()),
                    title = o.optString("title", ""),
                    venue = o.optString("venue", ""),
                    address = o.optString("address", ""),
                    startMs = o.optLong("startMs", 0L),
                    dateIso = dateIso,
                    timeLabel = o.optString("timeLabel", "уточн."),
                    hasExactTime = o.optBoolean("exact", false),
                    catKey = o.optString("catKey", "show"),
                    catIcon = o.optString("catIcon", "✨"),
                    accentColor = o.optInt("accent", 0xFF4DB6AC.toInt()),
                    siteUrl = o.optString("url", "")
                )
            )
        }
        return out
    }
}
