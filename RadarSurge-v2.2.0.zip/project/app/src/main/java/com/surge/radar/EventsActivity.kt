package com.surge.radar

import android.annotation.SuppressLint
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.net.URLEncoder
import java.time.LocalDate
import java.time.format.DateTimeFormatter

/** Live event listings: embedded web sources, no fake/offline event data. */
class EventsActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private lateinit var progress: ProgressBar
    private lateinit var status: TextView
    private lateinit var sourceRow: LinearLayout
    private lateinit var categoryRow: LinearLayout
    private lateinit var dateRow: LinearLayout
    private var source = 0
    private var category = "Все события"
    private var period = "Ближайшие"

    private val sources = listOf(
        "Яндекс Афиша" to "https://afisha.yandex.ru/moscow/events",
        "Timepad" to "https://afisha.timepad.ru/moscow",
        "Афиша" to "https://www.afisha.ru/msk/events/"
    )
    private val categories = listOf("Все события", "Концерты", "Театр", "Выставки", "Фестивали", "Спорт", "Стендап", "Детям", "Экскурсии", "Бесплатно")
    private val periods = listOf("Ближайшие", "Сегодня", "Завтра", "Выходные", "7 дней")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun text(s: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD)
    }
    private fun pill(label: String, selected: Boolean, onClick: () -> Unit): TextView = text(label, 12.5f, if (selected) Color.WHITE else Color.rgb(205,218,228), selected).apply {
        gravity = Gravity.CENTER; setPadding(dp(12), dp(9), dp(12), dp(9))
        background = GradientDrawable().apply { cornerRadius = dp(18).toFloat(); setColor(if (selected) Color.rgb(25,135,115) else Color.rgb(35,48,61)); setStroke(dp(1), if (selected) Color.rgb(50,180,150) else Color.rgb(54,70,82)) }
        setOnClickListener { onClick() }
    }
    private fun rowScroll(items: List<String>, selected: String, click: (String) -> Unit): LinearLayout {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        items.forEach { item -> row.addView(pill(item, item == selected) { click(item) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(6) }) }
        return row
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(15,23,31)); setPadding(dp(14), dp(12), dp(14), dp(10)) }
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; orientation = LinearLayout.HORIZONTAL }
        val back = text("‹  Назад", 16f, Color.rgb(80,210,175), true).apply { setPadding(0, dp(8), dp(12), dp(8)); setOnClickListener { finish() } }
        val title = text("Мероприятия Москвы", 20f, Color.WHITE, true)
        top.addView(back); top.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)); root.addView(top)
        status = text("Актуальная афиша загружается из выбранного источника", 11.5f, Color.rgb(160,180,194)).apply { setPadding(0, dp(4), 0, dp(8)) }
        root.addView(status)
        sourceRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val srcScroll = android.widget.HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(sourceRow) }
        root.addView(srcScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(8) })
        categoryRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val catScroll = android.widget.HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(categoryRow) }
        root.addView(catScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(7) })
        dateRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val dateScroll = android.widget.HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(dateRow) }
        root.addView(dateScroll, LinearLayout.LayoutParams(ViewGroup.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(8) })
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { visibility = View.GONE; max = 100 }
        root.addView(progress, LinearLayout.LayoutParams(ViewGroup.MATCH_PARENT, dp(3)))
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.loadsImagesAutomatically = true
            settings.userAgentString = "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36"
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                    val uri = runCatching { Uri.parse(url ?: "") }.getOrNull() ?: return true
                    return if (uri.scheme == "https" || uri.scheme == "http") false else true
                }
            }
            webChromeClient = object : WebChromeClient() { override fun onProgressChanged(view: WebView?, newProgress: Int) { progress.progress = newProgress; progress.visibility = if (newProgress >= 100) View.GONE else View.VISIBLE } }
        }
        root.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        renderFilters(); loadPage()
    }

    private fun renderFilters() {
        sourceRow.removeAllViews(); sources.forEachIndexed { i, sourceItem -> sourceRow.addView(pill(sourceItem.first, i == source) { source = i; category = "Все события"; period = "Ближайшие"; renderFilters(); loadPage() }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(6) }) }
        categoryRow.removeAllViews(); categories.forEach { c -> categoryRow.addView(pill(c, c == category) { category = c; renderFilters(); loadPage() }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(6) }) }
        dateRow.removeAllViews(); periods.forEach { d -> dateRow.addView(pill(d, d == period) { period = d; renderFilters(); loadPage() }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(6) }) }
    }

    private fun dateText(): String = when (period) {
        "Сегодня" -> LocalDate.now().format(DateTimeFormatter.ofPattern("dd.MM.yyyy"))
        "Завтра" -> LocalDate.now().plusDays(1).format(DateTimeFormatter.ofPattern("dd.MM.yyyy"))
        "Выходные" -> "ближайшие выходные"
        "7 дней" -> "на ближайшие 7 дней"
        else -> ""
    }
    private fun loadPage() {
        status.text = "Источник: ${sources[source].first} · ${category} · ${period}"
        if (category == "Все события" && period == "Ближайшие") { web.loadUrl(sources[source].second); return }
        val terms = listOf(category.takeIf { it != "Все события" }, dateText(), "мероприятия Москва", "${sources[source].first}").filterNotNull().joinToString(" ")
        val url = "https://www.google.com/search?q=" + URLEncoder.encode(terms, "UTF-8")
        web.loadUrl(url)
    }
    override fun onBackPressed() { if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed() }
}
