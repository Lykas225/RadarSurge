package com.surge.radar

import java.util.Calendar
import java.util.TimeZone
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.roundToInt

/**
 * Оценка спроса без Яндекс Про: профиль по часам и дню недели, тип района, погода.
 * Если Яндекс Про открыт и недавно прислал реальный коэффициент, он подмешивается в расчёт.
 */
object DemandModel {
    enum class Kind { CENTER, RESIDENTIAL, SUBURB, STATION, AIRPORT }

    private val centerWd = doubleArrayOf(
        0.35, 0.25, 0.15, 0.10, 0.10, 0.15, 0.25, 0.40, 0.55, 0.65, 0.55, 0.55,
        0.60, 0.60, 0.55, 0.60, 0.75, 0.95, 1.00, 0.95, 0.80, 0.70, 0.65, 0.50
    )
    private val centerWe = doubleArrayOf(
        0.85, 0.90, 0.80, 0.55, 0.30, 0.15, 0.10, 0.10, 0.15, 0.20, 0.30, 0.40,
        0.50, 0.55, 0.55, 0.60, 0.65, 0.70, 0.80, 0.85, 0.85, 0.85, 0.90, 0.90
    )
    private val residentialWd = doubleArrayOf(
        0.25, 0.15, 0.10, 0.10, 0.15, 0.40, 0.75, 0.95, 1.00, 0.80, 0.50, 0.40,
        0.40, 0.40, 0.40, 0.45, 0.50, 0.55, 0.60, 0.55, 0.50, 0.45, 0.40, 0.30
    )
    private val residentialWe = doubleArrayOf(
        0.45, 0.35, 0.25, 0.20, 0.15, 0.15, 0.15, 0.20, 0.25, 0.30, 0.40, 0.50,
        0.55, 0.55, 0.50, 0.50, 0.50, 0.55, 0.60, 0.65, 0.60, 0.60, 0.60, 0.55
    )
    private val station = doubleArrayOf(
        0.40, 0.30, 0.25, 0.20, 0.25, 0.40, 0.60, 0.80, 0.85, 0.75, 0.60, 0.55,
        0.55, 0.55, 0.55, 0.60, 0.70, 0.85, 0.90, 0.80, 0.70, 0.60, 0.50, 0.45
    )
    private val airport = doubleArrayOf(
        0.60, 0.50, 0.45, 0.50, 0.60, 0.70, 0.75, 0.70, 0.60, 0.55, 0.50, 0.50,
        0.50, 0.55, 0.55, 0.60, 0.65, 0.70, 0.75, 0.70, 0.70, 0.70, 0.65, 0.60
    )

    fun kindOf(zone: SurgeZone): Kind {
        val n = zone.name
        return when {
            n.startsWith("Аэропорт") -> Kind.AIRPORT
            n.startsWith("Комсомольская") || n.startsWith("Белорусская") -> Kind.STATION
            n.startsWith("Центр") || n.startsWith("Сити") || n.startsWith("Таганка") ||
                n.startsWith("Парк Культуры") || n.startsWith("Фили") -> Kind.CENTER
            n.startsWith("МО:") || n == "Зеленоград" || n == "Троицк" ||
                n == "Щербинка" || n == "Московский" -> Kind.SUBURB
            else -> Kind.RESIDENTIAL
        }
    }

    private fun moscowCal(timeMs: Long): Calendar =
        Calendar.getInstance(TimeZone.getTimeZone("Europe/Moscow")).apply { timeInMillis = timeMs }

    private fun isWeekend(cal: Calendar): Boolean {
        val h = cal.get(Calendar.HOUR_OF_DAY)
        return when (cal.get(Calendar.DAY_OF_WEEK)) {
            Calendar.SATURDAY, Calendar.SUNDAY -> true
            Calendar.FRIDAY -> h >= 20
            Calendar.MONDAY -> h < 5
            else -> false
        }
    }

    private fun zoneFactor(zone: SurgeZone): Double =
        0.9 + ((zone.name.hashCode() and 0x7fffffff) % 100) / 500.0

    fun intensity(zone: SurgeZone, timeMs: Long): Double {
        val cal = moscowCal(timeMs)
        val weekend = isWeekend(cal)
        val kind = kindOf(zone)
        val arr = when (kind) {
            Kind.CENTER -> if (weekend) centerWe else centerWd
            Kind.RESIDENTIAL, Kind.SUBURB -> if (weekend) residentialWe else residentialWd
            Kind.STATION -> station
            Kind.AIRPORT -> airport
        }
        val hourF = cal.get(Calendar.HOUR_OF_DAY) + cal.get(Calendar.MINUTE) / 60.0
        val i0 = floor(hourF).toInt() % 24
        val i1 = (i0 + 1) % 24
        val frac = hourF - floor(hourF)
        val v = arr[i0] * (1.0 - frac) + arr[i1] * frac
        return if (kind == Kind.SUBURB) v * 0.85 else v
    }

    /** Коэффициент уровня Эконом (1.0 = нет надбавки). */
    fun baseCoeff(
        zone: SurgeZone,
        timeMs: Long = System.currentTimeMillis(),
        useObserved: Boolean = true
    ): Double {
        val x = (intensity(zone, timeMs) * zoneFactor(zone) + WeatherProvider.boost()).coerceIn(0.0, 1.3)
        var c = 1.0 + 1.6 * max(0.0, x - 0.35)
        if (useObserved) {
            RadarEngine.freshCoeff(zone.name, 30 * 60_000L)?.let { c = 0.5 * c + 0.5 * it }
        }
        return c.coerceIn(1.0, 3.0)
    }

    fun scale(base: Double, t: Tariff): Double = 1.0 + (base - 1.0) * t.k

    fun pct(coeff: Double): Int = ((coeff - 1.0) * 100.0).roundToInt().coerceAtLeast(0)

    fun maxPct(base: Double, tariffs: List<Tariff>): Int =
        if (tariffs.isEmpty()) 0 else pct(tariffs.maxOf { scale(base, it) })

    fun waitMinutes(coeff: Double): Int = (8.0 / coeff.pow(1.6)).roundToInt().coerceIn(2, 12)

    fun forecast(zone: SurgeZone, tariff: Tariff, startMs: Long, steps: Int, stepMs: Long): List<Double> =
        List(steps) { i -> scale(baseCoeff(zone, startMs + i * stepMs, false), tariff) }

    fun label(pct: Int): String = when {
        pct >= 70 -> "Пиковая активность"
        pct >= 40 -> "Высокий спрос"
        pct >= 15 -> "Растущий спрос"
        else -> "Спокойно"
    }

    fun textColor(pct: Int): Int = when {
        pct >= 100 -> 0xFFE040FB.toInt()
        pct >= 60 -> 0xFFFF7043.toInt()
        pct >= 15 -> 0xFF69F0AE.toInt()
        else -> 0xFFB0BEC5.toInt()
    }

    fun heatColor(pct: Int): Int = when {
        pct >= 70 -> 0xFFFF3B30.toInt()
        pct >= 40 -> 0xFFFF8A3D.toInt()
        pct >= 15 -> 0xFFFFC107.toInt()
        else -> 0xFF2DD4BF.toInt()
    }
}
