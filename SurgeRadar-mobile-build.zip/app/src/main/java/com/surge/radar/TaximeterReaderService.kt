package com.surge.radar

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.content.Intent
import android.location.Geocoder
import kotlinx.coroutines.*
import java.util.Locale
import java.util.regex.Pattern

class TaximeterReaderService : AccessibilityService() {

    private val coeffRegex = Pattern.compile(
        "(?:×|x|х)\\s*([1-4](?:[.,][0-9]{1,2})?)",
        Pattern.CASE_INSENSITIVE
    )
    private val rubRegex = Pattern.compile(
        "(\\d{1,3}(?:[\\s\\u00A0]\\d{3}){0,2}|\\d{3,5})\\s*[₽рР]"
    )
    private val minRegex = Pattern.compile("(\\d{1,3})\\s*(?:мин|min)", Pattern.CASE_INSENSITIVE)
    private val addressRegex = Pattern.compile(
        "(?i).*(ул\\.|улица|пр-т|проспект|ш\\.|шоссе|б-р|бульвар|пер\\.|переулок|наб\\.|мкр|проезд|площадь|Москва|Люберцы|Жулебино|Химки|Мытищи|Балашиха|Одинцово|Подольск|Видное|Красногорск|Котельники|Реутов|Домодедово|Шереметьево|Внуково).*"
    )

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var lastScan = 0L
    private var lastAddress = ""

    override fun onServiceConnected() {
        super.onServiceConnected()
        RadarEngine.init(this)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val now = System.currentTimeMillis()
        if (now - lastScan < 300) return
        lastScan = now

        val root = rootInActiveWindow ?: return
        val texts = ArrayList<String>(128)
        collectNodes(root, texts)

        var coeff = 0.0
        var price: String? = null
        var duration: String? = null
        var address: String? = null

        for (raw in texts) {
            val text = raw.trim()
            if (text.isEmpty()) continue

            val cm = coeffRegex.matcher(text.replace(',', '.'))
            while (cm.find()) {
                cm.group(1)?.toDoubleOrNull()?.let {
                    if (it in 1.0..5.0) coeff = maxOf(coeff, it)
                }
            }

            val rm = rubRegex.matcher(text)
            if (rm.find()) {
                val n = rm.group(1).replace(Regex("[\\s\\u00A0]"), "")
                if (n.length in 3..6) price = "$n ₽"
            }

            val mm = minRegex.matcher(text)
            if (mm.find()) duration = "${mm.group(1)} мин"

            if (text.length in 6..120 && addressRegex.matcher(text).matches()) {
                address = text
            }
        }

        if (coeff <= 0.0 && price == null && duration == null && address == null) return

        val zone = address?.let { MoscowRegionGrid.byText(it) }
        val update = Intent(this, OverlayWidgetService::class.java).apply {
            if (coeff > 0) putExtra("COEFF", coeff)
            price?.let { putExtra("PRICE", it) }
            duration?.let { putExtra("DURATION", it) }
            zone?.let { putExtra("ZONE", it.name) }
        }

        // Normally the user starts the overlay service from the app.
        // This also attempts to revive it if the system stopped it.
        runCatching { OverlayWidgetService.start(this) }
        runCatching { startService(update) }

        if (address != null && address != lastAddress) {
            lastAddress = address
            resolveDestination(address)
        }
    }

    private fun resolveDestination(address: String) {
        scope.launch {
            var zone = MoscowRegionGrid.byText(address)

            if (zone == null) {
                runCatching {
                    @Suppress("DEPRECATION")
                    val result = Geocoder(this@TaximeterReaderService, Locale("ru", "RU"))
                        .getFromLocationName("Москва и Московская область, $address", 1)

                    if (!result.isNullOrEmpty()) {
                        val p = result[0]
                        zone = MoscowRegionGrid.nearest(p.latitude, p.longitude)
                    }
                }
            }

            zone?.let {
                val p = RadarEngine.predict(1.0, it.name)
                val intent = Intent(this@TaximeterReaderService, OverlayWidgetService::class.java).apply {
                    putExtra("DEST_NAME", it.name)
                    putExtra("DEST_COEFF", p.forecast5)
                }
                runCatching { startService(intent) }
            }
        }
    }

    private fun collectNodes(node: AccessibilityNodeInfo?, out: MutableList<String>) {
        if (node == null) return
        node.text?.toString()?.takeIf { it.isNotBlank() }?.let(out::add)
        node.contentDescription?.toString()?.takeIf { it.isNotBlank() }?.let(out::add)
        for (i in 0 until node.childCount) {
            collectNodes(node.getChild(i), out)
        }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
