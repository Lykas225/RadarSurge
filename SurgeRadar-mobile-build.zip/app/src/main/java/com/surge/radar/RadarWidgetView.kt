package com.surge.radar

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.roundToInt

/**
 * Виджет в трёх размерах: малый, средний, большой.
 * Используется и в оверлее, и в предпросмотре настроек.
 */
class RadarWidgetView(context: Context, private val cfg: WidgetSettings.Values) : LinearLayout(context) {

    var onClose: (() -> Unit)? = null
    var onOpenMap: (() -> Unit)? = null

    private val f = cfg.scale / 100f
    private val large = cfg.size == WidgetSettings.SIZE_LARGE
    private val teal = 0xFF40E0D0.toInt()
    private val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
    private val match = ViewGroup.LayoutParams.MATCH_PARENT

    private fun px(v: Float): Int = (v * resources.displayMetrics.density * f).roundToInt()

    private fun lp(w: Int, h: Int, weight: Float = 0f) = LinearLayout.LayoutParams(w, h, weight)

    private fun tv(t: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(context).apply {
            text = t
            setTextSize(TypedValue.COMPLEX_UNIT_SP, size * f)
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(0, px(1f), 0, px(1f))
        }

    private val title = tv("SurgeRadar", 13f, Color.WHITE)
    private val demandView = tv("Спрос: +0%", if (large) 16f else 15f, Color.WHITE, true)
    private val waitView = tv("Ожидание:\n—", 14f, Color.WHITE)
    private val labelView = tv("", 14f, Color.WHITE)
    private val orderLine = tv("", 12f, Color.LTGRAY)
    private val destLine = tv("", 12f, Color.LTGRAY)
    private val decisionLine = tv("", 13f, Color.WHITE, true)
    private val radar = RadarView(context)
    private val logo = RadarView(context, false)
    private val spark = SparkView(context)

    private val close = tv("✕", 16f, Color.LTGRAY).apply {
        setPadding(px(10f), 0, 0, 0)
        setOnClickListener { onClose?.invoke() }
    }

    private val nav = tv("➤", 18f, teal).apply {
        gravity = Gravity.CENTER
        setPadding(0, 0, 0, 0)
        background = GradientDrawable().apply {
            cornerRadius = px(10f).toFloat()
            setColor(Color.argb(90, 40, 120, 130))
            setStroke(px(1.5f).coerceAtLeast(1), Color.argb(200, 64, 224, 208))
        }
        setOnClickListener { onOpenMap?.invoke() }
    }

    init {
        orientation = LinearLayout.VERTICAL
        val bgA = (cfg.bgAlpha * 255 / 100).coerceIn(0, 255)
        background = GradientDrawable().apply {
            cornerRadius = px(18f).toFloat()
            setColor(Color.argb(bgA, 8, 22, 34))
            setStroke(px(1.5f).coerceAtLeast(1), Color.argb((bgA * 0.85f).toInt(), 64, 224, 208))
        }
        setPadding(px(12f), px(10f), px(12f), px(10f))
        alpha = cfg.widgetAlpha / 100f

        when (cfg.size) {
            WidgetSettings.SIZE_SMALL -> {
                minimumWidth = px(150f)
                buildSmall()
            }
            WidgetSettings.SIZE_MEDIUM -> {
                minimumWidth = px(210f)
                buildMedium()
            }
            else -> {
                minimumWidth = px(250f)
                buildLarge()
            }
        }
    }

    private fun header(withClose: Boolean): LinearLayout = LinearLayout(context).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        addView(logo, lp(px(16f), px(16f)))
        addView(title, lp(0, wrap, 1f).apply { leftMargin = px(6f) })
        if (withClose) addView(close)
    }

    private fun buildSmall() {
        addView(header(false), lp(match, wrap))
        val row = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        row.addView(demandView, lp(0, wrap, 1f))
        if (cfg.showRadar) row.addView(radar, lp(px(44f), px(44f)))
        addView(row, lp(match, wrap).apply { topMargin = px(6f) })
    }

    private fun buildMedium() {
        addView(header(true), lp(match, wrap))
        val mid = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        if (cfg.showRadar) mid.addView(radar, lp(px(84f), px(84f)))
        val col = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        col.addView(demandView)
        if (cfg.showWait) col.addView(waitView)
        mid.addView(col, lp(0, wrap, 1f).apply { if (cfg.showRadar) leftMargin = px(10f) })
        addView(mid, lp(match, wrap).apply { topMargin = px(6f) })

        addView(labelView, lp(match, wrap).apply { topMargin = px(4f) })

        val bottom = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        if (cfg.showGraph) {
            bottom.addView(spark, lp(0, px(34f), 1f))
        } else {
            bottom.addView(View(context), lp(0, px(34f), 1f))
        }
        bottom.addView(nav, lp(px(36f), px(36f)).apply { leftMargin = px(8f) })
        addView(bottom, lp(match, wrap))
        addDecisionBlock()
    }

    private fun buildLarge() {
        addView(header(true), lp(match, wrap))
        val mid = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        if (cfg.showRadar) mid.addView(radar, lp(px(104f), px(104f)))
        val col = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        col.addView(demandView)
        if (cfg.showWait) col.addView(waitView)
        if (cfg.showGraph) col.addView(spark, lp(match, px(38f)).apply { topMargin = px(4f) })
        mid.addView(col, lp(0, wrap, 1f).apply { if (cfg.showRadar) leftMargin = px(10f) })
        addView(mid, lp(match, wrap).apply { topMargin = px(6f) })

        val bottom = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        bottom.addView(labelView, lp(0, wrap, 1f))
        bottom.addView(nav, lp(px(40f), px(40f)))
        addView(bottom, lp(match, wrap))
        addDecisionBlock()
    }

    private fun addDecisionBlock() {
        if (!cfg.showDecision) return
        addView(orderLine, lp(match, wrap))
        if (large) addView(destLine, lp(match, wrap))
        addView(decisionLine, lp(match, wrap))
    }

    fun bind(d: WidgetData) {
        val sep = if (large) " " else "\n"
        val s = SpannableStringBuilder("Спрос:$sep")
        val start = s.length
        s.append(d.demandText)
        s.setSpan(ForegroundColorSpan(d.demandColor), start, s.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        demandView.text = s

        waitView.text = "Ожидание:\n${d.waitText}"
        labelView.text = d.label
        radar.blips = d.blips
        spark.values = d.history
        setLine(orderLine, d.orderLine)
        setLine(destLine, d.destLine)
        setLine(decisionLine, d.decision)
        decisionLine.setTextColor(d.decisionColor)
    }

    private fun setLine(v: TextView, t: String) {
        v.text = t
        v.visibility = if (t.isBlank()) View.GONE else View.VISIBLE
    }
}
