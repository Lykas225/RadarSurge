package com.surge.radar

import android.accessibilityservice.AccessibilityService
import android.os.PowerManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.content.Intent
import android.location.Geocoder
import kotlinx.coroutines.*
import java.util.Locale
import java.util.regex.Pattern

class TaximeterReaderService : AccessibilityService() {

    private val coeffRegex = Pattern.compile(
        "(?:×|x|х)\\s*([1-4](?:[.,][0-9]{1,2})?)",
        Pattern.CASE_INSENSITIVE
    )
    private val rubRegex = Pattern.compile(
        "(\\d{1,3}(?:[\\s\\u00A0]\\d{3}){0,2}|\\d{3,5})\\s*[₽рР]"
    )
    private val minRegex = Pattern.compile("(\\d{1,3})\\s*(?:мин|min)", Pattern.CASE_INSENSITIVE)
    private val kmRegex = Pattern.compile("(\\d{1,3}(?:[.,]\\d{1,2})?)\\s*км(?!/)", Pattern.CASE_INSENSITIVE)
    // Фразы экранов активного заказа и поездки: пока они на экране, виджет прячется
    private val tripWords = listOf("начать поездку", "завершить поездку", "завершить заказ", "я на месте", "в пути")
    private val addressRegex = Pattern.compile(
        "(?i).*(ул\\.|улица|пр-т|проспект|ш\\.|шоссе|б-р|бульвар|пер\\.|переулок|наб\\.|мкр|проезд|площадь|Москва|Люберцы|Жулебино|Химки|Мытищи|Балашиха|Одинцово|Подольск|Видное|Красногорск|Котельники|Реутов|Домодедово|Шереметьево|Внуково).*"
    )

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var lastScan = 0L
    private var lastAddress = ""
    private var lastHash = 0
    private var lastOfferSeenAt = 0L
    private var shownKey = ""
    private var lastNewOrderAt = 0L
    private var lastTrip = false
    private var lastHashAt = 0L
    private val pm by lazy { getSystemService(POWER_SERVICE) as PowerManager }

    override fun onServiceConnected() {
        super.onServiceConnected()
        RadarEngine.init(this)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val now = System.currentTimeMillis()
        if (now - lastScan < 1000) return
        if (!pm.isInteractive) return
        lastScan = now

        val root = rootInActiveWindow ?: return
        YandexLink.markSeen(this)
        val texts = ArrayList<String>(128)
        collectNodes(root, texts, intArrayOf(400))
        val h = texts.hashCode()
        if (h == lastHash && now - lastHashAt < 15_000L) return
        lastHash = h
        lastHashAt = now

        var coeff = 0.0
        var price: String? = null
        var priceVal = 0.0
        var accept = false
        var duration: String? = null
        var address: String? = null
        val kms = ArrayList<Double>(4)
        val mins = ArrayList<Int>(4)
        var tariff: String? = null
        var trip = false

        for (raw in texts) {
            val text = raw.trim()
            if (text.isEmpty()) continue

            val cm = coeffRegex.matcher(text.replace(',', '.'))
            while (cm.find()) {
                cm.group(1)?.toDoubleOrNull()?.let {
                    if (it in 1.0..5.0) coeff = maxOf(coeff, it)
                }
            }

            val rm = rubRegex.matcher(text)
            if (rm.find()) {
                val n = rm.group(1).replace(Regex("[\\s\\u00A0]"), "")
                // цена заказа: берём наибольшую из обычных сумм, чтобы не зависеть от порядка элементов
                n.toDoubleOrNull()?.let { v ->
                    if (v in 100.0..9999.0 && v > priceVal) {
                        priceVal = v
                        price = "$n ₽"
                    }
                }
            }

            val mm = minRegex.matcher(text)
            while (mm.find()) {
                duration = "${mm.group(1)} мин"
                mm.group(1)?.toIntOrNull()?.let { mins.add(it) }
            }

            val km = kmRegex.matcher(text)
            while (km.find()) {
                km.group(1)?.replace(',', '.')?.toDoubleOrNull()?.let { if (it in 0.1..400.0) kms.add(it) }
            }

            val low = text.lowercase()
            if (!accept && low.startsWith("принять") && low.length <= 24) accept = true
            if (!trip && tripWords.any { low.contains(it) }) trip = true
            if (tariff == null) {
                tariff = when {
                    low.contains("комфорт+") || low.contains("комфорт плюс") -> "COMFORT_PLUS"
                    low.contains("комфорт") -> "COMFORT"
                    low.contains("эконом") -> "ECONOM"
                    else -> null
                }
            }

            if (text.length in 6..120 && addressRegex.matcher(text).matches()) {
                address = text
            }
        }

        val overlayOn = WidgetSettings.load(this).overlayOn
        if (overlayOn && (trip || lastTrip)) {
            // пока на экране заказ/поездка, окошко прячется; после неё возвращается
            runCatching { startService(Intent(this, OverlayWidgetService::class.java).putExtra("TRIP", trip)) }
        }
        lastTrip = trip

        if (coeff <= 0.0 && price == null && duration == null && address == null) return
        if (coeff > 0.0 || price != null) YandexLink.markData(this)

        val zone = address?.let { MoscowRegionGrid.byText(it) }
        val priceNum = if (priceVal > 0.0) priceVal else null
        val hasOrderData = priceNum != null && kms.isNotEmpty()
        if (accept && hasOrderData && !trip) YandexLink.setAcceptLearned(this)

        // Предложение заказа: вердикт показываем ОДИН раз и только до принятия.
        // Когда кнопка «Принять» уже встречалась, предложением считается лишь экран, где она есть:
        // после принятия она пропадает, и цифры дороги и времени на экране больше ничего не запускают.
        val learned = YandexLink.acceptLearned(this)
        val offerLike = !trip && hasOrderData && (accept || !learned)
        var isNewOrder = false
        if (offerLike && priceNum != null) {
            val key = priceNum.toInt().toString()
            val gap = now - lastOfferSeenAt
            lastOfferSeenAt = now
            val absentBefore = gap > (if (learned) 2500L else 4000L)
            // заказ на экране сменился сразу на другой (без паузы) бывает только при кнопке «Принять»
            val swapped = learned && key != shownKey && now - lastNewOrderAt > 8000L
            if (absentBefore || swapped) {
                isNewOrder = true
                shownKey = key
                lastNewOrderAt = now
            }
        }

        if (coeff > 0.0 || isNewOrder) {
            val update = Intent(this, OverlayWidgetService::class.java).apply {
                if (coeff > 0) putExtra("COEFF", coeff)
                zone?.let { putExtra("ZONE", it.name) }
                if (isNewOrder && priceNum != null) {
                    putExtra("PRICE_NUM", priceNum)
                    putExtra("KMS", kms.toDoubleArray())
                    putExtra("MINS", mins.toIntArray())
                    tariff?.let { putExtra("TARIFF", it) }
                    putExtra("NEW_ORDER", true)
                }
            }
            if (overlayOn) {
                if (isNewOrder) runCatching { OverlayWidgetService.start(this) }
                runCatching { startService(update) }
            } else if (coeff > 0) {
                // Виджет выключен: просто запоминаем реальный коэффициент, он уточняет расчёт спроса
                RadarEngine.record(this, coeff, null, null, WidgetSettings.load(this).zone)
            }
        }

        if (address != null && address != lastAddress) {
            lastAddress = address
            resolveDestination(address)
        }
    }

    private fun resolveDestination(address: String) {
        scope.launch {
            var zone = MoscowRegionGrid.byText(address)

            if (zone == null) {
                runCatching {
                    @Suppress("DEPRECATION")
                    val result = Geocoder(this@TaximeterReaderService, Locale("ru", "RU"))
                        .getFromLocationName("Москва и Московская область, $address", 1)

                    if (!result.isNullOrEmpty()) {
                        val p = result[0]
                        zone = MoscowRegionGrid.nearest(p.latitude, p.longitude)
                    }
                }
            }

            zone?.let {
                val p = RadarEngine.predict(1.0, it.name)
                val intent = Intent(this@TaximeterReaderService, OverlayWidgetService::class.java).apply {
                    putExtra("DEST_NAME", it.name)
                    putExtra("DEST_COEFF", p.forecast5)
                }
                if (WidgetSettings.load(this@TaximeterReaderService).overlayOn) {
                    runCatching { startService(intent) }
                }
            }
        }
    }

    private fun collectNodes(node: AccessibilityNodeInfo?, out: MutableList<String>, budget: IntArray) {
        if (node == null || budget[0] <= 0) return
        budget[0]--
        node.text?.toString()?.takeIf { it.isNotBlank() }?.let(out::add)
        node.contentDescription?.toString()?.takeIf { it.isNotBlank() }?.let(out::add)
        for (i in 0 until node.childCount) {
            collectNodes(node.getChild(i), out, budget)
        }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
